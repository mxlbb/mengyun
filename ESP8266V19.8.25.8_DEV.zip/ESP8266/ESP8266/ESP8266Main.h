//#define define_esp8266_input //请确认硬件类型引脚是否只有GPIO-0和GPIO-2是请定义

#include "./System/System.h"
#include "./Application/Application.h"

void wifi_test_demo();

void setup()
{
  Serial.begin(115200);
  //wifi_test_demo();
  BasicErvices_setup();
  WebServer_setup();
}

void loop()
{
  BasicErvices_loop();
  WebServer_loop();
}

void wifi_test_demo()
{
  WiFi.hostname("萌小狸宝宝");
  WiFi.mode(WIFI_STA);
  WiFi.begin(F("萌小狸宝宝"), F("梦云之家智慧未来"));
  WiFi.getAutoConnect();
  Serial.print(F("正在连接到\"萌小狸宝宝\""));
  while (WiFi.status() != WL_CONNECTED)delay(500), Serial.print(F("."));
  Serial.print(F("\nWiFi已连接，IP地址:"));
  Serial.println(WiFi.localIP());
  Serial.printf("可用堆栈：%10dByte\n", ESP.getMaxFreeBlockSize());
}
