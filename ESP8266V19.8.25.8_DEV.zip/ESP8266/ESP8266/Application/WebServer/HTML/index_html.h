String web_server_html::HTML_index_html()
{
  String data_string;
  data_string = F("\n"\
                  "<!DOCTYPE html>\n"\
                  "<html lang=\"zh\">\n"\
                  "\n"\
                  "<head>\n"\
                  "<meta charset=\"UTF-8\" />\n"\
                  "<link rel=\"shortcut icon\" href=\"https://www.baidu.com/favicon.ico\" type=\"image/x-icon\" />\n"\
                  "<link rel=\"stylesheet\" type=\"text/css\" href=\"css/reset.css\" />\n"\
                  "<link rel=\"stylesheet\" type=\"text/css\" href=\"css/zzsc.css\" />\n"\
                  "<link rel=\"stylesheet\" href=\"css/style.css\" />\n"\
                  "<script src=\"js/public.js\" type=\"text/javascript\"></script>\n"\
                  "<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\" />\n"\
                  "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n"\
                  "<meta http-equiv=\"pragma\" content=\"no-cache\" />\n"\
                  "<meta http-equiv=\"Cache-Control\" content=\"no-cache, must-revalidate\" />\n"\
                  "<meta http-equiv=\"expires\" content=\"0\" />\n"\
                  "<p id=\"function_site\"></p>\n"\
                  "<script>function_site();</script>\n"\
                  "</head>\n"\
                  "\n"\
                  "<body>\n"\
                  "<p id=\"function_site\"></p>\n"\
                  "<script>function_site();</script>\n"\
                  "<style>p{text-align:center;} table{width:100%;height:100%;display: none;} input{width:100%;height:100%;outline:none;background:transparent;border:none;outline:medium;} *:focus{outline:none;background-color:transparent;} ::selection{background:transparent; } ::-moz-selection{background:transparent; }</style>\n"\
                  "<div style=\"text-align:center;margin:50px 0; font:normal 150% 'MicroSoft YaHei';\">\n"\
                  "<p id=\"function_title\">正在加载...</p></div>\n"\
                  "<script>function_title();</script>\n"\
                  "<div class=\"container\">\n"\
                  "<dl>\n"\
                  "<dt>授权认证</dt>\n"\
                  "<dd>\n"\
                  "<table style=\"display: table;\">\n"\
                  "<tbody>\n"\
                  "<tr>\n"\
                  "<td style=\"text-align:right;vertical-align:middle;\">用户名:</td>\n"\
                  "<td style=\"vertical-align:middle;\">\n"\
                  "<input id=\"DataUser\" placeholder=\"请输入用户名\" value=\"\n"\
                  "");
  data_string += data_security_user;
  data_string += F("\n"\
                   "\" /></td>\n"\
                   "</tr>\n"\
                   "<tr>\n"\
                   "<td style=\"text-align:right;vertical-align:middle;\">密&nbsp;&nbsp;&nbsp;&nbsp;码:</td>\n"\
                   "<td style=\"vertical-align:middle;\">\n"\
                   "<input id=\"DataPasswork\" placeholder=\"请输入密码\" value=\"\n"\
                   "");
  data_string += data_security_psk;
  data_string += F("\n"\
                   "\" /></td>\n"\
                   "</tr>\n"\
                   "<tr>\n"\
                   "<td style=\"text-align:right;vertical-align:middle;\"></td>\n"\
                   "<td style=\"vertical-align:middle;\">\n"\
                   "<button style=\"background:transparent;\" type=\"button\" onclick=\"function_main()\">登入设备</button></td>\n"\
                   "</tr>\n"\
                   "</tbody>\n"\
                   "<tbody>\n"\
                   "<tr>\n"\
                   "<td style=\"text-align:right;vertical-align:middle;\"></td>\n"\
                   "<td style=\"vertical-align:middle;\">你准备好&quot;登入设备&quot;了吗?</td></tr>\n"\
                   "<tr>\n"\
                   "<td style=\"text-align:right;vertical-align:middle;\"></td>\n"\
                   "<td style=\"vertical-align:middle;\">测试阶段显示用户密码</td></tr>\n"\
                   "</tbody>\n"\
                   "</table>\n"\
                   "</dd>\n"\
                   "<dt>功能菜单</dt>\n"\
                   "<dd>\n"\
                   "<div id=\"function_public\"></div>\n"\
                   "<div id=\"function_help\"></div>\n"\
                   "<script>\n"\
				   "function_public();\n"\
                   "function_help();\n"\
				   "</script>\n"\
                   "</dd>\n"\
                   "</dl>\n"\
                   "</div>\n"\
                   "<script src=\"https://code.jquery.com/jquery-2.1.1.min.js\" type=\"text/javascript\"></script>\n"\
                   "<script type=\"text/javascript\">(function() {\n"\
                   "$('dd').filter(':nth-child(n+4)').addClass('hide');\n"\
                   "$('dl').on('click', 'dt',\n"\
                   "function() {\n"\
                   "$(this).next().slideToggle(200);\n"\
                   "});\n"\
                   "})();</script>\n"\
                   "</body>\n"\
                   "\n"\
                   "</html>\n"\
                   "");
  return data_string;
}
