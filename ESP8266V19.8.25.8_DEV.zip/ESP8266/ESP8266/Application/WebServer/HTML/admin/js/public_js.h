String web_server_html::HTML_public_js()
{
  String data_string;
  data_string = F("\n"\
                    "function function_main() {\n"\
                  "var data_user = document.getElementById(\"DataUser\").value;\n"\
                  "var data_passwork = document.getElementById(\"DataPasswork\").value;\n"\
                  "if (data_user == \"\") {\n"\
                  "alert(\"用户名不能为空！\");\n"\
                  "return;\n"\
                  "}\n"\
                  "if (data_passwork == \"\") {\n"\
                  "alert(\"密码不能为空！\");\n"\
                  "return;\n"\
                  "}\n"\
                  "var data_url = location.protocol + \"//\" + data_user + \":\" + data_passwork + \"@\" + location.host + \"/admin.html\";\n"\
				  "self.location = data_url;\n"\
                  "}\n"\
                  "function function_title() {\n"\
                  "function_json(\"POST\", \"application/x-www-form-urlencoded\", \"/server/public.php\", \"\",\n"\
                  "function(returnData) {\n"\
                  "var Return_char = \"\";\n"\
                  "returnData = eval('(' + returnData + ')');\n"\
                  "Return_char += \"<a href=\\\"/\\\">\" + returnData.公共服务.设备名称 + \"</a>\";\n"\
                  "Return_char += \"&nbsp;-&nbsp;\";\n"\
                  "Return_char += \"<a target=\\\"view_window\\\" href=\\\"\" + returnData.公共服务.云端地址 + \"\\\">\" + returnData.公共服务.云端名称 + \"</a>\";\n"\
                  "document.getElementById(\"function_title\").innerHTML = Return_char;\n"\
                  "});\n"\
                  "}\n"\
                  "\n"\
                  "function function_site() {\n"\
                  "function_json(\"POST\", \"application/x-www-form-urlencoded\", \"/server/public.php\", \"\",\n"\
                  "function(returnData) {\n"\
                  "var Return_char = \"\";\n"\
                  "returnData = eval('(' + returnData + ')');\n"\
                  "Return_char += \"<title>\" + returnData.公共服务.设备名称 + \"&nbsp;-&nbsp;\" + returnData.公共服务.云端名称 + \"</title>\";\n"\
                  "document.getElementById(\"function_site\").innerHTML = Return_char;\n"\
                  "});\n"\
                  "}\n"\
                  "\n"\
                  "function function_public() {\n"\
                  "function_json(\"POST\", \"application/x-www-form-urlencoded\", \"/server/public.php\", \"\",\n"\
                  "function(returnData) {\n"\
                  "var Return_char;\n"\
                  "returnData = eval('(' + returnData + ')');\n"\
                  "for (var childElement in returnData) {\n"\
                  "Return_char = \"<table><dt>\" + childElement + \"</dt><tbody>\";\n"\
                  "var subchildElement = returnData[childElement];\n"\
                  "for (var subchild in subchildElement) {\n"\
                  "Return_char += \"<tr><td style=\\\"text-align:right;vertical-align:middle;\\\">\" + subchild + \":</td>\";\n"\
                  "Return_char += \"<td style=\\\"vertical-align:middle;\\\"><input value=\\\"\" + subchildElement[subchild] + \"\\\" /></td></tr>\";\n"\
                  "}\n"\
                  "}\n"\
                  "Return_char += \"</tbody></table>\";\n"\
                  "document.getElementById(\"function_public\").innerHTML = Return_char;\n"\
                  "});\n"\
                  "}\n"\
                  "\n"\
                  "function function_help() {\n"\
                  "var Return_char;\n"\
                  "Return_char = \"<table><dt>使用帮助</dt><tbody><tr><td style=\\\"text-align:center;vertical-align:middle;\\\">\";\n"\
				  "Return_char += \"&nbsp;<a style=\\\"text-decoration:none;\\\" href=\\\"help/index.html\\\">帮助文档</a>&nbsp;\";\n"\
                  "Return_char += \"&nbsp;<a style=\\\"text-decoration:none;\\\" href=\\\"help/index.html#Common_problem\\\">常见问题</a>&nbsp;\";\n"\
                  "Return_char += \"&nbsp;<a style=\\\"text-decoration:none;\\\" href=\\\"help/index.html#user\\\">用户手册</a>&nbsp;\";\n"\
                  "Return_char += \"&nbsp;<a style=\\\"text-decoration:none;\\\" href=\\\"help/index.html#dev\\\">开发手册</a>&nbsp;\";\n"\
				  "Return_char += \"</td></tr></tbody></table>\";\n"\
                  "document.getElementById(\"function_help\").innerHTML = Return_char;\n"\
                  "}\n"\
                  "function function_json(data_post, content_type, data_uri, data_params, callback) {\n"\
                  "var xmlhttp;\n"\
                  "var ReturnChar;\n"\
                  "if (window.XMLHttpRequest) xmlhttp = new XMLHttpRequest();\n"\
                  "else xmlhttp = new ActiveXObject(\"Microsoft.XMLHTTP\");\n"\
                  "xmlhttp.onreadystatechange = function() {\n"\
                  "if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {\n"\
                  "callback(xmlhttp.responseText);\n"\
                  "}\n"\
                  "}\n"\
                  "xmlhttp.open(data_post, data_uri, true);\n"\
                  "xmlhttp.setRequestHeader(\"Content-type\", content_type);\n"\
                  "xmlhttp.send(data_params);\n"\
                  "}\n"\
                  "\n"\
                  "");
  return data_string;
}
