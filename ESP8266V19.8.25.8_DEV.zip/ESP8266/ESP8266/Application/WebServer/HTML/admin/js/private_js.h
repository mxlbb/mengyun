String web_server_html::HTML_private_js()
{
  String data_string;
  data_string = F("\n"\
                  "function function_switch_query() {\n"\
                  "function_json(\"POST\", \"application/x-www-form-urlencoded\", \"/server/switch.php\", \"查询=GPIO-0\",\n"\
                  "function(returnData) {\n"\
                  "returnData = eval('(' + returnData + ')');\n"\
                  "var GPIO_STATUS = returnData['GPIO-0'];\n"\
                  "if (GPIO_STATUS)\n"\
                  "document.getElementById(\"function_switch\").innerHTML = \"运行状态:&nbsp;已开启&nbsp;\";\n"\
                  "else\n"\
                  "document.getElementById(\"function_switch\").innerHTML = \"运行状态:&nbsp;已关闭&nbsp;\";\n"\
                  "});\n"\
                  "}\n"\
                  "\n"\
                  "function function_switch_open() {\n"\
                  "function_json(\"POST\", \"application/x-www-form-urlencoded\", \"/server/switch.php\", \"开关=开启\",\n"\
                  "function(returnData) {\n"\
                  "returnData = eval('(' + returnData + ')');\n"\
                  "if (returnData.开关 == \"开启\") document.getElementById(\"function_switch\").innerHTML = \"运行状态:&nbsp;已开启&nbsp;\";\n"\
                  "});\n"\
                  "}\n"\
                  "\n"\
                  "function function_switch_close() {\n"\
                  "function_json(\"POST\", \"application/x-www-form-urlencoded\", \"/server/switch.php\", \"开关=关闭\",\n"\
                  "function(returnData) {\n"\
                  "returnData = eval('(' + returnData + ')');\n"\
                  "if (returnData.开关 == \"关闭\") document.getElementById(\"function_switch\").innerHTML = \"运行状态:&nbsp;已关闭&nbsp;\";\n"\
                  "});\n"\
                  "}\n"\
                  "\n"\
                  "function function_reboot() {\n"\
                  "function_json(\"POST\", \"application/x-www-form-urlencoded\", \"/server/switch.php\", \"重启=确认\",\n"\
                  "function(returnData) {\n"\
                  "returnData = eval('(' + returnData + ')');\n"\
                  "if (returnData.重启 == \"确认\") alert(\"重启成功\\n请耐心等待硬件接入网络！\");\n"\
                  "});\n"\
                  "}\n"\
                  "\n"\
                  "function function_reset() {\n"\
                  "function_json(\"POST\", \"application/x-www-form-urlencoded\", \"/server/switch.php\", \"重置=确认\",\n"\
                  "function(returnData) {\n"\
                  "returnData = eval('(' + returnData + ')');\n"\
                  "if (returnData.重置 == \"确认\");\n"\
                  "alert(\"重置成功\\n请重启硬件并重新设置网无线网络！\");\n"\
                  "});\n"\
                  "}\n"\
                  "\n"\
                  "function function_message() {\n"\
                  "function_json(\"POST\", \"application/x-www-form-urlencoded\", \"/server/api.php\", \"1=实时信息\",\n"\
                  "function(returnData) {\n"\
                  "var Return_char;\n"\
                  "returnData = eval('(' + returnData + ')');\n"\
                  "for (var childElement in returnData) {\n"\
                  "Return_char = \"<table><dt>\" + childElement + \"</dt><tbody>\";\n"\
                  "var subchildElement = returnData[childElement];\n"\
                  "for (var subchild in subchildElement) {\n"\
                  "Return_char += \"<tr><td style=\\\"text-align:right;vertical-align:middle;\\\">\" + subchild + \":</td>\";\n"\
                  "Return_char += \"<td style=\\\"vertical-align:middle;\\\"><input value=\\\"\" + subchildElement[subchild] + \"\\\" /></td></tr>\";\n"\
                  "}\n"\
                  "}\n"\
                  "Return_char += \"</tbody></table>\";\n"\
                  "document.getElementById(\"function_message\").innerHTML = Return_char;\n"\
                  "});\n"\
                  "}\n"\
                  "\n"\
                  "function function_network() {\n"\
                  "function_json(\"POST\", \"application/x-www-form-urlencoded\", \"/server/api.php\", \"2=网络状态\",\n"\
                  "function(returnData) {\n"\
                  "var Return_char;\n"\
                  "returnData = eval('(' + returnData + ')');\n"\
                  "for (var childElement in returnData) {\n"\
                  "Return_char = \"<table><dt>\" + childElement + \"</dt><tbody>\";\n"\
                  "var subchildElement = returnData[childElement];\n"\
                  "for (var subchild in subchildElement) {\n"\
                  "Return_char += \"<tr><td style=\\\"text-align:right;vertical-align:middle;\\\">\" + subchild + \":</td>\";\n"\
                  "Return_char += \"<td style=\\\"vertical-align:middle;\\\"><input value=\\\"\" + subchildElement[subchild] + \"\\\" /></td></tr>\";\n"\
                  "}\n"\
                  "}\n"\
                  "Return_char += \"</tbody></table>\";\n"\
                  "document.getElementById(\"function_network\").innerHTML = Return_char;\n"\
                  "});\n"\
                  "}\n"\
                  "\n"\
                  "function function_security() {\n"\
                  "function_json(\"POST\", \"application/x-www-form-urlencoded\", \"/server/api.php\", \"3=安全认证\",\n"\
                  "function(returnData) {\n"\
                  "var Return_char;\n"\
                  "returnData = eval('(' + returnData + ')');\n"\
                  "for (var childElement in returnData) {\n"\
                  "Return_char = \"<table><dt>\" + childElement + \"</dt><tbody>\";\n"\
                  "var subchildElement = returnData[childElement];\n"\
                  "for (var subchild in subchildElement) {\n"\
                  "Return_char += \"<tr><td style=\\\"text-align:right;vertical-align:middle;\\\">\" + subchild + \":</td>\";\n"\
                  "Return_char += \"<td style=\\\"vertical-align:middle;\\\"><input value=\\\"\" + subchildElement[subchild] + \"\\\" /></td></tr>\";\n"\
                  "}\n"\
                  "}\n"\
                  "Return_char += \"</tbody></table>\";\n"\
                  "document.getElementById(\"function_security\").innerHTML = Return_char;\n"\
                  "});\n"\
                  "}\n"\
                  "\n"\
                  "function function_eeprom() {\n"\
                  "function_json(\"POST\", \"application/x-www-form-urlencoded\", \"/server/eeprom.php\", \"1=全部数据\",\n"\
                  "function(returnData) {\n"\
                  "var Return_char;\n"\
                  "returnData = eval('(' + returnData + ')');\n"\
                  "for (var childElement in returnData) {\n"\
                  "Return_char = \"<table><dt>\" + childElement + \"</dt><tbody>\";\n"\
                  "var subchildElement = returnData[childElement];\n"\
                  "for (var subchild in subchildElement) {\n"\
                  "Return_char += \"<tr><td style=\\\"text-align:right;vertical-align:middle;\\\">\" + subchild + \":</td>\";\n"\
                  "Return_char += \"<td style=\\\"vertical-align:middle;\\\"><input value=\\\"\" + subchildElement[subchild] + \"\\\" /></td></tr>\";\n"\
                  "}\n"\
                  "}\n"\
                  "Return_char += \"</tbody></table>\";\n"\
                  "document.getElementById(\"function_eeprom\").innerHTML = Return_char;\n"\
                  "});\n"\
                  "}\n"\
                  "\n"\
                  "");\
  return data_string;
}
