String web_server_html::HTML_zzsc_css()
{
  return F(""\
           "body{"\
           "background: #494A5F;"\
           "color: #808080;"\
           "font-weight: 500;"\
           "font-size: 1.05em;"\
           "font-family: \"楷体\",\"Microsoft YaHei\",\"宋体\",\"Segoe UI\", \"Lucida Grande\", Helvetica, Arial,sans-serif, FreeSans, Arimo;"\
           "}"\
           "a{color: #808080;text-decoration: none;outline: none;}"\
           "a:hover,a:focus{color:#74777b;}"\
           ".center{text-align: center;}"\
           "");
}