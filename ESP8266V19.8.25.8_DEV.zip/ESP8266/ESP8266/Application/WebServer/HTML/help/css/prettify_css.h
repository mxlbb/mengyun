String web_server_html::HTML_help_prettify_css()
{
  String data_string;
  data_string = F(""
                  "/* GitHub Theme */\n"\
                  "/* Pretty printing styles. Used with prettify.js. */\n"\
                  "/* SPAN elements with the classes below are added by prettyprint. */\n"\
                  "/* plain text */\n"\
                  ".pln {\n"\
                  "  color: #333333;\n"\
                  "}\n"\
                  ".prettyprint{overflow:auto!important;}\n"\
                  "\n"\
                  "@media screen {\n"\
                  "  /* string content */\n"\
                  "  .str {\n"\
                  "    color: #dd1144;\n"\
                  "  }\n"\
                  "\n"\
                  "  /* a keyword */\n"\
                  "  .kwd {\n"\
                  "    color: #333333;\n"\
                  "  }\n"\
                  "\n"\
                  "  /* a comment */\n"\
                  "  .com {\n"\
                  "    color: #999988;\n"\
                  "  }\n"\
                  "\n"\
                  "  /* a type name */\n"\
                  "  .typ {\n"\
                  "    color: #445588;\n"\
                  "  }\n"\
                  "\n"\
                  "  /* a literal value */\n"\
                  "  .lit {\n"\
                  "    color: #445588;\n"\
                  "  }\n"\
                  "\n"\
                  "  /* punctuation */\n"\
                  "  .pun {\n"\
                  "    color: #333333;\n"\
                  "  }\n"\
                  "\n"\
                  "  /* lisp open bracket */\n"\
                  "  .opn {\n"\
                  "    color: #333333;\n"\
                  "  }\n"\
                  "\n"\
                  "  /* lisp close bracket */\n"\
                  "  .clo {\n"\
                  "    color: #333333;\n"\
                  "  }\n"\
                  "\n"\
                  "  /* a markup tag name */\n"\
                  "  .tag {\n"\
                  "    color: navy;\n"\
                  "  }\n"\
                  "\n"\
                  "  /* a markup attribute name */\n"\
                  "  .atn {\n"\
                  "    color: teal;\n"\
                  "  }\n"\
                  "\n"\
                  "  /* a markup attribute value */\n"\
                  "  .atv {\n"\
                  "    color: #dd1144;\n"\
                  "  }\n"\
                  "\n"\
                  "  /* a declaration */\n"\
                  "  .dec {\n"\
                  "    color: #333333;\n"\
                  "  }\n"\
                  "\n"\
                  "  /* a variable name */\n"\
                  "  .var {\n"\
                  "    color: teal;\n"\
                  "  }\n"\
                  "\n"\
                  "  /* a function name */\n"\
                  "  .fun {\n"\
                  "    color: #990000;\n"\
                  "  }\n"\
                  "}\n"\
                  "/* Use higher contrast and text-weight for printable form. */\n"\
                  "@media print, projection {\n"\
                  "  .str {\n"\
                  "    color: #006600;\n"\
                  "  }\n"\
                  "\n"\
                  "  .kwd {\n"\
                  "    color: #006;\n"\
                  "    font-weight: bold;\n"\
                  "  }\n"\
                  "\n"\
                  "  .com {\n"\
                  "    color: #600;\n"\
                  "    font-style: italic;\n"\
                  "  }\n"\
                  "\n"\
                  "  .typ {\n"\
                  "    color: #404;\n"\
                  "    font-weight: bold;\n"\
                  "  }\n"\
                  "\n"\
                  "  .lit {\n"\
                  "    color: #004444;\n"\
                  "  }\n"\
                  "\n"\
                  "  .pun, .opn, .clo {\n"\
                  "    color: #444400;\n"\
                  "  }\n"\
                  "\n"\
                  "  .tag {\n"\
                  "    color: #006;\n"\
                  "    font-weight: bold;\n"\
                  "  }\n"\
                  "\n"\
                  "  .atn {\n"\
                  "    color: #440044;\n"\
                  "  }\n"\
                  "\n"\
                  "  .atv {\n"\
                  "    color: #006600;\n"\
                  "  }\n"\
                  "}\n"\
                  "/* Style */\n"\
                  "pre.prettyprint {\n"\
                  "  background: #F0F0F0;\n"\
                  "  font-family: Menlo, \"Bitstream Vera Sans Mono\", \"DejaVu Sans Mono\", Monaco, Consolas, monospace;\n"\
                  "  font-size: 12px;\n"\
                  "  line-height: 1.5;\n"\
                  "  border: 1px solid #cccccc;\n"\
                  "  padding: 0;\n"\
                  "}\n"\
                  "\n"\
                  "/* Specify class=linenums on a pre to get line numbering */\n"\
                  "ol.linenums {\n"\
                  "  margin-top: 0;\n"\
                  "  margin-bottom: 0;\n"\
                  "  color: #888;\n"\
                  "}\n"\
                  "\n"\
                  ".linenums li {\n"\
                  "  background: #FAFAFA;\n"\
                  "  padding-left: 10px;\n"\
                  "  border-left: 1px solid #CCC;\n"\
                  "}\n"\
                  "\n"\
                  ".linenums li {\n"\
                  "  padding-top: 5px;\n"\
                  "}\n"\
                  "\n"\
                  ".linenums li + li {\n"\
                  "  padding-top: 0;\n"\
                  "}\n"\
                  "\n"\
                  ".linenums li:last-child {\n"\
                  "  padding-bottom: 5px;\n"\
                  "}\n"\
                  "\n"\
                  "\n"\
                  "\n"\
                  "/* IE indents via margin-left */\n"\
                  "li.L0,\n"\
                  "li.L1,\n"\
                  "li.L2,\n"\
                  "li.L3,\n"\
                  "li.L4,\n"\
                  "li.L5,\n"\
                  "li.L6,\n"\
                  "li.L7,\n"\
                  "li.L8,\n"\
                  "li.L9 {\n"\
                  "  /* */\n"\
                  "}\n"\
                  "\n"\
                  "/* Alternate shading for lines */\n"\
                  "li.L1,\n"\
                  "li.L3,\n"\
                  "li.L5,\n"\
                  "li.L7,\n"\
                  "li.L9 {\n"\
                  "  /* */\n"\
                  "}\n"\
                  "\n"\
                  "");
  return data_string;
}