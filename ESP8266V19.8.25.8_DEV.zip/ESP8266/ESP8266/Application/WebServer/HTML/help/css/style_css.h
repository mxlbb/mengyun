String web_server_html::HTML_help_style_css()
{
  String data_string;
  data_string = F(""
                  "body,\n"\
                  "html {\n"\
                  "    margin: 0;\n"\
                  "    padding: 0;\n"\
                  "}\n"\
                  "\n"\
                  "body,\n"\
                  "input,\n"\
                  "h1,\n"\
                  "h2,\n"\
                  "h3,\n"\
                  "h4,\n"\
                  "h5,\n"\
                  "h6 {\n"\
                  "    font-family: \"Raleway\", Helvetica, Arial, \"Lucida Grande\", sans-serif;\n"\
                  "    font-weight: 300;\n"\
                  "    font-size: 18px;\n"\
                  "}\n"\
                  "\n"\
                  "body {\n"\
                  "    line-height: 2;\n"\
                  "    color: #444;\n"\
                  "    background: #fff;\n"\
                  "}\n"\
                  "\n"\
                  "img,\n"\
                  "iframe {\n"\
                  "    max-width: 100%;\n"\
                  "}\n"\
                  "\n"\
                  "iframe {\n"\
                  "    max-height: 100%;\n"\
                  "}\n"\
                  "\n"\
                  "img {\n"\
                  "    height: auto;\n"\
                  "}\n"\
                  "\n"\
                  "iframe {\n"\
                  "    border: 0 !important;\n"\
                  "}\n"\
                  "\n"\
                  "header {\n"\
                  "    width: 100%;\n"\
                  "    overflow: hidden;\n"\
                  "}\n"\
                  "\n"\
                  ".container {\n"\
                  "    width: 95%;\n"\
                  "    max-width: 650px;\n"\
                  "    margin: 0 auto;\n"\
                  "    position: relative;\n"\
                  "}\n"\
                  "\n"\
                  "strong,\n"\
                  "dt,\n"\
                  "h3,\n"\
                  "h4 {\n"\
                  "    font-weight: 700;\n"\
                  "}\n"\
                  "\n"\
                  "h1,\n"\
                  "h2,\n"\
                  "h3,\n"\
                  "h4,\n"\
                  "h5,\n"\
                  "h6 {\n"\
                  "    margin: 10px 0;\n"\
                  "    line-height: 20px;\n"\
                  "    color: inherit;\n"\
                  "    text-rendering: optimizelegibility;\n"\
                  "}\n"\
                  "\n"\
                  "h1,\n"\
                  "h2,\n"\
                  "h3 {\n"\
                  "    line-height: 40px;\n"\
                  "}\n"\
                  "\n"\
                  "h2 {\n"\
                  "    font-size: 50px;\n"\
                  "    line-height: 1.2;\n"\
                  "}\n"\
                  "\n"\
                  "h3 {\n"\
                  "    font-size: 24.5px;\n"\
                  "}\n"\
                  "\n"\
                  "h4 {\n"\
                  "    font-size: 17.5px;\n"\
                  "}\n"\
                  "\n"\
                  "h5 {\n"\
                  "    font-size: 14px;\n"\
                  "}\n"\
                  "\n"\
                  "h6 {\n"\
                  "    font-size: 11.9px;\n"\
                  "}\n"\
                  "\n"\
                  "hr {\n"\
                  "    background: #eee;\n"\
                  "    border: 0;\n"\
                  "    height: 1px;\n"\
                  "    margin: 40px 0 40px;\n"\
                  "}\n"\
                  "\n"\
                  "blockquote {\n"\
                  "    margin: 1em 0;\n"\
                  "    border-left: 3px solid #ccc;\n"\
                  "    padding-left: 20px;\n"\
                  "    text-align: left;\n"\
                  "}\n"\
                  "\n"\
                  "dt {}\n"\
                  "\n"\
                  "dd {\n"\
                  "    padding: 0;\n"\
                  "    margin: 0 0 25px 0;\n"\
                  "}\n"\
                  "\n"\
                  "a {\n"\
                  "    -webkit-transition: all ease 150ms;\n"\
                  "    -moz-transition: all ease 150ms;\n"\
                  "    -o-transition: all ease 150ms;\n"\
                  "    transition: all ease 150ms;\n"\
                  "    text-decoration: none;\n"\
                  "    color: #333;\n"\
                  "}\n"\
                  "\n"\
                  "a:hover {\n"\
                  "    text-decoration: underline;\n"\
                  "    color: #f56741;\n"\
                  "}\n"\
                  "\n"\
                  "a:active {\n"\
                  "    color: #f56741;\n"\
                  "}\n"\
                  "\n"\
                  "\n"\
                  "/* Header Styles */\n"\
                  "\n"\
                  "header {\n"\
                  "    padding: 2em 0 2em 0;\n"\
                  "    text-align: center;\n"\
                  "    background: #f56741;\n"\
                  "    color: #fff;\n"\
                  "}\n"\
                  "\n"\
                  "h1 {\n"\
                  "    margin: 0;\n"\
                  "    padding: 0;\n"\
                  "    float: left;\n"\
                  "    color: #fff;\n"\
                  "    font-weight: bold;\n"\
                  "    font-size: 35px;\n"\
                  "    text-transform: uppercase;\n"\
                  "    padding-top: 10px;\n"\
                  "    margin-right: 30px;\n"\
                  "}\n"\
                  "\n"\
                  "header h2 {\n"\
                  "    margin: 0 0 1em 0;\n"\
                  "}\n"\
                  "\n"\
                  "header h2.docs-header {\n"\
                  "    margin: 0;\n"\
                  "}\n"\
                  "\n"\
                  "footer {\n"\
                  "    text-align: center;\n"\
                  "    padding: 1.5em 0;\n"\
                  "}\n"\
                  "\n"\
                  "footer p {\n"\
                  "    margin: 0;\n"\
                  "    color: #999;\n"\
                  "}\n"\
                  "\n"\
                  "\n"\
                  "/* Navigation Styles */\n"\
                  "\n"\
                  "nav {\n"\
                  "    background: #2b2a28;\n"\
                  "    padding: 10px 0;\n"\
                  "    min-height: 60px;\n"\
                  "}\n"\
                  "\n"\
                  "nav ul,\n"\
                  "nav li {\n"\
                  "    margin: 0;\n"\
                  "    padding: 0;\n"\
                  "    list-style: none;\n"\
                  "}\n"\
                  "\n"\
                  "nav a {\n"\
                  "    padding: 0 1em;\n"\
                  "    color: #eee;\n"\
                  "    font-size: 0.9em;\n"\
                  "    height: 60px;\n"\
                  "    line-height: 60px;\n"\
                  "    display: block;\n"\
                  "    background: #2b2a28;\n"\
                  "}\n"\
                  "\n"\
                  "nav h1 a {\n"\
                  "    padding: 7px 1em;\n"\
                  "    height: 46px;\n"\
                  "    line-height: 0;\n"\
                  "    height: 45px;\n"\
                  "    line-height: 45px;\n"\
                  "}\n"\
                  "\n"\
                  "nav a:hover {\n"\
                  "    background: #f56741;\n"\
                  "    text-decoration: none;\n"\
                  "    color: #fff;\n"\
                  "}\n"\
                  "\n"\
                  "nav a:active {\n"\
                  "    background: #27637e;\n"\
                  "}\n"\
                  "\n"\
                  "nav a:active {\n"\
                  "    color: #fff;\n"\
                  "    cursor: default;\n"\
                  "}\n"\
                  "\n"\
                  "nav ul.site {\n"\
                  "    padding: 20px 0 0 0;\n"\
                  "}\n"\
                  "\n"\
                  "nav #menu {\n"\
                  "    overflow: hidden;\n"\
                  "    max-height: 0;\n"\
                  "    clear: left;\n"\
                  "}\n"\
                  "\n"\
                  "nav #menu-toggle {\n"\
                  "    position: absolute;\n"\
                  "    right: 0;\n"\
                  "    top: 0;\n"\
                  "    font-size: 1.5em;\n"\
                  "    padding: 0 16px;\n"\
                  "}\n"\
                  "\n"\
                  "@media only screen and (min-width: 680px) {\n"\
                  "    nav,\n"\
                  "    nav #menu {\n"\
                  "        height: 60px !important;\n"\
                  "    }\n"\
                  "    nav li,\n"\
                  "    nav a {\n"\
                  "        float: left;\n"\
                  "    }\n"\
                  "    nav ul.site {\n"\
                  "        float: left;\n"\
                  "        padding: 0;\n"\
                  "        clear: none;\n"\
                  "    }\n"\
                  "    nav ul.site li {\n"\
                  "        margin: 0 0 0 10px;\n"\
                  "    }\n"\
                  "    nav #menu-toggle {\n"\
                  "        display: none !important;\n"\
                  "    }\n"\
                  "    nav #menu {\n"\
                  "        max-height: 9999px;\n"\
                  "        clear: none;\n"\
                  "    }\n"\
                  "}\n"\
                  "\n"\
                  "\n"\
                  "/* Content Styles */\n"\
                  "\n"\
                  "section {\n"\
                  "    padding: 1em 0 3em;\n"\
                  "    text-align: center;\n"\
                  "}\n"\
                  "\n"\
                  "section.vibrant {\n"\
                  "    background: #222;\n"\
                  "    color: #fff;\n"\
                  "}\n"\
                  "\n"\
                  "nav:before,\n"\
                  "nav:after,\n"\
                  "header:before,\n"\
                  "header:after,\n"\
                  "section:before,\n"\
                  "section:after {\n"\
                  "    content: \" \";\n"\
                  "    display: table;\n"\
                  "}\n"\
                  "\n"\
                  "nav:after,\n"\
                  "header:after,\n"\
                  "section:after {\n"\
                  "    clear: both;\n"\
                  "}\n"\
                  "\n"\
                  "nav,\n"\
                  "header,\n"\
                  "section {\n"\
                  "    *zoom: 1;\n"\
                  "}\n"\
                  "\n"\
                  "\n"\
                  "/* Form Styles */\n"\
                  "\n"\
                  "input {\n"\
                  "    display: block;\n"\
                  "    vertical-align: middle;\n"\
                  "    line-height: 30px;\n"\
                  "    margin: 0 auto;\n"\
                  "    width: 100%;\n"\
                  "    max-width: 400px;\n"\
                  "    -moz-box-sizing: border-box;\n"\
                  "    -webkit-box-sizing: border-box;\n"\
                  "    box-sizing: border-box;\n"\
                  "    -webkit-transition: all linear 0.2s;\n"\
                  "    -moz-transition: all linear 0.2s;\n"\
                  "    -o-transition: all linear 0.2s;\n"\
                  "    transition: all linear 0.2s;\n"\
                  "}\n"\
                  "\n"\
                  "input:focus {\n"\
                  "    border-color: #007eb2;\n"\
                  "    outline: 0;\n"\
                  "}\n"\
                  "\n"\
                  ".docs-nav {\n"\
                  "    background-color: #f5f5f5;\n"\
                  "    list-style: none;\n"\
                  "    margin: 0 0 0 20px;\n"\
                  "    padding: 15px 20px;\n"\
                  "    font-size: 0.97em;\n"\
                  "}\n"\
                  "\n"\
                  ".docs-nav a {\n"\
                  "    display: block;\n"\
                  "    margin: 0 -20px;\n"\
                  "    padding: 0 20px;\n"\
                  "    text-decoration: none;\n"\
                  "    border-right: 2px solid transparent;\n"\
                  "}\n"\
                  "\n"\
                  "@media only screen and (min-width: 400px) {}\n"\
                  "\n"\
                  "@media only screen and (min-width: 600px) {}\n"\
                  "\n"\
                  "@media only screen and (min-width: 960px) {\n"\
                  "    .docs-nav {\n"\
                  "        position: absolute;\n"\
                  "        top: 0;\n"\
                  "        width: 220px;\n"\
                  "        -webkit-transition: top linear 50ms;\n"\
                  "        -moz-transition: top linear 50ms;\n"\
                  "        -o-transition: top linear 50ms;\n"\
                  "        transition: top linear 50ms;\n"\
                  "    }\n"\
                  "    .docs-nav.fixed {\n"\
                  "        position: fixed;\n"\
                  "        top: 49px;\n"\
                  "        width: 220px;\n"\
                  "    }\n"\
                  "    .docs-nav a:hover {\n"\
                  "        background: #eee;\n"\
                  "    }\n"\
                  "    .docs-nav a:active,\n"\
                  "    .docs-nav .active {\n"\
                  "        background: #eee;\n"\
                  "        border-right: 2px solid #ccc;\n"\
                  "    }\n"\
                  "    .docs-nav .separator {\n"\
                  "        height: 20px;\n"\
                  "    }\n"\
                  "    .docs-content {\n"\
                  "        padding-left: 310px;\n"\
                  "    }\n"\
                  "    header {\n"\
                  "        padding: 4em 0 4em 0;\n"\
                  "    }\n"\
                  "    .container {\n"\
                  "        max-width: 1000px;\n"\
                  "        padding: 0 20px;\n"\
                  "    }\n"\
                  "    section {\n"\
                  "        padding: 3em 0;\n"\
                  "        text-align: left;\n"\
                  "    }\n"\
                  "    section.centered {\n"\
                  "        text-align: center;\n"\
                  "    }\n"\
                  "    input {\n"\
                  "        display: inline-block;\n"\
                  "    }\n"\
                  "}\n"\
                  "");
  return data_string;
}