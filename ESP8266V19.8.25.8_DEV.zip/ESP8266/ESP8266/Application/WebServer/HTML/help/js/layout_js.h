String web_server_html::HTML_help_layout_js()
{
  String data_string;
  data_string = F(""
                  "$(document).ready(function () {\n"\
                  "var AFFIX_TOP_LIMIT = 300;\n"\
                  "var AFFIX_OFFSET = 49;\n"\
                  "$('#menu-left').localScroll({hash:true, onAfterFirst:function(){$('html, body').scrollTo( {top:'-=25px'}, 'fast' );}});\n"\
                  "var $menu = $(\"#menu\"),\n"\
                  "$btn = $(\"#menu-toggle\");\n"\
                  "\n"\
                  "$(\"#menu-toggle\").on(\"click\", function () {\n"\
                  "$menu.toggleClass(\"open\");\n"\
                  "return false;\n"\
                  "});\n"\
                  "\n"\
                  "\n"\
                  "$(\".docs-nav\").each(function () {\n"\
                  "var $affixNav = $(this),\n"\
                  "$container = $affixNav.parent(),\n"\
                  "affixNavfixed = false,\n"\
                  "originalClassName = this.className,\n"\
                  "current = null,\n"\
                  "$links = $affixNav.find(\"a\");\n"\
                  "\n"\
                  "function getClosestHeader(top) {\n"\
                  "var last = $links.first();\n"\
                  "\n"\
                  "if (top < AFFIX_TOP_LIMIT) {\n"\
                  "return last;\n"\
                  "}\n"\
                  "\n"\
                  "for (var i = 0; i < $links.length; i++) {\n"\
                  "var $link = $links.eq(i),\n"\
                  "href = $link.attr(\"href\");\n"\
                  "\n"\
                  "if (href.charAt(0) === \"#\" && href.length > 1) {\n"\
                  "var $anchor = $(href).first();\n"\
                  "\n"\
                  "if ($anchor.length > 0) {\n"\
                  "var offset = $anchor.offset();\n"\
                  "\n"\
                  "if (top < offset.top - AFFIX_OFFSET) {\n"\
                  "return last;\n"\
                  "}\n"\
                  "\n"\
                  "last = $link;\n"\
                  "}\n"\
                  "}\n"\
                  "}\n"\
                  "return last;\n"\
                  "}\n"\
                  "\n"\
                  "\n"\
                  "$(window).on(\"scroll\", function (evt) {\n"\
                  "var top = window.scrollY,\n"\
                  "height = $affixNav.outerHeight(),\n"\
                  "max_bottom = $container.offset().top + $container.outerHeight(),\n"\
                  "bottom = top + height + AFFIX_OFFSET;\n"\
                  "\n"\
                  "if (affixNavfixed) {\n"\
                  "if (top <= AFFIX_TOP_LIMIT) {\n"\
                  "$affixNav.removeClass(\"fixed\");\n"\
                  "$affixNav.css(\"top\", 0);\n"\
                  "affixNavfixed = false;\n"\
                  "} else if (bottom > max_bottom) {\n"\
                  "$affixNav.css(\"top\", (max_bottom - height) - top);\n"\
                  "} else {\n"\
                  "$affixNav.css(\"top\", AFFIX_OFFSET);\n"\
                  "}\n"\
                  "} else if (top > AFFIX_TOP_LIMIT) {\n"\
                  "$affixNav.addClass(\"fixed\");\n"\
                  "affixNavfixed = true;\n"\
                  "}\n"\
                  "\n"\
                  "var $current = getClosestHeader(top);\n"\
                  "\n"\
                  "if (current !== $current) {\n"\
                  "$affixNav.find(\".active\").removeClass(\"active\");\n"\
                  "$current.addClass(\"active\");\n"\
                  "current = $current;\n"\
                  "}\n"\
                  "});\n"\
                  "});\n"\
                  "\n"\
                  "prettyPrint();\n"\
                  "});\n"\
                  "\n"\
                  "");
  return data_string;
}