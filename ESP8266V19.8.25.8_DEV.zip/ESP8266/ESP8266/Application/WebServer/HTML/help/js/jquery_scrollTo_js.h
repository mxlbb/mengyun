String web_server_html::HTML_help_jquery_scrollTo_js()
{
  String data_string;
  data_string = F(""
                  ";(function( $ ){\n"\
                  "\n"\
                  "var $scrollTo = $.scrollTo = function( target, duration, settings ){\n"\
                  "$(window).scrollTo( target, duration, settings );\n"\
                  "};\n"\
                  "\n"\
                  "$scrollTo.defaults = {\n"\
                  "axis:'xy',\n"\
                  "duration: parseFloat($.fn.jquery) >= 1.3 ? 0 : 1,\n"\
                  "limit:true\n"\
                  "};\n"\
                  "\n"\
                  "$scrollTo.window = function( scope ){\n"\
                  "return $(window)._scrollable();\n"\
                  "};\n"\
                  "\n"\
                  "$.fn._scrollable = function(){\n"\
                  "return this.map(function(){\n"\
                  "var elem = this,\n"\
                  "isWin = !elem.nodeName || $.inArray( elem.nodeName.toLowerCase(), ['iframe','#document','html','body'] ) != -1;\n"\
                  "\n"\
                  "if( !isWin )\n"\
                  "return elem;\n"\
                  "\n"\
                  "var doc = (elem.contentWindow || elem).document || elem.ownerDocument || elem;\n"\
                  "\n"\
                  "return /webkit/i.test(navigator.userAgent) || doc.compatMode == 'BackCompat' ?\n"\
                  "doc.body : \n"\
                  "doc.documentElement;\n"\
                  "});\n"\
                  "};\n"\
                  "\n"\
                  "$.fn.scrollTo = function( target, duration, settings ){\n"\
                  "if( typeof duration == 'object' ){\n"\
                  "settings = duration;\n"\
                  "duration = 0;\n"\
                  "}\n"\
                  "if( typeof settings == 'function' )\n"\
                  "settings = { onAfter:settings };\n"\
                  "\n"\
                  "if( target == 'max' )\n"\
                  "target = 9e9;\n"\
                  "\n"\
                  "settings = $.extend( {}, $scrollTo.defaults, settings );\n"\
                  "duration = duration || settings.duration;\n"\
                  "settings.queue = settings.queue && settings.axis.length > 1;\n"\
                  "\n"\
                  "if( settings.queue )\n"\
                  "duration /= 2;\n"\
                  "settings.offset = both( settings.offset );\n"\
                  "settings.over = both( settings.over );\n"\
                  "\n"\
                  "return this._scrollable().each(function(){\n"\
                  "if (target == null) return;\n"\
                  "\n"\
                  "var elem = this,\n"\
                  "$elem = $(elem),\n"\
                  "targ = target, toff, attr = {},\n"\
                  "win = $elem.is('html,body');\n"\
                  "\n"\
                  "switch( typeof targ ){\n"\
                  "case 'number':\n"\
                  "case 'string':\n"\
                  "if( /^([+-]=)?\\d+(\\.\\d+)?(px|%)?$/.test(targ) ){\n"\
                  "targ = both( targ );\n"\
                  "break;\n"\
                  "}\n"\
                  "targ = $(targ,this);\n"\
                  "if (!targ.length) return;\n"\
                  "case 'object':\n"\
                  "if( targ.is || targ.style )\n"\
                  "toff = (targ = $(targ)).offset();\n"\
                  "}\n"\
                  "$.each( settings.axis.split(''), function( i, axis ){\n"\
                  "var Pos  = axis == 'x' ? 'Left' : 'Top',\n"\
                  "pos = Pos.toLowerCase(),\n"\
                  "key = 'scroll' + Pos,\n"\
                  "old = elem[key],\n"\
                  "max = $scrollTo.max(elem, axis);\n"\
                  "\n"\
                  "if( toff ){\n"\
                  "attr[key] = toff[pos] + ( win ? 0 : old - $elem.offset()[pos] );\n"\
                  "\n"\
                  "if( settings.margin ){\n"\
                  "attr[key] -= parseInt(targ.css('margin'+Pos)) || 0;\n"\
                  "attr[key] -= parseInt(targ.css('border'+Pos+'Width')) || 0;\n"\
                  "}\n"\
                  "\n"\
                  "attr[key] += settings.offset[pos] || 0;\n"\
                  "\n"\
                  "if( settings.over[pos] )\n"\
                  "// Scroll to a fraction of its width/height\n"\
                  "attr[key] += targ[axis=='x'?'width':'height']() * settings.over[pos];\n"\
                  "}else{ \n"\
                  "var val = targ[pos];\n"\
                  "attr[key] = val.slice && val.slice(-1) == '%' ? \n"\
                  "parseFloat(val) / 100 * max\n"\
                  ": val;\n"\
                  "}\n"\
                  "\n"\
                  "if( settings.limit && /^\\d+$/.test(attr[key]) )\n"\
                  "attr[key] = attr[key] <= 0 ? 0 : Math.min( attr[key], max );\n"\
                  "\n"\
                  "if( !i && settings.queue ){\n"\
                  "if( old != attr[key] )\n"\
                  "animate( settings.onAfterFirst );\n"\
                  "delete attr[key];\n"\
                  "}\n"\
                  "});\n"\
                  "\n"\
                  "animate( settings.onAfter );     \n"\
                  "\n"\
                  "function animate( callback ){\n"\
                  "$elem.animate( attr, duration, settings.easing, callback && function(){\n"\
                  "callback.call(this, target, settings);\n"\
                  "});\n"\
                  "};\n"\
                  "\n"\
                  "}).end();\n"\
                  "};\n"\
                  "\n"\
                  "$scrollTo.max = function( elem, axis ){\n"\
                  "var Dim = axis == 'x' ? 'Width' : 'Height',\n"\
                  "scroll = 'scroll'+Dim;\n"\
                  "\n"\
                  "if( !$(elem).is('html,body') )\n"\
                  "return elem[scroll] - $(elem)[Dim.toLowerCase()]();\n"\
                  "\n"\
                  "var size = 'client' + Dim,\n"\
                  "html = elem.ownerDocument.documentElement,\n"\
                  "body = elem.ownerDocument.body;\n"\
                  "\n"\
                  "return Math.max( html[scroll], body[scroll] ) \n"\
                  " - Math.min( html[size]  , body[size]   );\n"\
                  "};\n"\
                  "\n"\
                  "function both( val ){\n"\
                  "return typeof val == 'object' ? val : { top:val, left:val };\n"\
                  "};\n"\
                  "\n"\
                  "})( jQuery );\n"\
                  "");
  return data_string;
}