String web_server_html::HTML_help_prettify_js()
{
  String data_string;
  data_string = F(""
                  "!function() {\n"\
                  "var q = null;\n"\
                  "window.PR_SHOULD_USE_CONTINUATION = !0; (function() {\n"\
                  "function S(a) {\n"\
                  "function d(e) {\n"\
                  "var b = e.charCodeAt(0);\n"\
                  "if (b !== 92) return b;\n"\
                  "var a = e.charAt(1);\n"\
                  "return (b = r[a]) ? b: \"0\" <= a && a <= \"7\" ? parseInt(e.substring(1), 8) : a === \"u\" || a === \"x\" ? parseInt(e.substring(2), 16) : e.charCodeAt(1)\n"\
                  "}\n"\
                  "function g(e) {\n"\
                  "if (e < 32) return (e < 16 ? \"\\\\x0\": \"\\\\x\") + e.toString(16);\n"\
                  "e = String.fromCharCode(e);\n"\
                  "return e === \"\\\\\" || e === \"-\" || e === \"]\" || e === \"^\" ? \"\\\\\" + e: e\n"\
                  "}\n"\
                  "function b(e) {\n"\
                  "var b = e.substring(1, e.length - 1).match(/\\\\u[\\dA-Fa-f]{4}|\\\\x[\\dA-Fa-f]{2}|\\\\[0-3][0-7]{0,2}|\\\\[0-7]{1,2}|\\\\[\\S\\s]|[^\\\\]/g),\n"\
                  "e = [],\n"\
                  "a = b[0] === \"^\",\n"\
                  "c = [\"[\"];\n"\
                  "a && c.push(\"^\");\n"\
                  "for (var a = a ? 1 : 0, f = b.length; a < f; ++a) {\n"\
                  "var h = b[a];\n"\
                  "if (/\\\\[bdsw]/i.test(h)) c.push(h);\n"\
                  "else {\n"\
                  "var h = d(h),\n"\
                  "l;\n"\
                  "a + 2 < f && \"-\" === b[a + 1] ? (l = d(b[a + 2]), a += 2) : l = h;\n"\
                  "e.push([h, l]);\n"\
                  "l < 65 || h > 122 || (l < 65 || h > 90 || e.push([Math.max(65, h) | 32, Math.min(l, 90) | 32]), l < 97 || h > 122 || e.push([Math.max(97, h) & -33, Math.min(l, 122) & -33]))\n"\
                  "}\n"\
                  "}\n"\
                  "e.sort(function(e, a) {\n"\
                  "return e[0] - a[0] || a[1] - e[1]\n"\
                  "});\n"\
                  "b = [];\n"\
                  "f = [];\n"\
                  "for (a = 0; a < e.length; ++a) h = e[a],\n"\
                  "h[0] <= f[1] + 1 ? f[1] = Math.max(f[1], h[1]) : b.push(f = h);\n"\
                  "for (a = 0; a < b.length; ++a) h = b[a],\n"\
                  "c.push(g(h[0])),\n"\
                  "h[1] > h[0] && (h[1] + 1 > h[0] && c.push(\"-\"), c.push(g(h[1])));\n"\
                  "c.push(\"]\");\n"\
                  "return c.join(\"\")\n"\
                  "}\n"\
                  "function s(e) {\n"\
                  "for (var a = e.source.match(/\\[(?:[^\\\\\\]]|\\\\[\\S\\s])*]|\\\\u[\\dA-Fa-f]{4}|\\\\x[\\dA-Fa-f]{2}|\\\\\\d+|\\\\[^\\dux]|\\(\\?[!:=]|[()^]|[^()[\\\\^]+/g), c = a.length, d = [], f = 0, h = 0; f < c; ++f) {\n"\
                  "var l = a[f];\n"\
                  "l === \"(\" ? ++h: \"\\\\\" === l.charAt(0) && (l = +l.substring(1)) && (l <= h ? d[l] = -1 : a[f] = g(l))\n"\
                  "}\n"\
                  "for (f = 1; f < d.length; ++f) - 1 === d[f] && (d[f] = ++x);\n"\
                  "for (h = f = 0; f < c; ++f) l = a[f],\n"\
                  "l === \"(\" ? (++h, d[h] || (a[f] = \"(?:\")) : \"\\\\\" === l.charAt(0) && (l = +l.substring(1)) && l <= h && (a[f] = \"\\\\\" + d[l]);\n"\
                  "for (f = 0; f < c; ++f)\"^\" === a[f] && \"^\" !== a[f + 1] && (a[f] = \"\");\n"\
                  "if (e.ignoreCase && m) for (f = 0; f < c; ++f) l = a[f],\n"\
                  "e = l.charAt(0),\n"\
                  "l.length >= 2 && e === \"[\" ? a[f] = b(l) : e !== \"\\\\\" && (a[f] = l.replace(/[A-Za-z]/g,\n"\
                  "function(a) {\n"\
                  "a = a.charCodeAt(0);\n"\
                  "return \"[\" + String.fromCharCode(a & -33, a | 32) + \"]\"\n"\
                  "}));\n"\
                  "return a.join(\"\")\n"\
                  "}\n"\
                  "for (var x = 0,\n"\
                  "m = !1,\n"\
                  "j = !1,\n"\
                  "k = 0,\n"\
                  "c = a.length; k < c; ++k) {\n"\
                  "var i = a[k];\n"\
                  "if (i.ignoreCase) j = !0;\n"\
                  "else if (/[a-z]/i.test(i.source.replace(/\\\\u[\\da-f]{4}|\\\\x[\\da-f]{2}|\\\\[^UXux]/gi, \"\"))) {\n"\
                  "m = !0;\n"\
                  "j = !1;\n"\
                  "break\n"\
                  "}\n"\
                  "}\n"\
                  "for (var r = {\n"\
                  "b: 8,\n"\
                  "t: 9,\n"\
                  "n: 10,\n"\
                  "v: 11,\n"\
                  "f: 12,\n"\
                  "r: 13\n"\
                  "},\n"\
                  "n = [], k = 0, c = a.length; k < c; ++k) {\n"\
                  "i = a[k];\n"\
                  "if (i.global || i.multiline) throw Error(\"\" + i);\n"\
                  "n.push(\"(?:\" + s(i) + \")\")\n"\
                  "}\n"\
                  "return RegExp(n.join(\"|\"), j ? \"gi\": \"g\")\n"\
                  "}\n"\
                  "function T(a, d) {\n"\
                  "function g(a) {\n"\
                  "var c = a.nodeType;\n"\
                  "if (c == 1) {\n"\
                  "if (!b.test(a.className)) {\n"\
                  "for (c = a.firstChild; c; c = c.nextSibling) g(c);\n"\
                  "c = a.nodeName.toLowerCase();\n"\
                  "if (\"br\" === c || \"li\" === c) s[j] = \"\\n\",\n"\
                  "m[j << 1] = x++,\n"\
                  "m[j++<<1 | 1] = a\n"\
                  "}\n"\
                  "} else if (c == 3 || c == 4) c = a.nodeValue,\n"\
                  "c.length && (c = d ? c.replace(/\\r\\n?/g, \"\\n\") : c.replace(/[\\t\\n\\r ]+/g, \" \"), s[j] = c, m[j << 1] = x, x += c.length, m[j++<<1 | 1] = a)\n"\
                  "}\n"\
                  "var b = /(?:^|\\s)nocode(?:\\s|$)/,\n"\
                  "s = [],\n"\
                  "x = 0,\n"\
                  "m = [],\n"\
                  "j = 0;\n"\
                  "g(a);\n"\
                  "return {\n"\
                  "a: s.join(\"\").replace(/\\n$/, \"\"),\n"\
                  "d: m\n"\
                  "}\n"\
                  "}\n"\
                  "function H(a, d, g, b) {\n"\
                  "d && (a = {\n"\
                  "a: d,\n"\
                  "e: a\n"\
                  "},\n"\
                  "g(a), b.push.apply(b, a.g))\n"\
                  "}\n"\
                  "function U(a) {\n"\
                  "for (var d = void 0,\n"\
                  "g = a.firstChild; g; g = g.nextSibling) var b = g.nodeType,\n"\
                  "d = b === 1 ? d ? a: g: b === 3 ? V.test(g.nodeValue) ? a: d: d;\n"\
                  "return d === a ? void 0 : d\n"\
                  "}\n"\
                  "function C(a, d) {\n"\
                  "function g(a) {\n"\
                  "for (var j = a.e,\n"\
                  "k = [j, \"pln\"], c = 0, i = a.a.match(s) || [], r = {},\n"\
                  "n = 0, e = i.length; n < e; ++n) {\n"\
                  "var z = i[n],\n"\
                  "w = r[z],\n"\
                  "t = void 0,\n"\
                  "f;\n"\
                  "if (typeof w === \"string\") f = !1;\n"\
                  "else {\n"\
                  "var h = b[z.charAt(0)];\n"\
                  "if (h) t = z.match(h[1]),\n"\
                  "w = h[0];\n"\
                  "else {\n"\
                  "for (f = 0; f < x; ++f) if (h = d[f], t = z.match(h[1])) {\n"\
                  "w = h[0];\n"\
                  "break\n"\
                  "}\n"\
                  "t || (w = \"pln\")\n"\
                  "}\n"\
                  "if ((f = w.length >= 5 && \"lang-\" === w.substring(0, 5)) && !(t && typeof t[1] === \"string\")) f = !1,\n"\
                  "w = \"src\";\n"\
                  "f || (r[z] = w)\n"\
                  "}\n"\
                  "h = c;\n"\
                  "c += z.length;\n"\
                  "if (f) {\n"\
                  "f = t[1];\n"\
                  "var l = z.indexOf(f),\n"\
                  "B = l + f.length;\n"\
                  "t[2] && (B = z.length - t[2].length, l = B - f.length);\n"\
                  "w = w.substring(5);\n"\
                  "H(j + h, z.substring(0, l), g, k);\n"\
                  "H(j + h + l, f, I(w, f), k);\n"\
                  "H(j + h + B, z.substring(B), g, k)\n"\
                  "} else k.push(j + h, w)\n"\
                  "}\n"\
                  "a.g = k\n"\
                  "}\n"\
                  "var b = {},\n"\
                  "s; (function() {\n"\
                  "for (var g = a.concat(d), j = [], k = {},\n"\
                  "c = 0, i = g.length; c < i; ++c) {\n"\
                  "var r = g[c],\n"\
                  "n = r[3];\n"\
                  "if (n) for (var e = n.length; --e >= 0;) b[n.charAt(e)] = r;\n"\
                  "r = r[1];\n"\
                  "n = \"\" + r;\n"\
                  "k.hasOwnProperty(n) || (j.push(r), k[n] = q)\n"\
                  "}\n"\
                  "j.push(/[\\S\\s]/);\n"\
                  "s = S(j)\n"\
                  "})();\n"\
                  "var x = d.length;\n"\
                  "return g\n"\
                  "}\n"\
                  "function v(a) {\n"\
                  "var d = [],\n"\
                  "g = [];\n"\
                  "a.tripleQuotedStrings ? d.push([\"str\", /^(?:'''(?:[^'\\\\]|\\\\[\\S\\s]|''?(?=[^']))*(?:'''|$)|\"\"\"(?:[^\"\\\\]|\\\\[\\S\\s]|\"\"?(?=[^\"]))*(?:\"\"\"|$)|'(?:[^'\\\\]|\\\\[\\S\\s])*(?:'|$)|\"(?:[^\"\\\\]|\\\\[\\S\\s])*(?:\"|$))/, q, \"'\\\"\"]) : a.multiLineStrings ? d.push([\"str\", /^(?:'(?:[^'\\\\]|\\\\[\\S\\s])*(?:'|$)|\"(?:[^\"\\\\]|\\\\[\\S\\s])*(?:\"|$)|`(?:[^\\\\`]|\\\\[\\S\\s])*(?:`|$))/, q, \"'\\\"`\"]) : d.push([\"str\", /^(?:'(?:[^\\n\\r'\\\\]|\\\\.)*(?:'|$)|\"(?:[^\\n\\r\"\\\\]|\\\\.)*(?:\"|$))/, q, \"\\\"'\"]);\n"\
                  "a.verbatimStrings && g.push([\"str\", /^@\"(?:[^\"]|\"\")*(?:\"|$)/, q]);\n"\
                  "var b = a.hashComments;\n"\
                  "b && (a.cStyleComments ? (b > 1 ? d.push([\"com\", /^#(?:##(?:[^#]|#(?!##))*(?:###|$)|.*)/, q, \"#\"]) : d.push([\"com\", /^#(?:(?:define|e(?:l|nd)if|else|error|ifn?def|include|line|pragma|undef|warning)\\b|[^\\n\\r]*)/, q, \"#\"]), g.push([\"str\", /^<(?:(?:(?:\\.\\.\\/)*|\\/?)(?:[\\w-]+(?:\\/[\\w-]+)+)?[\\w-]+\\.h(?:h|pp|\\+\\+)?|[a-z]\\w*)>/, q])) : d.push([\"com\", /^#[^\\n\\r]*/, q, \"#\"]));\n"\
                  "a.cStyleComments && (g.push([\"com\", /^\\/\\/[^\\n\\r]*/, q]), g.push([\"com\", /^\\/\\*[\\S\\s]*?(?:\\*\\/|$)/, q]));\n"\
                  "if (b = a.regexLiterals) {\n"\
                  "var s = (b = b > 1 ? \"\": \"\\n\\r\") ? \".\": \"[\\\\S\\\\s]\";\n"\
                  "g.push([\"lang-regex\", RegExp(\"^(?:^^\\\\.?|[+-]|[!=]=?=?|\\\\#|%=?|&&?=?|\\\\(|\\\\*=?|[+\\\\-]=|->|\\\\/=?|::?|<<?=?|>>?>?=?|,|;|\\\\?|@|\\\\[|~|{|\\\\^\\\\^?=?|\\\\|\\\\|?=?|break|case|continue|delete|do|else|finally|instanceof|return|throw|try|typeof)\\\\s*(\" + (\"/(?=[^/*\" + b + \"])(?:[^/\\\\x5B\\\\x5C\" + b + \"]|\\\\x5C\" + s + \"|\\\\x5B(?:[^\\\\x5C\\\\x5D\" + b + \"]|\\\\x5C\" + s + \")*(?:\\\\x5D|$))+/\") + \")\")])\n"\
                  "} (b = a.types) && g.push([\"typ\", b]);\n"\
                  "b = (\"\" + a.keywords).replace(/^ | $/g, \"\");\n"\
                  "b.length && g.push([\"kwd\", RegExp(\"^(?:\" + b.replace(/[\\s,]+/g, \"|\") + \")\\\\b\"), q]);\n"\
                  "d.push([\"pln\", /^\\s+/, q, \" \\r\\n\\t\\u00a0\"]);\n"\
                  "b = \"^.[^\\\\s\\\\w.$@'\\\"`/\\\\\\\\]*\";\n"\
                  "a.regexLiterals && (b += \"(?!s*/)\");\n"\
                  "g.push([\"lit\", /^@[$_a-z][\\w$@]*/i, q], [\"typ\", /^(?:[@_]?[A-Z]+[a-z][\\w$@]*|\\w+_t\\b)/, q], [\"pln\", /^[$_a-z][\\w$@]*/i, q], [\"lit\", /^(?:0x[\\da-f]+|(?:\\d(?:_\\d+)*\\d*(?:\\.\\d*)?|\\.\\d\\+)(?:e[+-]?\\d+)?)[a-z]*/i, q, \"0123456789\"], [\"pln\", /^\\\\[\\S\\s]?/, q], [\"pun\", RegExp(b), q]);\n"\
                  "return C(d, g)\n"\
                  "}\n"\
                  "function J(a, d, g) {\n"\
                  "function b(a) {\n"\
                  "var c = a.nodeType;\n"\
                  "if (c == 1 && !x.test(a.className)) if (\"br\" === a.nodeName) s(a),\n"\
                  "a.parentNode && a.parentNode.removeChild(a);\n"\
                  "else for (a = a.firstChild; a; a = a.nextSibling) b(a);\n"\
                  "else if ((c == 3 || c == 4) && g) {\n"\
                  "var d = a.nodeValue,\n"\
                  "i = d.match(m);\n"\
                  "if (i) c = d.substring(0, i.index),\n"\
                  "a.nodeValue = c,\n"\
                  "(d = d.substring(i.index + i[0].length)) && a.parentNode.insertBefore(j.createTextNode(d), a.nextSibling),\n"\
                  "s(a),\n"\
                  "c || a.parentNode.removeChild(a)\n"\
                  "}\n"\
                  "}\n"\
                  "function s(a) {\n"\
                  "function b(a, c) {\n"\
                  "var d = c ? a.cloneNode(!1) : a,\n"\
                  "e = a.parentNode;\n"\
                  "if (e) {\n"\
                  "var e = b(e, 1),\n"\
                  "g = a.nextSibling;\n"\
                  "e.appendChild(d);\n"\
                  "for (var i = g; i; i = g) g = i.nextSibling,\n"\
                  "e.appendChild(i)\n"\
                  "}\n"\
                  "return d\n"\
                  "}\n"\
                  "for (; ! a.nextSibling;) if (a = a.parentNode, !a) return;\n"\
                  "for (var a = b(a.nextSibling, 0), d; (d = a.parentNode) && d.nodeType === 1;) a = d;\n"\
                  "c.push(a)\n"\
                  "}\n"\
                  "for (var x = /(?:^|\\s)nocode(?:\\s|$)/,\n"\
                  "m = /\\r\\n?|\\n/,\n"\
                  "j = a.ownerDocument,\n"\
                  "k = j.createElement(\"li\"); a.firstChild;) k.appendChild(a.firstChild);\n"\
                  "for (var c = [k], i = 0; i < c.length; ++i) b(c[i]);\n"\
                  "d === (d | 0) && c[0].setAttribute(\"value\", d);\n"\
                  "var r = j.createElement(\"ol\");\n"\
                  "r.className = \"linenums\";\n"\
                  "for (var d = Math.max(0, d - 1 | 0) || 0, i = 0, n = c.length; i < n; ++i) k = c[i],\n"\
                  "k.className = \"L\" + (i + d) % 10,\n"\
                  "k.firstChild || k.appendChild(j.createTextNode(\"\\u00a0\")),\n"\
                  "r.appendChild(k);\n"\
                  "a.appendChild(r)\n"\
                  "}\n"\
                  "function p(a, d) {\n"\
                  "for (var g = d.length; --g >= 0;) {\n"\
                  "var b = d[g];\n"\
                  "F.hasOwnProperty(b) ? D.console && console.warn(\"cannot override language handler %s\", b) : F[b] = a\n"\
                  "}\n"\
                  "}\n"\
                  "function I(a, d) {\n"\
                  "if (!a || !F.hasOwnProperty(a)) a = /^\\s*</.test(d) ? \"default-markup\": \"default-code\";\n"\
                  "return F[a]\n"\
                  "}\n"\
                  "function K(a) {\n"\
                  "var d = a.h;\n"\
                  "try {\n"\
                  "var g = T(a.c, a.i),\n"\
                  "b = g.a;\n"\
                  "a.a = b;\n"\
                  "a.d = g.d;\n"\
                  "a.e = 0;\n"\
                  "I(d, b)(a);\n"\
                  "var s = /\\bMSIE\\s(\\d+)/.exec(navigator.userAgent),\n"\
                  "s = s && +s[1] <= 8,\n"\
                  "d = /\\n/g,\n"\
                  "x = a.a,\n"\
                  "m = x.length,\n"\
                  "g = 0,\n"\
                  "j = a.d,\n"\
                  "k = j.length,\n"\
                  "b = 0,\n"\
                  "c = a.g,\n"\
                  "i = c.length,\n"\
                  "r = 0;\n"\
                  "c[i] = m;\n"\
                  "var n, e;\n"\
                  "for (e = n = 0; e < i;) c[e] !== c[e + 2] ? (c[n++] = c[e++], c[n++] = c[e++]) : e += 2;\n"\
                  "i = n;\n"\
                  "for (e = n = 0; e < i;) {\n"\
                  "for (var p = c[e], w = c[e + 1], t = e + 2; t + 2 <= i && c[t + 1] === w;) t += 2;\n"\
                  "c[n++] = p;\n"\
                  "c[n++] = w;\n"\
                  "e = t\n"\
                  "}\n"\
                  "c.length = n;\n"\
                  "var f = a.c,\n"\
                  "h;\n"\
                  "if (f) h = f.style.display,\n"\
                  "f.style.display = \"none\";\n"\
                  "try {\n"\
                  "for (; b < k;) {\n"\
                  "var l = j[b + 2] || m,\n"\
                  "B = c[r + 2] || m,\n"\
                  "t = Math.min(l, B),\n"\
                  "A = j[b + 1],\n"\
                  "G;\n"\
                  "if (A.nodeType !== 1 && (G = x.substring(g, t))) {\n"\
                  "s && (G = G.replace(d, \"\\r\"));\n"\
                  "A.nodeValue = G;\n"\
                  "var L = A.ownerDocument,\n"\
                  "o = L.createElement(\"span\");\n"\
                  "o.className = c[r + 1];\n"\
                  "var v = A.parentNode;\n"\
                  "v.replaceChild(o, A);\n"\
                  "o.appendChild(A);\n"\
                  "g < l && (j[b + 1] = A = L.createTextNode(x.substring(t, l)), v.insertBefore(A, o.nextSibling))\n"\
                  "}\n"\
                  "g = t;\n"\
                  "g >= l && (b += 2);\n"\
                  "g >= B && (r += 2)\n"\
                  "}\n"\
                  "} finally {\n"\
                  "if (f) f.style.display = h\n"\
                  "}\n"\
                  "} catch(u) {\n"\
                  "D.console && console.log(u && u.stack || u)\n"\
                  "}\n"\
                  "}\n"\
                  "var D = window,\n"\
                  "y = [\"break,continue,do,else,for,if,return,while\"],\n"\
                  "E = [[y, \"auto,case,char,const,default,double,enum,extern,float,goto,inline,int,long,register,short,signed,sizeof,static,struct,switch,typedef,union,unsigned,void,volatile\"], \"catch,class,delete,false,import,new,operator,private,protected,public,this,throw,true,try,typeof\"],\n"\
                  "M = [E, \"alignof,align_union,asm,axiom,bool,concept,concept_map,const_cast,constexpr,decltype,delegate,dynamic_cast,explicit,export,friend,generic,late_check,mutable,namespace,nullptr,property,reinterpret_cast,static_assert,static_cast,template,typeid,typename,using,virtual,where\"],\n"\
                  "N = [E, \"abstract,assert,boolean,byte,extends,final,finally,implements,import,instanceof,interface,null,native,package,strictfp,super,synchronized,throws,transient\"],\n"\
                  "O = [N, \"as,base,by,checked,decimal,delegate,descending,dynamic,event,fixed,foreach,from,group,implicit,in,internal,into,is,let,lock,object,out,override,orderby,params,partial,readonly,ref,sbyte,sealed,stackalloc,string,select,uint,ulong,unchecked,unsafe,ushort,var,virtual,where\"],\n"\
                  "E = [E, \"debugger,eval,export,function,get,null,set,undefined,var,with,Infinity,NaN\"],\n"\
                  "P = [y, \"and,as,assert,class,def,del,elif,except,exec,finally,from,global,import,in,is,lambda,nonlocal,not,or,pass,print,raise,try,with,yield,False,True,None\"],\n"\
                  "Q = [y, \"alias,and,begin,case,class,def,defined,elsif,end,ensure,false,in,module,next,nil,not,or,redo,rescue,retry,self,super,then,true,undef,unless,until,when,yield,BEGIN,END\"],\n"\
                  "W = [y, \"as,assert,const,copy,drop,enum,extern,fail,false,fn,impl,let,log,loop,match,mod,move,mut,priv,pub,pure,ref,self,static,struct,true,trait,type,unsafe,use\"],\n"\
                  "y = [y, \"case,done,elif,esac,eval,fi,function,in,local,set,then,until\"],\n"\
                  "R = /^(DIR|FILE|vector|(de|priority_)?queue|list|stack|(const_)?iterator|(multi)?(set|map)|bitset|u?(int|float)\\d*)\\b/,\n"\
                  "V = /\\S/,\n"\
                  "X = v({\n"\
                  "keywords: [M, O, E, \"caller,delete,die,do,dump,elsif,eval,exit,foreach,for,goto,if,import,last,local,my,next,no,our,print,package,redo,require,sub,undef,unless,until,use,wantarray,while,BEGIN,END\", P, Q, y],\n"\
                  "hashComments: !0,\n"\
                  "cStyleComments: !0,\n"\
                  "multiLineStrings: !0,\n"\
                  "regexLiterals: !0\n"\
                  "}),\n"\
                  "F = {};\n"\
                  "p(X, [\"default-code\"]);\n"\
                  "p(C([], [[\"pln\", /^[^<?]+/], [\"dec\", /^<!\\w[^>]*(?:>|$)/], [\"com\", /^<\\!--[\\S\\s]*?(?:--\\>|$)/], [\"lang-\", /^<\\?([\\S\\s]+?)(?:\\?>|$)/], [\"lang-\", /^<%([\\S\\s]+?)(?:%>|$)/], [\"pun\", /^(?:<[%?]|[%?]>)/], [\"lang-\", /^<xmp\\b[^>]*>([\\S\\s]+?)<\\/xmp\\b[^>]*>/i], [\"lang-js\", /^<script\\b[^>]*>([\\S\\s]*?)(<\\/script\\b[^>]*>)/i], [\"lang-css\", /^<style\\b[^>]*>([\\S\\s]*?)(<\\/style\\b[^>]*>)/i], [\"lang-in.tag\", /^(<\\/?[a-z][^<>]*>)/i]]), [\"default-markup\", \"htm\", \"html\", \"mxml\", \"xhtml\", \"xml\", \"xsl\"]);\n"\
                  "p(C([[\"pln\", /^\\s+/, q, \" \\t\\r\\n\"], [\"atv\", /^(?:\"[^\"]*\"?|'[^']*'?)/, q, \"\\\"'\"]], [[\"tag\", /^^<\\/?[a-z](?:[\\w-.:]*\\w)?|\\/?>$/i], [\"atn\", /^(?!style[\\s=]|on)[a-z](?:[\\w:-]*\\w)?/i], [\"lang-uq.val\", /^=\\s*([^\\s\"'>]*(?:[^\\s\"'/ > ] | \\ / ( ? =\\s))) / ],\n"\
                  "[\"pun\", /^[/ < ->] + /],\n"\
                  "[\"lang-js\",/ ^ on\\w + \\s *= \\s * \"([^\"] + )\"/i],[\"lang - js \",/^on\\w+\\s*=\\s*'([^']+)'/i],[\"lang - js \",/^on\\w+\\s*=\\s*([^\\s\"'>]+)/i],[\"lang-css\",/^style\\s*=\\s*\"([^\"]+)\"/i],[\"lang-css\",/^style\\s*=\\s*' ([ ^ ']+)' / i], [\"lang-css\", /^style\\s*=\\s*([^\\s\"'>]+)/i]]),\n"\
                  "[\"in.tag\"]);\n"\
                  "p(C([], [[\"atv\", /^[\\S\\s]+/]]), [\"uq.val\"]);\n"\
                  "p(v({\n"\
                  "keywords: M,\n"\
                  "hashComments: !0,\n"\
                  "cStyleComments: !0,\n"\
                  "types: R\n"\
                  "}), [\"c\", \"cc\", \"cpp\", \"cxx\", \"cyc\", \"m\"]);\n"\
                  "p(v({\n"\
                  "keywords: \"null,true,false\"\n"\
                  "}), [\"json\"]);\n"\
                  "p(v({\n"\
                  "keywords: O,\n"\
                  "hashComments: !0,\n"\
                  "cStyleComments: !0,\n"\
                  "verbatimStrings: !0,\n"\
                  "types: R\n"\
                  "}), [\"cs\"]);\n"\
                  "p(v({\n"\
                  "keywords: N,\n"\
                  "cStyleComments: !0\n"\
                  "}), [\"java\"]);\n"\
                  "p(v({\n"\
                  "keywords: y,\n"\
                  "hashComments: !0,\n"\
                  "multiLineStrings: !0\n"\
                  "}), [\"bash\", \"bsh\", \"csh\", \"sh\"]);\n"\
                  "p(v({\n"\
                  "keywords: P,\n"\
                  "hashComments: !0,\n"\
                  "multiLineStrings: !0,\n"\
                  "tripleQuotedStrings: !0\n"\
                  "}), [\"cv\", \"py\", \"python\"]);\n"\
                  "p(v({\n"\
                  "keywords: \"caller,delete,die,do,dump,elsif,eval,exit,foreach,for,goto,if,import,last,local,my,next,no,our,print,package,redo,require,sub,undef,unless,until,use,wantarray,while,BEGIN,END\",\n"\
                  "hashComments: !0,\n"\
                  "multiLineStrings: !0,\n"\
                  "regexLiterals: 2\n"\
                  "}), [\"perl\", \"pl\", \"pm\"]);\n"\
                  "p(v({\n"\
                  "keywords: Q,\n"\
                  "hashComments: !0,\n"\
                  "multiLineStrings: !0,\n"\
                  "regexLiterals: !0\n"\
                  "}), [\"rb\", \"ruby\"]);\n"\
                  "p(v({\n"\
                  "keywords: E,\n"\
                  "cStyleComments: !0,\n"\
                  "regexLiterals: !0\n"\
                  "}), [\"javascript\", \"js\"]);\n"\
                  "p(v({\n"\
                  "keywords: \"all,and,by,catch,class,else,extends,false,finally,for,if,in,is,isnt,loop,new,no,not,null,of,off,on,or,return,super,then,throw,true,try,unless,until,when,while,yes\",\n"\
                  "hashComments: 3,\n"\
                  "cStyleComments: !0,\n"\
                  "multilineStrings: !0,\n"\
                  "tripleQuotedStrings: !0,\n"\
                  "regexLiterals: !0\n"\
                  "}), [\"coffee\"]);\n"\
                  "p(v({\n"\
                  "keywords: W,\n"\
                  "cStyleComments: !0,\n"\
                  "multilineStrings: !0\n"\
                  "}), [\"rc\", \"rs\", \"rust\"]);\n"\
                  "p(C([], [[\"str\", /^[\\S\\s]+/]]), [\"regex\"]);\n"\
                  "var Y = D.PR = {\n"\
                  "createSimpleLexer: C,\n"\
                  "registerLangHandler: p,\n"\
                  "sourceDecorator: v,\n"\
                  "PR_ATTRIB_NAME: \"atn\",\n"\
                  "PR_ATTRIB_VALUE: \"atv\",\n"\
                  "PR_COMMENT: \"com\",\n"\
                  "PR_DECLARATION: \"dec\",\n"\
                  "PR_KEYWORD: \"kwd\",\n"\
                  "PR_LITERAL: \"lit\",\n"\
                  "PR_NOCODE: \"nocode\",\n"\
                  "PR_PLAIN: \"pln\",\n"\
                  "PR_PUNCTUATION: \"pun\",\n"\
                  "PR_SOURCE: \"src\",\n"\
                  "PR_STRING: \"str\",\n"\
                  "PR_TAG: \"tag\",\n"\
                  "PR_TYPE: \"typ\",\n"\
                  "prettyPrintOne: D.prettyPrintOne = function(a, d, g) {\n"\
                  "var b = document.createElement(\"div\");\n"\
                  "b.innerHTML = \"<pre>\" + a + \"</pre>\";\n"\
                  "b = b.firstChild;\n"\
                  "g && J(b, g, !0);\n"\
                  "K({\n"\
                  "h: d,\n"\
                  "j: g,\n"\
                  "c: b,\n"\
                  "i: 1\n"\
                  "});\n"\
                  "return b.innerHTML\n"\
                  "},\n"\
                  "prettyPrint: D.prettyPrint = function(a, d) {\n"\
                  "function g() {\n"\
                  "for (var b = D.PR_SHOULD_USE_CONTINUATION ? c.now() + 250 : Infinity; i < p.length && c.now() < b; i++) {\n"\
                  "for (var d = p[i], j = h, k = d; k = k.previousSibling;) {\n"\
                  "var m = k.nodeType,\n"\
                  "o = (m === 7 || m === 8) && k.nodeValue;\n"\
                  "if (o ? !/^\\??prettify\\b/.test(o) : m !== 3 || /\\S/.test(k.nodeValue)) break;\n"\
                  "if (o) {\n"\
                  "j = {};\n"\
                  "o.replace(/\\b(\\w+)=([\\w%+\\-.:]+)/g,\n"\
                  "function(a, b, c) {\n"\
                  "j[b] = c\n"\
                  "});\n"\
                  "break\n"\
                  "}\n"\
                  "}\n"\
                  "k = d.className;\n"\
                  "if ((j !== h || e.test(k)) && !v.test(k)) {\n"\
                  "m = !1;\n"\
                  "for (o = d.parentNode; o; o = o.parentNode) if (f.test(o.tagName) && o.className && e.test(o.className)) {\n"\
                  "m = !0;\n"\
                  "break\n"\
                  "}\n"\
                  "if (!m) {\n"\
                  "d.className += \" prettyprinted\";\n"\
                  "m = j.lang;\n"\
                  "if (!m) {\n"\
                  "var m = k.match(n),\n"\
                  "y;\n"\
                  "if (!m && (y = U(d)) && t.test(y.tagName)) m = y.className.match(n);\n"\
                  "m && (m = m[1])\n"\
                  "}\n"\
                  "if (w.test(d.tagName)) o = 1;\n"\
                  "else var o = d.currentStyle,\n"\
                  "u = s.defaultView,\n"\
                  "o = (o = o ? o.whiteSpace: u && u.getComputedStyle ? u.getComputedStyle(d, q).getPropertyValue(\"white-space\") : 0) && \"pre\" === o.substring(0, 3);\n"\
                  "u = j.linenums;\n"\
                  "if (! (u = u === \"true\" || +u)) u = (u = k.match(/\\blinenums\\b(?::(\\d+))?/)) ? u[1] && u[1].length ? +u[1] : !0 : !1;\n"\
                  "u && J(d, u, o);\n"\
                  "r = {\n"\
                  "h: m,\n"\
                  "c: d,\n"\
                  "j: u,\n"\
                  "i: o\n"\
                  "};\n"\
                  "K(r)\n"\
                  "}\n"\
                  "}\n"\
                  "}\n"\
                  "i < p.length ? setTimeout(g, 250) : \"function\" === typeof a && a()\n"\
                  "}\n"\
                  "for (var b = d || document.body,\n"\
                  "s = b.ownerDocument || document,\n"\
                  "b = [b.getElementsByTagName(\"pre\"), b.getElementsByTagName(\"code\"), b.getElementsByTagName(\"xmp\")], p = [], m = 0; m < b.length; ++m) for (var j = 0,\n"\
                  "k = b[m].length; j < k; ++j) p.push(b[m][j]);\n"\
                  "var b = q,\n"\
                  "c = Date;\n"\
                  "c.now || (c = {\n"\
                  "now: function() {\n"\
                  "return + new Date\n"\
                  "}\n"\
                  "});\n"\
                  "var i = 0,\n"\
                  "r, n = /\\blang(?:uage)?-([\\w.]+)(?!\\S)/,\n"\
                  "e = /\\bprettyprint\\b/,\n"\
                  "v = /\\bprettyprinted\\b/,\n"\
                  "w = /pre|xmp/i,\n"\
                  "t = /^code$/i,\n"\
                  "f = /^(?:pre|code|xmp)$/i,\n"\
                  "h = {};\n"\
                  "g()\n"\
                  "}\n"\
                  "};\n"\
                  "typeof define === \"function\" && define.amd && define(\"google-code-prettify\", [],\n"\
                  "function() {\n"\
                  "return Y\n"\
                  "})\n"\
                  "})();\n"\
                  "} ()\n"\
                  "");
  return data_string;
}