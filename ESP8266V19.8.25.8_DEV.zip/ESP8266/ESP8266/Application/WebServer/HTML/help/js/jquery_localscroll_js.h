String web_server_html::HTML_help_jquery_localscroll_js()
{
  String data_string;
  data_string = F(""
                  ";(function( $ ){\n"\
                  "var URI = location.href.replace(/#.*/,'');\n"\
                  "\n"\
                  "var $localScroll = $.localScroll = function( settings ){\n"\
                  "$('body').localScroll( settings );\n"\
                  "};\n"\
                  "\n"\
                  "$localScroll.defaults = {\n"\
                  "duration:1000, \n"\
                  "axis:'y',\n"\
                  "event:'click',\n"\
                  "stop:true,\n"\
                  "target: window,\n"\
                  "reset: true \n"\
                  "};\n"\
                  "\n"\
                  "// If the URL contains a hash, it will scroll to the pointed element\n"\
                  "$localScroll.hash = function( settings ){\n"\
                  "if( location.hash ){\n"\
                  "settings = $.extend( {}, $localScroll.defaults, settings );\n"\
                  "settings.hash = false; // can't be true\n"\
                  "\n"\
                  "if( settings.reset ){\n"\
                  "var d = settings.duration;\n"\
                  "delete settings.duration;\n"\
                  "$(settings.target).scrollTo( 0, settings );\n"\
                  "settings.duration = d;\n"\
                  "}\n"\
                  "scroll( 0, location, settings );\n"\
                  "}\n"\
                  "};\n"\
                  "\n"\
                  "$.fn.localScroll = function( settings ){\n"\
                  "settings = $.extend( {}, $localScroll.defaults, settings );\n"\
                  "\n"\
                  "return settings.lazy ?\n"\
                  "// use event delegation, more links can be added later.    \n"\
                  "this.bind( settings.event, function( e ){\n"\
                  "// Could use closest(), but that would leave out jQuery -1.3.x\n"\
                  "var a = $([e.target, e.target.parentNode]).filter(filter)[0];\n"\
                  "// if a valid link was clicked\n"\
                  "if( a )\n"\
                  "scroll( e, a, settings );\n"\
                  "}) :\n"\
                  "\n"\
                  "this.find('a,area')\n"\
                  ".filter( filter ).bind( settings.event, function(e){\n"\
                  "scroll( e, this, settings );\n"\
                  "}).end()\n"\
                  ".end();\n"\
                  "\n"\
                  "function filter(){\n"\
                  "return !!this.href && !!this.hash && this.href.replace(this.hash,'') == URI && (!settings.filter || $(this).is( settings.filter ));\n"\
                  "};\n"\
                  "};\n"\
                  "\n"\
                  "function scroll( e, link, settings ){\n"\
                  "var id = link.hash.slice(1),\n"\
                  "elem = document.getElementById(id) || document.getElementsByName(id)[0];\n"\
                  "\n"\
                  "if ( !elem )\n"\
                  "return;\n"\
                  "\n"\
                  "if( e )\n"\
                  "e.preventDefault();\n"\
                  "\n"\
                  "var $target = $( settings.target );\n"\
                  "\n"\
                  "if( settings.lock && $target.is(':animated') ||\n"\
                  "settings.onBefore && settings.onBefore.call(settings, e, elem, $target) === false ) \n"\
                  "return;\n"\
                  "\n"\
                  "if( settings.stop )\n"\
                  "$target.stop(true); // remove all its animations\n"\
                  "\n"\
                  "if( settings.hash ){\n"\
                  "var attr = elem.id == id ? 'id' : 'name',\n"\
                  "$a = $('<a> </a>').attr(attr, id).css({\n"\
                  "position:'absolute',\n"\
                  "top: $(window).scrollTop(),\n"\
                  "left: $(window).scrollLeft()\n"\
                  "});\n"\
                  "\n"\
                  "elem[attr] = '';\n"\
                  "$('body').prepend($a);\n"\
                  "location = link.hash;\n"\
                  "$a.remove();\n"\
                  "elem[attr] = id;\n"\
                  "}\n"\
                  "\n"\
                  "$target\n"\
                  ".scrollTo( elem, settings ) // do scroll\n"\
                  ".trigger('notify.serialScroll',[elem]);\n"\
                  "};\n"\
                  "\n"\
                  "})( jQuery );\n"\
                  "");
  return data_string;
}