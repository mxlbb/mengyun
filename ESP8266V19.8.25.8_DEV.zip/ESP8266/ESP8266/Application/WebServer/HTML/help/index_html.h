String web_server_html::HTML_help_index_html()
{
  String data_string;
  data_string = F(""
                  "<!DOCTYPE html>\n"\
                  "<html>\n"\
                  "\n"\
                  "<head>\n"\
                  "<meta charset=\"utf-8\">\n"\
				  /*
                  "<meta name=\"description\" content=\"\">\n"\
                  "<meta name=\"HandheldFriendly\" content=\"True\">\n"\
                  "<meta name=\"MobileOptimized\" content=\"320\">\n"\
                  "<meta name=\"viewport\" content=\"initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no\">\n"\
                  "<link rel=\"alternate\" type=\"application/rss+xml\" title=\"egrappler.com\" href=\"feed/index.html\">\n"\
				  */
				  "<title>物联文档</title>\n"\
				  "<link rel=\"stylesheet\" href=\"css/style.css\">\n"\
                  "<link rel=\"stylesheet\" href=\"css/prettify.css\">\n"\
                  "</head>\n"\
                  "\n"\
                  "<body>\n"\
                  "<header>\n"\
                  "<div class=\"container\">\n"\
                  "<h2 class=\"docs-header\">物联文档</h2>\n"\
                  "</div>\n"\
                  "</header>\n"\
                  "<section>\n"\
                  "<div class=\"container\">\n"\
                  "<ul class=\"docs-nav\" id=\"menu-left\">\n"\
                  "<li><strong><h3><a href=\"#help\">帮助文档</a></h3></strong></li>\n"\
                  "<li><a href=\"#Preface\">前言</a></li>\n"\
                  "<li><strong><h3><a href=\"#Common_problem\">常见问题</a></h3></strong></li>\n"\
                  "<li><a href=\"#unavailable\">无法使用</a></li>\n"\
                  "<li><a href=\"#Development_issues\">开发问题</a></li>\n"\
                  "<li><strong><h3><a href=\"#user\">用户手册</a></h3></strong></li>\n"\
                  "<li><a href=\"#NetWork\">配置网络</a></li>\n"\
                  "<li><a href=\"#Help\">使用帮助</a></li>\n"\
                  "<li><strong><h3><a href=\"#dev\">开发手册</a></h3></strong></li>\n"\
                  "<li><a href=\"#Catalog\">目录</a></li>\n"\
                  "<li><a href=\"#EEPROM\">EEPROM</a></li>\n"\
                  "<li><a href=\"#Network\">Network</a></li>\n"\
                  "<li><a href=\"#NTP\">NTP</a></li>\n"\
                  "<li><a href=\"#System\">System</a></li>\n"\
                  "<li><a href=\"#INPUT\">INPUT</a></li>\n"\
                  "<li><a href=\"#WebClise\">WebClise</a></li>\n"\
                  "<li><a href=\"#WebServer\">WebServer</a></li>\n"\
                  "</ul>\n"\
                  "<div class=\"docs-content\">\n"\
                  "<hr id=\"help\" color=\"#ffd700\" size=\"10\" />\n"\
                  "<h2><a style=\"text-decoration:none;\" href=\"#\">帮助文档</a></h2>\n"\
                  "<hr id=\"Preface\" color=\"#ffd700\" size=\"10\" />\n"\
                  "<h3><a style=\"text-decoration:none;\" href=\"#\">前言</a></h3>\n"\
                  "<p>物联网的智能化使得实时性要求更高，为了解决实时性、依赖性、可控性、私有化设计的智能化固件。固件的设计能够解决大多数物联网所带来的快捷方便。不需要云端、通信更快更稳定、私有化数据储存、动态安全等智能化设计。</p>\n"\
                  "<ul>\n"\
                  "<li>常见问题：使用过程中遇到的问题。</li>\n"\
                  "<li>用户手册：帮助用户了解使用过程。</li>\n"\
                  "<li>开发手册：帮助开发者解答疑惑。</li>\n"\
                  "<p>注意：这份帮助文档是嵌入在ESP8266硬件中，点击标题即可回到顶部。</p>\n"\
                  "</ul>\n"\
                  "<hr id=\"Common_problem\" color=\"#ffd700\" size=\"10\" />\n"\
                  "</div>\n"\
                  "<div class=\"docs-content\">\n"\
                  "<h2><a style=\"text-decoration:none;\" href=\"#\">常见问题</a></h2>\n"\
                  "<hr id=\"unavailable\" color=\"#ffd700\" size=\"10\" />\n"\
                  "<h3><a style=\"text-decoration:none;\" href=\"#\">设备出现无法使用怎么办？（用户手册）</a></h3>\n"\
                  "<ul>\n"\
                  "<li>无法访问请确认IP地址正确后再访问（适用于网页直接访问）</li>\n"\
                  "<li>设备反应慢，请耐心等待一下。或者确认一台受控设备只有一台控制设备使用。</li>\n"\
                  "<li>硬件还是无响应，请重新给设备断电后再上电。等待接入网络。</li>\n"\
                  "<li>还是无法使用请重复步骤4。请按下重置键并同时上电，约等待2秒。完成后请参阅用户手册\"配网设置\"。</li>\n"\
                  "</ul>\n"\
                  "<hr id=\"Development_issues\" color=\"#ffd700\" size=\"10\" />\n"\
                  "<h3><a style=\"text-decoration:none;\" href=\"#\">设备开发问题收集（开发者手册）</a></h3>\n"\
                  "<ul>\n"\
                  "<li>开发者请注意：源代码使用编译器是Arduino IDE，由于Arduino底层代码尚未完善，出现未知的BUG。</li>\n"\
                  "<li>ESP8266-01编译时请选择v2.5.0版本，非ESP8266-01可以选择最新版本。</li>\n"\
                  "<li>ESP8266-01版本v2.5.0 BUG：HTTP客户端定时上报IP信息，目前暂无对DNS服务器造成异常影响。</li>\n"\
                  "<li>ESP8266-01版本v2.5.1+ BUG：EEPROM储存将无法使用。</li>\n"\
                  "<li>所有版本测试BUG：网络配置密码最长60位字符串，大于60位字符串将会配网失败。</li>\n"\
                  "<li>所有版本测试BUG：按键控制以及数据控制只能二选一。切换点是高电平状态，非高电平将被当前操作模式锁定。</li>\n"\
                  "<li>定制开发：请不要对框架进行随意修改，应用程序可以根据实际情况进行修改。</li>\n"\
                  "<li>关于EEPROM数据：储存区数据将决定连接的云端配置服务器和DNS，EEPROM中的默认配置地址请修改为需要连接云端的服务器地址。</li>\n"\
                  "<li>更换云端配置原理：只需要修改EEPROM中的默认储存数据且重启就可以修改接入的服务器地址。如果更换云端出现异常则需要对设备进行重置操作，具体请参阅开发手册。注意：局域网或广域网均适用。</li>\n"\
                  "<li>API使用请自行使用工具获取地址：http://ip:880/index.php，数据格式JSON。</li>\n"\
                  "</ul>\n"\
                  "<hr id=\"user\" color=\"#ffd700\" size=\"10\" />\n"\
                  "</div>\n"\
                  "<div class=\"docs-content\">\n"\
                  "<h2><a style=\"text-decoration:none;\" href=\"#\">用户手册</a></h2>\n"\
                  "<hr id=\"NetWork\" color=\"#ffd700\" size=\"10\" />\n"\
                  "<h3><a style=\"text-decoration:none;\" href=\"#\">配置网络</a></h3>\n"\
                  "<ul>\n"\
                  "<li>步骤一：打开APP或者使用其他设备，进入配置页。</li>\n"\
                  "<li>步骤二：输入WiFi名称和密码，点击开始配置。</li>\n"\
                  "<li>步骤三：完成配置后有相关提示。如果配置无反应，可能配置失败。</li>\n"\
                  "<p>注意：APP支持SmartConfig配置都可以使用，一般大多数APP都会支持。</p>\n"\
                  "</ul>\n"\
                  "<hr id=\"Help\" color=\"#ffd700\" size=\"10\" />\n"\
                  "<h3><a style=\"text-decoration:none;\" href=\"#\">使用帮助</a></h3>\n"\
                  "<ul>\n"\
                  "<li>如何使用？</li>\n"\
                  "<p>配置完成后，您可以使用浏览器进行控制、APP或其他硬件进行操作。</p>\n"\
                  "<li>如何操作？</li>\n"\
                  "<p>请根据页面提示进行操作。如果操作响应时间过长，请查阅常见问题\"设备出现无法访问怎么办？\"。</p>\n"\
                  "</ul>\n"\
                  "<hr id=\"dev\" color=\"#ffd700\" size=\"10\" />\n"\
                  "</div>\n"\
                  "\n"\
                  "<div class=\"docs-content\">\n"\
                  "<h2><a style=\"text-decoration:none;\" href=\"#\">开发手册</a></h2>\n"\
                  "<hr id=\"Catalog\" color=\"#ffd700\" size=\"10\" />\n"\
                  "<h3><a style=\"text-decoration:none;\" href=\"#\">目录</a></h3>\n"\
                  "<p style=\"text-align:center;\"><a style=\"text-decoration:none;\" href=\"#\">System目录表</a></p>\n"\
                  "<table style=\"width:100%;\" cellpadding=\"2\" cellspacing=\"0\" align=\"center\" border=\"1\">\n"\
                  "<tbody>\n"\
                  "<tr>\n"\
                  "<td>文件名</td>\n"\
                  "<td>作用功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>./EEPROM/EEPROM.h</td>\n"\
                  "<td>包含EEPROM头文件以及储存功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>./Network/Network.h</td>\n"\
                  "<td>包含Network头文件以及网络功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>./NTP/NTP.h</td>\n"\
                  "<td>包含NTP头文件以及时间功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>./System/System.h</td>\n"\
                  "<td>包含System头文件以及GPIO功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>./WebClise/WebClise.h</td>\n"\
                  "<td>包含WebClise头文件以及HTTP客户端功能</td>\n"\
                  "</tr>\n"\
                  "</tbody>\n"\
                  "</table>\n"\
                  "<p style=\"text-align:center;\"><a style=\"text-decoration:none;\" href=\"#\">Application目录表</a></p>\n"\
                  "<table style=\"width:100%;\" cellpadding=\"2\" cellspacing=\"0\" align=\"center\" border=\"1\">\n"\
                  "<tbody>\n"\
                  "<tr>\n"\
                  "<td>文件名</td>\n"\
                  "<td>作用功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>./HTML/</td>\n"\
                  "<td>HTML文件夹是网页模板，可自由更换。</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>./JsonServer/</td>\n"\
                  "<td>JsonServer文件夹管理HTTP后端传输。</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>./JsonServer/WebErvices/</td>\n"\
                  "<td>WebErvices文件夹是基础的web框架，不建议修改。</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>./JsonServer/Application/</td>\n"\
                  "<td>Application文件夹是应用框架，根据实际修改。</td>\n"\
                  "</tr>\n"\
                  "</tbody>\n"\
                  "</table>\n"\
                  "<p>注意：<br />修改过程中注意System文件夹提供的API。</p>\n"\
                  "<hr id=\"System\" color=\"#ffd700\" size=\"10\" />\n"\
                  "<h3><a style=\"text-decoration:none;\" href=\"#\">System作用功能：入口点</a></h3>\n"\
                  "<table style=\"width:100%;\" cellpadding=\"2\" cellspacing=\"0\" align=\"center\" border=\"1\">\n"\
                  "<tbody>\n"\
                  "<tr>\n"\
                  "<td>函数名</td>\n"\
                  "<td>作用功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>System_ setup</td>\n"\
                  "<td>System的初始化</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>System_ loop</td>\n"\
                  "<td>System的主函数</td>\n"\
                  "</tr>\n"\
                  "</tbody>\n"\
                  "</table>\n"\
                  "<p>注意：<br />请不要自定义调节函数顺序</p>\n"\
                  "<hr id=\"EEPROM\" color=\"#ffd700\" size=\"10\" />\n"\
                  "<h3><a style=\"text-decoration:none;\" href=\"#\">EEPROM作用功能：存储功能</a></h3>\n"\
                  "<table style=\"width:100%;\" cellpadding=\"2\" cellspacing=\"0\" align=\"center\" border=\"1\">\n"\
                  "<tbody>\n"\
                  "<tr>\n"\
                  "<td>宏定义</td>\n"\
                  "<td>作用功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>define_ eeprom_ template_ debug</td>\n"\
                  "<td>eeprom.main中自动判断初始化</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>define_ Struct_ eeprom_ data_ http_ api</td>\n"\
                  "<td>EEPROM默认初始化云端地址</td>\n"\
                  "</tr>\n"\
                  "</tbody>\n"\
                  "</table>\n"\
                  "<br />\n"\
                  "<table style=\"width:100%;\" cellpadding=\"2\" cellspacing=\"0\" align=\"center\" border=\"1\">\n"\
                  "<tbody>\n"\
                  "<tr>\n"\
                  "<td>变量名</td>\n"\
                  "<td>作用功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>eeprom_ data_ switch_ init</td>\n"\
                  "<td>判断云端配置:覆盖(true),不覆盖(false)</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>eeprom_ data_ web_ name</td>\n"\
                  "<td>显示硬件的标题</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>eeprom_ data_ http_ url</td>\n"\
                  "<td>显示硬件的服务器地址</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>eeprom_ data_ http_ api</td>\n"\
                  "<td>硬件接口配置地址</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>eeprom_ data_ https_ dns</td>\n"\
                  "<td>硬件域名服务器(DNS)地址</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>eeprom_ data_ https_ sha1</td>\n"\
                  "<td>硬件域名服务器(DNS)地址的</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>eeprom_ data_ ntp_ url</td>\n"\
                  "<td>指定硬件的NTP时间服务器</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>eeprom_ data_ scene</td>\n"\
                  "<td>字符串&quot;使用场景 &quot;类型变量，比如&quot;客厅 &quot;等</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>eeprom_ data_ category</td>\n"\
                  "<td>字符串&quot;硬件类型 &quot;类型变量，比如&quot;灯泡 &quot;等</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>eeprom_ data_ remarks</td>\n"\
                  "<td>自定义数据储存区域</td>\n"\
                  "</tr>\n"\
                  "</tbody>\n"\
                  "</table>\n"\
                  "<br />\n"\
                  "<table style=\"width:100%;\" cellpadding=\"2\" cellspacing=\"0\" align=\"center\" border=\"1\">\n"\
                  "<tbody>\n"\
                  "<tr>\n"\
                  "<td>类方法</td>\n"\
                  "<td>作用功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>eeprom.init</td>\n"\
                  "<td>初始化：配置地址、场景类型、自定义数据储存区域</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>eeprom.main</td>\n"\
                  "<td>主方法：判断读取 配置地址是否为空，空值调用</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>eeprom.message</td>\n"\
                  "<td>打印类变量的字符串</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>eeprom.read</td>\n"\
                  "<td>读取EEPROM数据到变量中</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>eeprom.write</td>\n"\
                  "<td>写入EEPROM数据到变量中</td>\n"\
                  "</tr>\n"\
                  "</tbody>\n"\
                  "</table>\n"\
                  "<p>注意:<br />所有变量均为全局变量，eeprom.read覆盖EEPROM类变量，调用eeprom.write之前保存数据到EEPROM类变量。<br />重启时按住GPIO0口可以恢复固件默认的接口配置地址。digitalRead(0X0)是设置GPIO0口 Vcc - GPIO0</p>\n"\
                  "<hr id=\"Network\" color=\"#ffd700\" size=\"10\" />\n"\
                  "<h3><a style=\"text-decoration:none;\" href=\"#\">Network作用功能：网络管理</a></h3>\n"\
                  "<table style=\"width:100%;\" cellpadding=\"2\" cellspacing=\"0\" align=\"center\" border=\"1\">\n"\
                  "<tbody>\n"\
                  "<tr>\n"\
                  "<td>宏定义</td>\n"\
                  "<td>作用功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>define_ smartnetwork_ print_ debug</td>\n"\
                  "<td>显示串口调试信息</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>define_ smartnetwork_ function_ swit_ time</td>\n"\
                  "<td>控制Network.time方法编译</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>define_ smartnetwork_ network_ overtime</td>\n"\
                  "<td>调节Network.smartconfig和Network.connect连接时间</td>\n"\
                  "</tr>\n"\
                  "</tbody>\n"\
                  "</table>\n"\
                  "<br />\n"\
                  "<table style=\"width:100%;\" cellpadding=\"2\" cellspacing=\"0\" align=\"center\" border=\"1\">\n"\
                  "<tbody>\n"\
                  "<tr>\n"\
                  "<td>类方法</td>\n"\
                  "<td>作用功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Network.init</td>\n"\
                  "<td>初始化：设置WiFi工作模式、主机名(部分芯片不支持)</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Network.main</td>\n"\
                  "<td>主方法：调用自动判断配网和连接</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Network.message</td>\n"\
                  "<td>显示网络信息,false显示基础信息，true显示全部信息</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Network.time</td>\n"\
                  "<td>统计Network类方法的运行时间：返回值long单位ms</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Network.hostname</td>\n"\
                  "<td>设置主机名</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Network.smartconfig</td>\n"\
                  "<td>基础配网</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Network.connect</td>\n"\
                  "<td>基础连接</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Network.ip</td>\n"\
                  "<td>获取IP或MAC有关信息</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Network.equipment</td>\n"\
                  "<td>获取基础网络信息</td>\n"\
                  "</tr>\n"\
                  "</tbody>\n"\
                  "</table>\n"\
                  "<p>注意:<br />配置无线网络和连接无线网络需要15秒时间。</p>\n"\
                  "<hr id=\"NTP\" color=\"#ffd700\" size=\"10\" />\n"\
                  "<h3><a style=\"text-decoration:none;\" href=\"#\">NTP作用功能：时间管理</a></h3>\n"\
                  "<table style=\"width:100%;\" cellpadding=\"2\" cellspacing=\"0\" align=\"center\" border=\"1\">\n"\
                  "<tbody>\n"\
                  "<tr>\n"\
                  "<td>宏定义</td>\n"\
                  "<td>作用功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>define_ time_ adjustment</td>\n"\
                  "<td>调整秒数 +N / -N (UL) 默认+2秒(传输延迟)</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>define_ time_ sha1_ switch</td>\n"\
                  "<td>SHA1开关：BOOL型</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>define_ time_ sha1_ security</td>\n"\
                  "<td>设置动态密钥的安全时间</td>\n"\
                  "</tr>\n"\
                  "</tbody>\n"\
                  "</table>\n"\
                  "<br />\n"\
                  "<table style=\"width:100%;\" cellpadding=\"2\" cellspacing=\"0\" align=\"center\" border=\"1\">\n"\
                  "<tbody>\n"\
                  "<tr>\n"\
                  "<td>全局变量</td>\n"\
                  "<td>作用功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>data_ time_ server_ ip</td>\n"\
                  "<td>声明IPAddress类型变量</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>data_ ntp_ server_ name</td>\n"\
                  "<td>设置NTP服务器地址。仅用于调试。</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>data_ ntp_ packet_ size</td>\n"\
                  "<td>储存NTP时间戳</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>data_ packet_ buffer</td>\n"\
                  "<td>用于保存传入和传出数据包的缓冲区</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>data_ epoch</td>\n"\
                  "<td>Unix时间戳</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>data_ time_ sha1</td>\n"\
                  "<td>十六进制Unix时间戳字符串</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>data_ time_ string_ print</td>\n"\
                  "<td>CST时间字符串</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>localPort</td>\n"\
                  "<td>本地端口用于侦听data_ udp数据包</td>\n"\
                  "</tr>\n"\
                  "</tbody>\n"\
                  "</table>\n"\
                  "<br />\n"\
                  "<table style=\"width:100%;\" cellpadding=\"2\" cellspacing=\"0\" align=\"center\" border=\"1\">\n"\
                  "<tbody>\n"\
                  "<tr>\n"\
                  "<td>函数方法</td>\n"\
                  "<td>作用功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>NTP.init</td>\n"\
                  "<td>基础NTP服务器信息初始化。</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>NTP.main</td>\n"\
                  "<td>每秒显示Unix时间戳、CST时间</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>NTP.sum</td>\n"\
                  "<td>调用data_ time_ sum</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>data_ time_ main</td>\n"\
                  "<td>处理NTP返回数据</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>data_ time_ sum</td>\n"\
                  "<td>定时任务：每秒使Unix时间+1</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>data_ time_ print</td>\n"\
                  "<td>打印十六进制字符串和加密后的SHA1</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>data_ send_ ntp_ packet</td>\n"\
                  "<td>请求NTP服务器数据</td>\n"\
                  "</tr>\n"\
                  "</tbody>\n"\
                  "</table>\n"\
                  "<p>注意：<br />NTP.init函数出于安全考虑如果未连接网络一直循环检测网络，硬件无法正常工作。<br />NTP.init函数丢失或者未配置NTP服务器地址，硬件无法正常工作。</p>\n"\
                  "<hr id=\"System\" color=\"#ffd700\" size=\"10\" />\n"\
                  "<h3><a style=\"text-decoration:none;\" href=\"#\">System作用功能：硬件GPIO管理</a></h3>\n"\
                  "<table style=\"width:100%;\" cellpadding=\"2\" cellspacing=\"0\" align=\"center\" border=\"1\">\n"\
                  "<tbody>\n"\
                  "<tr>\n"\
                  "<td>类方法 </td>\n"\
                  "<td>作用功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>System.init</td>\n"\
                  "<td>硬件初始化GPIO函数，可以增加或删除</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>System.main</td>\n"\
                  "<td>声明GPIO并初始化</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>System.function_ esp</td>\n"\
                  "<td>初始化硬件系统控制，可以增加或删除</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>System.function_ io</td>\n"\
                  "<td>硬件GPIO声明定义</td>\n"\
                  "</tr>\n"\
                  "</tbody>\n"\
                  "</table>\n"\
                  "<p>注意：<br />System.h自定义硬件的GPIO口</p>\n"\
                  "<hr id=\"INPUT\" color=\"#ffd700\" size=\"10\" />\n"\
                  "<h3><a style=\"text-decoration:none;\" href=\"#\">INPUT作用功能：使用按键控制GPIO</a></h3>\n"\
                  "<table style=\"width:100%;\" cellpadding=\"2\" cellspacing=\"0\" align=\"center\" border=\"1\">\n"\
                  "<tbody>\n"\
                  "<tr>\n"\
                  "<td>函数</td>\n"\
                  "<td>作用功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Analog_ key</td>\n"\
                  "<td>检测按键状态</td>\n"\
                  "</tr>\n"\
                  "</tbody>\n"\
                  "</table>\n"\
                  "<p>注意：<br />ESP8266-12F引脚说明：当define_ esp8266_ input被定义控制脚GPIO15(D8) - Vcc.<br />ESP8266-12F引脚说明：当define_ esp8266_ input不被被定义控制脚GPIO2(D4) - GND.<br />ESP8266-01引脚说明：当define_ esp8266_ input不被被定义控制脚GPIO2 - Vcc(不确定).</p>\n"\
                  "<hr id=\"WebClise\" color=\"#ffd700\" size=\"10\" />\n"\
                  "<h3><a style=\"text-decoration:none;\" href=\"#\">WebClise作用功能：模拟浏览器</a></h3>\n"\
                  "<table style=\"width:100%;\" cellpadding=\"2\" cellspacing=\"0\" align=\"center\" border=\"1\">\n"\
                  "<tbody>\n"\
                  "<tr>\n"\
                  "<td>全局变量</td>\n"\
                  "<td>作用功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Web.server.restart</td>\n"\
                  "<td>控制Web.main执行</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Web.server.ipv4</td>\n"\
                  "<td>缓存IPV4字符串</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Web.server.ipv6</td>\n"\
                  "<td>缓存IPV6字符串</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Web.server.time</td>\n"\
                  "<td>缓存返回时间字符串</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Web.server.sha1</td>\n"\
                  "<td>缓存SHA1指纹字符串</td>\n"\
                  "</tr>\n"\
                  "</tbody>\n"\
                  "</table>\n"\
                  "<br />\n"\
                  "<table style=\"width:100%;\" cellpadding=\"2\" cellspacing=\"0\" align=\"center\" border=\"1\">\n"\
                  "<tbody>\n"\
                  "<tr>\n"\
                  "<td>类方法</td>\n"\
                  "<td>作用功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Web.main</td>\n"\
                  "<td>检测HTTP、HTTPS请求状态</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Web.http</td>\n"\
                  "<td>发送HTTP请求获取云端配置信息</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Web.https</td>\n"\
                  "<td>发送HTTPS请求：云端配置、IP、MAC、时间字符串</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>Web.json</td>\n"\
                  "<td>数据模板</td>\n"\
                  "</tr>\n"\
                  "</tbody>\n"\
                  "</table>\n"\
                  "</ul>注意：<br />Web.main函数如果不能正常接收数据，导致NTP类无法正常工作.<br />Web.main函数检测通信状态，通信失败则再次建立通信直到通信成功.<br />Web.main函数检测IP变动会上传到&quot;物联网 &quot;DNS服务器.\n"\
                  "<hr id=\"WebServer\" color=\"#ffd700\" size=\"10\" />\n"\
                  "<h3><a style=\"text-decoration:none;\" href=\"#\">WebServer作用功能：WEB服务器</a></h3>\n"\
                  "<table style=\"width:100%;\" cellpadding=\"2\" cellspacing=\"0\" align=\"center\" border=\"1\">\n"\
                  "<tbody>\n"\
                  "<tr>\n"\
                  "<td>类方法</td>\n"\
                  "<td>作用功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>WebServer.JsonServer_ index_ json</td>\n"\
                  "<td>JSON入口点</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>WebServer.JsonServer_ switch_ json</td>\n"\
                  "<td>JSON硬件控制</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>WebServer.JsonServer_ api_ json</td>\n"\
                  "<td>JSON硬件信息</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>WebServer.JsonServer_ help_ json</td>\n"\
                  "<td>JSON帮助文件</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>WebServer.JsonServer_ eeprom_ json</td>\n"\
                  "<td>JSON数据存储</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>WebServer.HTML_ index_ root</td>\n"\
                  "<td>HTML根目录</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>WebServer.HTML_ index_ html</td>\n"\
                  "<td>HTML首页</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>WebServer.HTML_ reset_ css</td>\n"\
                  "<td>HTML样式文件</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>WebServer.HTML_ style_ css</td>\n"\
                  "<td>HTML样式文件</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>WebServer.HTML_ zzsc_ css</td>\n"\
                  "<td>HTML样式文件</td>\n"\
                  "</tr>\n"\
                  "</tbody>\n"\
                  "</table>\n"\
                  "<br />\n"\
                  "<table style=\"width:100%;\" cellpadding=\"2\" cellspacing=\"0\" align=\"center\" border=\"1\">\n"\
                  "<tbody>\n"\
                  "<tr>\n"\
                  "<td>函数</td>\n"\
                  "<td>作用功能</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>web_ server</td>\n"\
                  "<td>WEB服务主函数，默认880传参端口</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>JsonServer_ security_ authentication</td>\n"\
                  "<td>JSONServer安全身份验证</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>web_ server_ html</td>\n"\
                  "<td>HTML网页区域</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>web_ server_ server</td>\n"\
                  "<td>JSON函数区域</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>web_ server_ help</td>\n"\
                  "<td>HTML帮助文档</td>\n"\
                  "</tr>\n"\
                  "<tr>\n"\
                  "<td>JsonServer_ error_ code</td>\n"\
                  "<td>HTML错误页</td>\n"\
                  "</tr>\n"\
                  "</tbody>\n"\
                  "</table>\n"\
                  "</p>注意：<br />server.onNotFound函数只能调用普通函数，不能调用class类的函数.<br />WebServer.JsonServer_ eeprom_ json函数是重要配置文件，接受客户端全面修改和服务器基础配置修改.<br />JSON获取全部参数容易内存不足，引起硬件重启。解决方法，提高访问时间间隔.</p>\n"\
                  "<hr id=\"Common_problem\" color=\"#ffd700\" size=\"10\" />\n"\
                  "</div>\n"\
                  "</div>\n"\
                  "</section>\n"\
                  "<footer>\n"\
                  "<div class=\"container\">\n"\
                  "<p> &copy; 2019 <a href=\"http://mengyun.org/\" target=\"_blank\" title=\"梦云之家\">梦云之家</a> 版权所有</p>\n"\
                  "</div>\n"\
                  "</footer>\n"\
                  "<script type=\"text/javascript\" src=\"js/prettify.js\"></script>\n"\
                  "<script src=\"js/layout.js\"></script>\n"\
                  "<script src=\"js/jquery.localscroll-1.2.7.js\" type=\"text/javascript\"></script>\n"\
                  "<script src=\"js/jquery.scrollTo-1.4.3.1.js\" type=\"text/javascript\"></script>\n"\
                  "</body>\n"\
                  "\n"\
                  "</html>\n"\
                  "");
  return data_string;
}