#include <ESP8266WebServer.h>
#include <ArduinoJson.h>
#include <Hash.h>

#define define_security_authentication

ESP8266WebServer server;

String data_security_user;
char data_security_psk[0X20] = {false};

void web_server(const unsigned int data_post);
void web_encryption();
class web_server_html;
void JsonServer_security_authentication();
void web_server_html();
void web_server_server();
void web_server_help();
String JsonServer_error_code();

void web_server(const unsigned int data_post)
{
  web_server_html();
  web_server_server();
  web_server_help();
  server.onNotFound(JsonServer_error_code);
  server.begin(data_post);
  /*void loop(){server.handleClient();}*/
}

void web_encryption()
{
  data_security_user = (String)ESP.getChipId() + (String)ESP.getFlashChipId();
  String data_security_psk_temp = sha1(
      //sha1(String(data_time_sha1)) +
      sha1((String)ESP.getChipId() + (String)ESP.getFlashChipId()) +
      sha1(Network.equipment(F("equipment_localmac"))) +
      sha1(Network.equipment(F("equipment_psk"))));
  for (uint16_t data_temp = 0; data_temp < sizeof(data_security_psk); data_temp++)
    data_security_psk[data_temp] = data_security_psk_temp[data_temp];
}

class web_server_html
{
public:
  String JsonServer_index_json();
  String JsonServer_switch_json();
  String JsonServer_api_json();
  String JsonServer_help_json();
  String JsonServer_eeprom_json();
  String HTML_root_html();
  String HTML_index_html();
  String HTML_admin_html();
  String HTML_reset_css();
  String HTML_style_css();
  String HTML_zzsc_css();
  String HTML_public_js();
  String HTML_private_js();
  String HTML_help_index_html();
  String HTML_help_prettify_css();
  String HTML_help_style_css();
  String HTML_help_jquery_localscroll_js();
  String HTML_help_jquery_scrollTo_js();
  String HTML_help_layout_js();
  String HTML_help_prettify_js();
  web_server_html() {}
  ~web_server_html() {}
} WebServer;

void JsonServer_security_authentication()
{
  web_encryption();
  //Serial.println();
  //Serial.println(data_security_user.c_str());
  //Serial.println(data_security_psk);
  if (!server.authenticate(data_security_user.c_str(), data_security_psk))
  {
    return server.requestAuthentication();
  }
  //Serial.println("登录成功");
  //return 0;
}

void web_server_html()
{
  server.on(F("/"), []() {
    String data_html_char = WebServer.HTML_root_html();
    server.send(200, F("text/html"), data_html_char);
  });
  server.on(F("/index.html"), []() {
    web_encryption();
    String data_html_char = WebServer.HTML_index_html();
    server.send(200, F("text/html"), data_html_char);
  });
  server.on(F("/admin.html"), []() {
#ifdef define_security_authentication
    JsonServer_security_authentication(); //身份验证函数
#endif
    String data_html_char = WebServer.HTML_admin_html();
    server.send(200, F("text/html"), data_html_char);
  });
  server.on(F("/css/reset.css"), []() {
    String data_html_char = WebServer.HTML_reset_css();
    server.send(200, F("text/css"), data_html_char);
  });
  server.on(F("/css/style.css"), []() {
    String data_html_char = WebServer.HTML_style_css();
    server.send(200, F("text/css"), data_html_char);
  });
  server.on(F("/css/zzsc.css"), []() {
    String data_html_char = WebServer.HTML_zzsc_css();
    server.send(200, F("text/css"), data_html_char);
  });
  server.on(F("/js/public.js"), []() {
    String data_html_char = WebServer.HTML_public_js();
    server.send(200, F("application/json"), data_html_char);
  });
  server.on(F("/js/private.js"), []() {
#ifdef define_security_authentication
    JsonServer_security_authentication(); //身份验证函数
#endif
    String data_html_char = WebServer.HTML_private_js();
    server.send(200, F("application/json"), data_html_char);
  });
}

void web_server_server()
{
  server.on(F("/index.php"), []() {
    String data_html_char = WebServer.JsonServer_index_json();
    server.send(200, F("application/json"), data_html_char);
  });
  server.on(F("/server/switch.php"), []() {
#ifdef define_security_authentication
    JsonServer_security_authentication(); //身份验证函数
#endif
    String data_html_char = WebServer.JsonServer_switch_json();
    server.send(200, F("application/json"), data_html_char);
  });
  server.on(F("/server/public.php"), []() {
    String data_html_char = Web.json();
    server.send(200, F("application/json"), data_html_char);
  });
  server.on(F("/server/api.php"), []() {
#ifdef define_security_authentication
    JsonServer_security_authentication(); //身份验证函数
#endif
    String data_html_char = WebServer.JsonServer_api_json();
    server.send(200, F("application/json"), data_html_char);
  });
  server.on(F("/server/help.php"), []() {
    String data_html_char = WebServer.JsonServer_help_json();
    server.send(200, F("application/json"), data_html_char);
  });
  server.on(F("/server/eeprom.php"), []() {
#ifdef define_security_authentication
    JsonServer_security_authentication(); //身份验证函数
#endif
    String data_html_char = WebServer.JsonServer_eeprom_json();
    server.send(200, F("application/json"), data_html_char);
  });
  server.on(F("/server/error.php"), []() {
    String data_html_char = JsonServer_error_code();
    server.send(404, F("text/html"), data_html_char);
  });
}

void web_server_help()
{
  server.on(F("/help/index.html"), []() {
    String data_html_char = WebServer.HTML_help_index_html();
    server.send(200, F("text/html"), data_html_char);
  });
  server.on(F("/help/css/prettify.css"), []() {
    String data_html_char = WebServer.HTML_help_prettify_css();
    server.send(200, F("text/css"), data_html_char);
  });
  server.on(F("/help/css/style.css"), []() {
    String data_html_char = WebServer.HTML_help_style_css();
    server.send(200, F("text/css"), data_html_char);
  });
  server.on(F("/help/js/jquery.localscroll-1.2.7.js"), []() {
    String data_html_char = WebServer.HTML_help_jquery_localscroll_js();
    server.send(200, F("application/json"), data_html_char);
  });
  server.on(F("/help/js/jquery.scrollTo-1.4.3.1.js"), []() {
    String data_html_char = WebServer.HTML_help_jquery_scrollTo_js();
    server.send(200, F("application/json"), data_html_char);
  });
  server.on(F("/help/js/layout.js"), []() {
    String data_html_char = WebServer.HTML_help_layout_js();
    server.send(200, F("application/json"), data_html_char);
  });
  server.on(F("/help/js/prettify.js"), []() {
    String data_html_char = WebServer.HTML_help_prettify_js();
    server.send(200, F("application/json"), data_html_char);
  });
}
