#include "./WebServer.h"

#include "./HTML/root_html.h"

#include "./HTML/index_html.h"
#include "./HTML/admin/admin_html.h"
#include "./HTML/admin/css/reset_css.h"
#include "./HTML/admin/css/style_css.h"
#include "./HTML/admin/css/zzsc_css.h"
#include "./HTML/admin/js/public_js.h"
#include "./HTML/admin/js/private_js.h"

#include "./JsonServer/WebErvices/api.h"
#include "./JsonServer/WebErvices/eeprom.h"
#include "./JsonServer/WebErvices/error.h"

#include "./JsonServer/Application/index.h"
#include "./JsonServer/Application/switch.h"
#include "./JsonServer/Application/help.h"

#include "./HTML/help/index_html.h"
#include "./HTML/help/css/prettify_css.h"
#include "./HTML/help/css/style_css.h"
#include "./HTML/help/js/jquery_localscroll_js.h"
#include "./HTML/help/js/jquery_scrollTo_js.h"
#include "./HTML/help/js/layout_js.h"
#include "./HTML/help/js/prettify_js.h"

void WebServer_setup();
void WebServer_loop();

void WebServer_setup()
{
  web_server(880);
}

void WebServer_loop()
{
  server.handleClient();
  //Serial.println(digitalRead(0));
}