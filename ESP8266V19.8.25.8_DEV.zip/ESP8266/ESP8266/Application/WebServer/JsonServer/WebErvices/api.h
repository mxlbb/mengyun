String web_server_html::JsonServer_api_json()
{
  StaticJsonDocument<0X320> data_json;
  if (server.args() == false)
  {
    JsonObject data_json_help   = data_json.createNestedObject(F("功能目录(void)"));
    data_json_help[F("0")] = F("{");
    data_json_help[F("1")] = F("实时信息(function)");
    data_json_help[F("2")] = F("网络状态(function)");
    data_json_help[F("3")] = F("安全认证(function)");
    data_json_help[F("4")] = F("}");
  }
  for (uint8_t data_JsonServer_api_json = 0X0; data_JsonServer_api_json < server.args(); data_JsonServer_api_json++)
  {
    if (String(server.argName(data_JsonServer_api_json)) == String(F("1")) && server.arg(data_JsonServer_api_json) == F("实时信息"))
    {
      JsonObject data_json_hardware    = data_json.createNestedObject(F("实时信息"));
      data_json_hardware[F("型号")]   = String(F("ESP8266EX"));
      data_json_hardware[F("CPU")]    = System.function_esp(F("ESP.getCpuFreqMHz()"));
      data_json_hardware[F("RAM")]    = System.function_esp(F("ESP.getFreeHeap()"));
      data_json_hardware[F("ROM")]    = System.function_esp(F("ESP.getSketchSize()"));
      data_json_hardware[F("本地时间")] = data_time_string_print;
      data_json_hardware[F("信号强度")] = String(WiFi.RSSI()) + "dBm";
    }
    if (String(server.argName(data_JsonServer_api_json)) == String(F("2")) && server.arg(data_JsonServer_api_json) == F("网络状态"))
    {
      JsonObject data_json_network = data_json.createNestedObject(F("网络状态"));
      data_json_network[F("无线名称")] = Network.equipment(F("equipment_ssid"));
      data_json_network[F("无线密码")] = Network.equipment(F("equipment_psk"));
      data_json_network[F("本机MAC")] = Network.equipment(F("equipment_localmac"));
      data_json_network[F("网关MAC")] = Network.equipment(F("equipment_gatewaymac"));
      data_json_network[F("IPV4地址")]  = Network.ip(F("ipv4_ip"));
      data_json_network[F("IPV4子网")]  = Network.ip(F("ipv4_subnetmask"));
      data_json_network[F("IPV4网关")]  = Network.ip(F("ipv4_gateway"));
      data_json_network[F("IPV6地址")]  = Network.ip(F("ipv6_ip"));
      data_json_network[F("IPV6保留")]  = Network.ip(F("ipv6_retain"));
      data_json_network[F("DNS1")]    = Network.ip(F("ip_dns1"));
      data_json_network[F("DNS2")]    = Network.ip(F("ip_dns2"));
    }

    if (String(server.argName(data_JsonServer_api_json)) == String(F("3")) && server.arg(data_JsonServer_api_json) == F("安全认证"))
    {
      web_encryption();
      JsonObject data_json_security   = data_json.createNestedObject(F("安全认证"));
      data_json_security[F("用户")]   = data_security_user;
      data_json_security[F("密码")]   = data_security_psk;
      data_json_security[F("密钥周期")] = define_time_sha1_security - (data_epoch % define_time_sha1_security);
      data_json_security[F("认证密钥")] = sha1(
            sha1(String(data_time_sha1)) +
            sha1((String)ESP.getChipId() + (String)ESP.getFlashChipId()) +
            sha1(Network.equipment(F("equipment_localmac"))) +
            sha1(Network.equipment(F("equipment_psk")))
          );
    }
  }
  Serial.println();
  serializeJsonPretty(data_json, Serial);
  Serial.println();
  Serial.print(F("生成的JSON文档大小："));
  Serial.println(serializeJson(data_json, Serial));
  return data_json.as<String>();
}
