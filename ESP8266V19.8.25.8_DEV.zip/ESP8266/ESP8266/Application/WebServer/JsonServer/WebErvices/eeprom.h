String web_server_html::JsonServer_eeprom_json()
{
  StaticJsonDocument<0XC00 - 0XE0> data_json;

  bool eeprom_json_webhttp_http_api = false;
  bool eeprom_json_webhttp_http_data = false;

  Serial.println();
  for (byte data_eeprom_json_sum = 0X0; data_eeprom_json_sum < server.args(); data_eeprom_json_sum++)
  {
    if (server.argName(data_eeprom_json_sum) == F("云端名称") && String(server.arg(data_eeprom_json_sum)) != String(eeprom.Struct.eeprom_data_web_name))
      strcpy(eeprom.Struct.eeprom_data_web_name, server.arg(data_eeprom_json_sum).c_str());
    if (server.argName(data_eeprom_json_sum) == F("云端地址") && String(server.arg(data_eeprom_json_sum)) != String(eeprom.Struct.eeprom_data_web_name))
      strcpy(eeprom.Struct.eeprom_data_http_url, server.arg(data_eeprom_json_sum).c_str());
    if (server.argName(data_eeprom_json_sum) == F("API地址") && String(server.arg(data_eeprom_json_sum)) != String(eeprom.Struct.eeprom_data_web_name))
      strcpy(eeprom.Struct.eeprom_data_http_api, server.arg(data_eeprom_json_sum).c_str()), eeprom_json_webhttp_http_api = true;
    if (server.argName(data_eeprom_json_sum) == F("DNS地址") && String(server.arg(data_eeprom_json_sum)) != String(eeprom.Struct.eeprom_data_web_name))
      strcpy(eeprom.Struct.eeprom_data_https_dns, server.arg(data_eeprom_json_sum).c_str());
    if (server.argName(data_eeprom_json_sum) == F("DNS指纹") && String(server.arg(data_eeprom_json_sum)) != String(eeprom.Struct.eeprom_data_web_name))
      strcpy(eeprom.Struct.eeprom_data_https_sha1, server.arg(data_eeprom_json_sum).c_str());
    if (server.argName(data_eeprom_json_sum) == F("NTP地址") && String(server.arg(data_eeprom_json_sum)) != String(eeprom.Struct.eeprom_data_web_name))
      strcpy(eeprom.Struct.eeprom_data_ntp_url, server.arg(data_eeprom_json_sum).c_str());
    if (server.argName(data_eeprom_json_sum) == F("数据场景") && String(server.arg(data_eeprom_json_sum)) != String(eeprom.Struct.eeprom_data_web_name))
      strcpy(eeprom.Struct.eeprom_data_scene, server.arg(data_eeprom_json_sum).c_str()), eeprom_json_webhttp_http_data = true;
    if (server.argName(data_eeprom_json_sum) == F("数据类别") && String(server.arg(data_eeprom_json_sum)) != String(eeprom.Struct.eeprom_data_web_name))
      strcpy(eeprom.Struct.eeprom_data_category, server.arg(data_eeprom_json_sum).c_str()), eeprom_json_webhttp_http_data = true;
    if (server.argName(data_eeprom_json_sum) == F("数据存储") && String(server.arg(data_eeprom_json_sum)) != String(eeprom.Struct.eeprom_data_web_name))
      strcpy(eeprom.Struct.eeprom_data_remarks, server.arg(data_eeprom_json_sum).c_str()), eeprom_json_webhttp_http_data = true;

    Serial.print(String(server.argName(data_eeprom_json_sum)));
    Serial.print(":");
    Serial.println(String(server.arg(data_eeprom_json_sum)));

  }
  Serial.println(F("if(eeprom_json_webhttp_http_api)"));
  if (eeprom_json_webhttp_http_api)Web.server.restart = false;
  if (eeprom_json_webhttp_http_data)
  {
    eeprom.write();
    eeprom.read();
    eeprom.message();
  }

  if (server.args() == false)
  {
    JsonObject data_json_help   = data_json.createNestedObject(F("储存目录(void)"));
    data_json_help[F("0")] = F("{");
    data_json_help[F("1")] = F("云端名称(String)");
    data_json_help[F("2")] = F("云端地址(String)");
    data_json_help[F("3")] = F("API地址(String)");
    data_json_help[F("4")] = F("DNS地址(String)");
    data_json_help[F("5")] = F("DNS指纹(String)");
    data_json_help[F("6")] = F("NTP地址(String)");
    data_json_help[F("7")] = F("数据场景(String)");
    data_json_help[F("8")] = F("数据类别(String)");
    data_json_help[F("9")] = F("数据存储(String)");
    data_json_help[F("10")] = F("}");

  }
  else
  {
    JsonObject data_json_eeprom    = data_json.createNestedObject(F("存储数据"));
    data_json_eeprom[F("云端名称")] = eeprom.Struct.eeprom_data_web_name;
    data_json_eeprom[F("云端地址")] = eeprom.Struct.eeprom_data_http_url;
    data_json_eeprom[F("API地址")] = eeprom.Struct.eeprom_data_http_api;
    data_json_eeprom[F("DNS地址")] = eeprom.Struct.eeprom_data_https_dns;
    data_json_eeprom[F("DNS指纹")] = eeprom.Struct.eeprom_data_https_sha1;
    data_json_eeprom[F("NTP地址")] = eeprom.Struct.eeprom_data_ntp_url;
    data_json_eeprom[F("数据场景")] = eeprom.Struct.eeprom_data_scene;
    data_json_eeprom[F("数据类别")] = eeprom.Struct.eeprom_data_category;
    data_json_eeprom[F("数据存储")] = eeprom.Struct.eeprom_data_remarks;
    serializeJsonPretty(data_json, Serial);
  }
  //delay(500);
  Serial.print(F("生成的JSON文档大小："));
  Serial.println(serializeJson(data_json, Serial));
  return data_json.as<String>();
}
