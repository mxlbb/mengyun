String JsonServer_error_code()
{
  String data_html;
  if (server.method() == HTTP_GET)
  {
    data_html = F(""\
                  "<html>"\
                  "<head> "\
                  "<meta charset=\"UTF-8\" /> "\
                  "<title>404 - 梦云之家</title> "\
                  "<meta name=\"renderer\" content=\"webkit\" /> "\
                  "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /> "\
                  "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0,maximum-scale=1.0,minimum-scale=1.0,user-scalable=no\" /> "\
                  "<!--[if lte IE 8]> <script> location = \"/ie.html?url=\" + encodeURIComponent(location.href); </script> <![endif]--> "\
                  "<style>*{ padding:0; margin:0; box-sizing: border-box;font-family: \"楷体\"; }body,html{ width:100%; height:100%; }img{ -webkit-user-select: none; -moz-user-select: none; -ms-user-select: none; user-select: none; }.container{ max-width:90%; margin:0 auto; padding:80px 0px; }.bg{ display:block; max-width:100%; margin:0px auto; }.btn{ width:400px; margin:0 auto; max-width:100%; margin-top:40px; }.btn a{ float:left; text-decoration: none; width:46.5%; border:1px solid #5298ff; background:#FFA07A; color:#FFF; display:block; height:46px; line-height:44px; text-align:center; font-size:16px; border-radius:3px; overflow: hidden; }.btn .goindex{ margin-right:7%; }.btn .lx{ border: 1px solid #d8d8d8; background: #ffffff; color: #8c8c8c; }@media screen and (max-width: 500px) {.btn{ width:85%; }.btn a{ width:100%; font-size:15px; height:42px; line-height:42px; }.btn .goindex{ margin-right:0; margin-bottom:20px; }}</style> "\
                  "</head> "\
                  "<body> "\
                  "<div style=\"text-align:center;margin:5em 0; font:normal 1em;\"> "\
                  "<h1 style=\"font-size:6em;\"><p style=\"color:#FFA500;\">404</p></h1> "\
                  "</div> "\
                  "<div style=\"text-align:center;margin:4em 0; font:normal 1em;\"> "\
                  "<h1 style=\"font-size:25px;\"><p><font color=\"#FFA500\">找不到请求的参数或者网页</font></p></h1> "\
                  "</div> "\
                  "<div class=\"btn\"> "\
                  "<a href=\"/\" class=\"goindex\">返回首页</a> "\
                  "<a href=\"index.json\" target=\"_blank\" class=\"lx\">进入Json首页</a> "\
                  "<div style=\"clear: both;\"></div> "\
                  "</div> "\
                  "</body>"\
                  "</html>"\
                  "");
  }
  if (server.method() == HTTP_POST)
  {
    data_html = F("{\"error\":\"403\"}");
  }
  server.send(404, F("text/html"), data_html);
  return data_html;
}