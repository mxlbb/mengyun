String web_server_html::JsonServer_index_json()
{
  StaticJsonDocument<0X139> data_json;//0X139
  if (server.args() == false)
  {
    JsonObject data_json_index  = data_json.createNestedObject(F("主页目录(void)"));
    data_json_index[F("0")]   = String(F("{"));
    data_json_index[F("1")]   = String(F("index.php(flie)"));
    data_json_index[F("2")]   = String(F("switch.php(flie)"));
    data_json_index[F("3")]   = String(F("public.php(flie)"));
    data_json_index[F("4")]   = String(F("api.php(flie)"));
    data_json_index[F("5")]   = String(F("help.php(flie)"));
    data_json_index[F("6")]   = String(F("error.php(flie)"));
    data_json_index[F("7")]   = String(F("eeprom.php(flie)"));
    data_json_index[F("8")]   = String(F("}"));
  }
  for (uint8_t data_JsonServer_api_json = 0X0; data_JsonServer_api_json < server.args(); data_JsonServer_api_json++)
  {
    if (String(server.argName(data_JsonServer_api_json)) == String(F("1")) && server.arg(data_JsonServer_api_json) == F("index.php"))
    {
      JsonObject data_json_index_json = data_json.createNestedObject(F("index.php"));
      data_json_index_json[F("地址")] = String(F("/index.php"));
      data_json_index_json[F("类型")] = String(F("文件"));
      data_json_index_json[F("属性")] = String(F("公有"));
      data_json_index_json[F("说明")] = String(F("有目录"));
    }

    if (String(server.argName(data_JsonServer_api_json)) == String("2") && server.arg(data_JsonServer_api_json) == F("switch.php"))
    {
      JsonObject data_json_switch_json = data_json.createNestedObject(F("switch.php"));
      data_json_switch_json[F("地址")] = String(F("/server/switch.php"));
      data_json_switch_json[F("类型")] = String(F("文件"));
      data_json_switch_json[F("属性")] = String(F("私有"));
      data_json_switch_json[F("说明")] = String(F("有目录"));
    }

    if (String(server.argName(data_JsonServer_api_json)) == String("3") && server.arg(data_JsonServer_api_json) == F("public.php"))
    {
      JsonObject data_json_help_json = data_json.createNestedObject(F("public.php"));
      data_json_help_json[F("地址")] = String(F("/server/public.php"));
      data_json_help_json[F("类型")] = String(F("文件"));
      data_json_help_json[F("属性")] = String(F("公有"));
	  data_json_help_json[F("说明")] = String(F("无目录"));
    }

    if (String(server.argName(data_JsonServer_api_json)) == String("4") && server.arg(data_JsonServer_api_json) == F("api.php"))
    {
      JsonObject data_json_api_json = data_json.createNestedObject(F("api.php"));
      data_json_api_json[F("地址")] = String(F("/server/api.php"));
      data_json_api_json[F("类型")] = String(F("文件"));
      data_json_api_json[F("属性")] = String(F("私有"));
      data_json_api_json[F("说明")] = String(F("有目录"));
    }
	
	if (String(server.argName(data_JsonServer_api_json)) == String("5") && server.arg(data_JsonServer_api_json) == F("help.php"))
    {
      JsonObject data_json_help_json = data_json.createNestedObject(F("help.php"));
      data_json_help_json[F("地址")] = String(F("/server/help.php"));
      data_json_help_json[F("类型")] = String(F("文件"));
      data_json_help_json[F("属性")] = String(F("公有"));
      data_json_help_json[F("说明")] = String(F("有目录"));
    }
	
    if (String(server.argName(data_JsonServer_api_json)) == String("6") && server.arg(data_JsonServer_api_json) == F("error.php"))
    {
      JsonObject data_json_error_json = data_json.createNestedObject(F("error.php"));
      data_json_error_json[F("地址")] = String(F("/server/error.php"));
      data_json_error_json[F("类型")] = String(F("文件"));
      data_json_error_json[F("属性")] = String(F("公有"));
      data_json_error_json[F("说明")] = String(F("无目录"));

    }

    if (String(server.argName(data_JsonServer_api_json)) == String("7") && server.arg(data_JsonServer_api_json) == F("eeprom.php"))
    {
      JsonObject data_json_eeprom_json = data_json.createNestedObject(F("eeprom.php"));
      data_json_eeprom_json[F("地址")] = String(F("/server/eeprom.php"));
      data_json_eeprom_json[F("属性")] = String(F("文件"));
      data_json_eeprom_json[F("属性")] = String(F("私有"));
      data_json_eeprom_json[F("说明")] = String(F("无目录，云端配置以及硬件基本配置信息（危险功能）"));
    }
  }
  Serial.println();
  Serial.print(F("生成的JSON文档大小："));
  Serial.println(serializeJson(data_json, Serial));
  return data_json.as<String>();
}