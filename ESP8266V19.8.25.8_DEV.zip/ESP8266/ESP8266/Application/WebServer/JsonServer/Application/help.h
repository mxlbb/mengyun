/*
  链接
  1.用户手册
  2.开发者手册
  3.源码手册
  4.常见问题
*/

String web_server_html::JsonServer_help_json()
{
  StaticJsonDocument<0XFD> data_json;//0XFD
  if (server.args() == false)
  {
    JsonObject data_json_index  = data_json.createNestedObject(F("使用帮助(void)"));
    data_json_index[F("0")]   = String(F("{"));
    data_json_index[F("1")]   = String(F("帮助文档(url)"));
    data_json_index[F("2")]   = String(F("用户手册(url)"));
    data_json_index[F("3")]   = String(F("开发手册(url)"));
    data_json_index[F("4")]   = String(F("源码手册(url)"));
    data_json_index[F("5")]   = String(F("常见问题(url)"));
    data_json_index[F("6")]   = String(F("}"));
  }
  for (uint8_t data_JsonServer_api_json = 0X0; data_JsonServer_api_json < server.args(); data_JsonServer_api_json++)
  {
    if (String(server.argName(data_JsonServer_api_json)) == String("1") && server.arg(data_JsonServer_api_json) == F("帮助文档"))
    {
      JsonObject data_json_user = data_json.createNestedObject(F("帮助文档"));
      data_json_user[F("地址")] = String(F("/help/index.php"));
      data_json_user[F("类型")] = String(F("地址"));
      data_json_user[F("说明")] = String(F("帮助文档"));
    }
	
    if (String(server.argName(data_JsonServer_api_json)) == String("2") && server.arg(data_JsonServer_api_json) == F("用户手册"))
    {
      JsonObject data_json_user = data_json.createNestedObject(F("用户手册"));
      data_json_user[F("地址")] = String(F("/help/user.php"));
      data_json_user[F("类型")] = String(F("地址"));
      data_json_user[F("说明")] = String(F("接口目录"));
    }

    if (String(server.argName(data_JsonServer_api_json)) == String("3") && server.arg(data_JsonServer_api_json) == F("开发手册"))
    {
      JsonObject data_json_dev = data_json.createNestedObject(F("开发手册"));
      data_json_dev[F("地址")] = String(F("/help/dev.php"));
      data_json_dev[F("类型")] = String(F("地址"));
      data_json_dev[F("说明")] = String(F("硬件控制"));
    }

    if (String(server.argName(data_JsonServer_api_json)) == String("4") && server.arg(data_JsonServer_api_json) == F("源码手册"))
    {
      JsonObject data_json_code = data_json.createNestedObject(F("源码手册"));
      data_json_code[F("地址")] = String(F("/help/code.php"));
      data_json_code[F("类型")] = String(F("地址"));
      data_json_code[F("说明")] = String(F("帮助文档"));
    }

    if (String(server.argName(data_JsonServer_api_json)) == String("5") && server.arg(data_JsonServer_api_json) == F("常见问题"))
    {
      JsonObject data_json_problem = data_json.createNestedObject(F("常见问题"));
      data_json_problem[F("地址")] = String(F("/help/problem.php"));
      data_json_problem[F("类型")] = String(F("地址"));
      data_json_problem[F("说明")] = String(F("应用接口"));
    }

  }
  Serial.println();
  Serial.print(F("生成的JSON文档大小："));
  Serial.println(serializeJson(data_json, Serial));
  return data_json.as<String>();
}
