/*
  功能
  1.基本控制
  2.重启硬件
  3.清除配置
*/

String web_server_html::JsonServer_switch_json()
{
  StaticJsonDocument<0X110> data_json;//0X10C
  if (server.args() == false)
  {
    JsonObject data_json_switch  = data_json.createNestedObject(F("运行信息(void)"));
    data_json_switch[F("0")]   = String(F("{"));
    data_json_switch[F("1")]   = String(F("设备名称(String)"));
    data_json_switch[F("2")]   = String(F("查询状态(String)"));
    data_json_switch[F("3")]   = String(F("运行状态(String)"));
    data_json_switch[F("4")]   = String(F("重启硬件(String)"));
    data_json_switch[F("5")]   = String(F("重置配置(String)"));
    data_json_switch[F("6")]   = String(F("}"));
  }

  for (uint8_t data_JsonServer_api_json = 0X0; data_JsonServer_api_json < server.args(); data_JsonServer_api_json++)
  {
    if (String(server.argName(data_JsonServer_api_json)) == String("1") && server.arg(data_JsonServer_api_json) == F("设备名称"))
    {
      JsonObject data_json_name = data_json.createNestedObject(F("设备名称"));
      data_json_name[F("类型")] = String(eeprom.Struct.eeprom_data_scene) + String(eeprom.Struct.eeprom_data_category);
      data_json_name[F("说明")] = String(F("设备的名字，用于区分不同设备"));
    }

    if (String(server.argName(data_JsonServer_api_json)) == String("2") && server.arg(data_JsonServer_api_json) == F("查询状态"))
    {
      JsonObject data_json_run = data_json.createNestedObject(F("查询状态"));
      data_json_run[F("类型")] = String(F("查询"));
      data_json_run[F("查询")] = String(F("GPIO-(int)"));
	  data_json_run[F("说明")] = String(F("查询设备的状态。"));
    }

    if (String(server.argName(data_JsonServer_api_json)) == String("3") && server.arg(data_JsonServer_api_json) == F("运行状态"))
    {
      JsonObject data_json_run = data_json.createNestedObject(F("运行状态"));
      data_json_run[F("类型")] = String(F("开关"));
      JsonArray data_json_run_switch = data_json_run.createNestedArray(F("开关"));
      data_json_run_switch.add(F("开启"));
      data_json_run_switch.add(F("关闭"));
      data_json_run[F("说明")] = String(F("控制设备的状态。"));
    }

    if (String(server.argName(data_JsonServer_api_json)) == String("4") && server.arg(data_JsonServer_api_json) == F("重启硬件"))
    {
      JsonObject data_json_hardware = data_json.createNestedObject(F("重启硬件"));
      data_json_hardware[F("类型")] = String(F("重启"));
      JsonArray data_json_hardware_switch = data_json_hardware.createNestedArray(F("重启"));
      data_json_hardware_switch.add(F("确认"));
      data_json_hardware_switch.add(F("取消"));
      data_json_hardware[F("说明")] = String(F("控制设备的状态。"));
    }

    if (String(server.argName(data_JsonServer_api_json)) == String("5") && server.arg(data_JsonServer_api_json) == F("重置配置"))
    {
      JsonObject data_json_configure = data_json.createNestedObject(F("重置配置"));
      data_json_configure[F("类型")] = String(F("重置"));
      JsonArray data_json_configure_switch = data_json_configure.createNestedArray(F("重置"));
      data_json_configure_switch.add(F("确认"));
      data_json_configure_switch.add(F("取消"));
      data_json_configure[F("说明")] = String(F("清除设备无线网络名称以及密码。"));
    }

  }

  for (uint8_t data_JsonServer_api_json = 0X0; data_JsonServer_api_json < server.args(); data_JsonServer_api_json++)
  {

    if (String(server.argName(data_JsonServer_api_json)) == String(F("查询")))
    {
      for(byte data_switch_gpio = 0X0; data_switch_gpio < 0X10; data_switch_gpio++)
        if (server.arg(data_JsonServer_api_json) == String(F("GPIO-")) + String(data_switch_gpio))
        {
          data_json[String(F("GPIO-")) + String(data_switch_gpio)] = !digitalRead(data_switch_gpio);
        }
    }
	
    if (String(server.argName(data_JsonServer_api_json)) == String(F("开关")))
    {
      if (server.arg(data_JsonServer_api_json) == F("开启"))
      {
        data_json[F("开关")] = F("开启");
#ifdef define_esp8266_input
        System.function_io(F("pinMode"), 0X0, HIGH);
        System.function_io(F("pinMode"), 0X2, HIGH);
#else
        System.function_io(F("pinMode"), 0X0, HIGH);
#endif
      }
      if (server.arg(data_JsonServer_api_json) == F("关闭"))
      {
        data_json[F("开关")] = F("关闭");
#ifdef define_esp8266_input
        System.function_io(F("pinMode"), 0X0, LOW);
        System.function_io(F("pinMode"), 0X2, LOW);
#else
        System.function_io(F("pinMode"), 0X0, LOW);
#endif
      }
    }

    if (String(server.argName(data_JsonServer_api_json)) == String(F("重启")))
    {
      if (server.arg(data_JsonServer_api_json) == F("确认"))
      {
        data_json[F("重启")] = F("确认");
        server.send(200, F("application/json"), data_json.as<String>());
        delay(0X3E8);
        ESP.reset();
      }
      if (server.arg(data_JsonServer_api_json) == F("取消"))
      {
        data_json[F("重启")] = F("取消");
      }
    }

    if (String(server.argName(data_JsonServer_api_json)) == String(F("重置")))
    {
      if (server.arg(data_JsonServer_api_json) == F("确认"))
      {
        data_json[F("重置")] = F("确认");
        ESP.eraseConfig();
      }
      if (server.arg(data_JsonServer_api_json) == F("取消"))
      {
        data_json[F("重置")] = F("取消");
      }
    }
  }
  //Serial.println();
  //Serial.print(F("生成的JSON文档大小："));
  //Serial.println(serializeJson(data_json, Serial));
  return data_json.as<String>();
}
