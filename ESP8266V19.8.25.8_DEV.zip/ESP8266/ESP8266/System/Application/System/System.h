class system_setting
{
  public:
    bool init(const String data_function, const uint8_t data_value, const uint8_t data_option);
    void main();
    String function_esp(const String data_function);
    byte function_io(const String data_function, const uint8_t data_value, const uint8_t data_option);
    system_setting();
    ~system_setting();
} System;

bool system_setting::init(const String data_function, const uint8_t data_value, const uint8_t data_option)
{
  if (data_function == F("pinMode"))
  {
    if (data_option == OUTPUT)
    {
      pinMode(data_value, data_option);
      return true;
    }
    if (data_option == INPUT)
    {
      pinMode(data_value, data_option);
      return true;
    }
  }
  return false;
}

void system_setting::main()
{
  //Serial.begin(1000000);
#ifdef define_esp8266_input
  init(F("pinMode"), 0X0, OUTPUT);
  function_io("pinMode", 0X0, true);
  init(F("pinMode"), 0X2, OUTPUT);
  function_io("pinMode", 0X2, true);
  init(F("pinMode"), 0X15, INPUT);
#else
  init(F("pinMode"), 0X2, INPUT);
  init(F("pinMode"), 0X0, OUTPUT);
#endif
  
  //Di mini pro gpio15 -> g8
  //Di mini pro gpio16 -> g0
}

String system_setting::function_esp(const String data_function)
{
  if (data_function == F("ESP.getCpuFreqMHz()"))        return String(ESP.getCpuFreqMHz()) + "MHz";
  if (data_function == F("ESP.getFreeHeap()"))          return String((float)(ESP.getFreeHeap()) / 0X400) + "KiB";
  if (data_function == F("ESP.getSketchSize()"))		return String((float)(ESP.getSketchSize()) / 0X400) + "KiB";
  if (data_function == F("ESP.getSketchSize()"))        return String(ESP.getSketchSize());
  if (data_function == F("ESP.getVcc()"))               return String(ESP.getVcc());
  if (data_function == F("ESP.getChipId()"))            return String(ESP.getChipId());
  if (data_function == F("ESP.getFlashChipId()"))       return String(ESP.getFlashChipId());
  return "0";
}

byte system_setting::function_io(const String data_function, const uint8_t data_value, const uint8_t data_option)
{
  if (data_function == F("pinMode"))
  {
    pinMode(data_value, data_option);
    return data_option;
  }
  if (data_function == F("analogWrite"))
  {
    analogWrite(data_value, data_option);
    return data_option;
  }
  if (data_function == F("analogRead"))
  {
    analogRead(data_value);
    return data_option;
  }
  if (data_function == F("pinMode"))
  {
    digitalWrite(data_value, data_option);
    return data_option;
  }
  if (data_function == F("pinMode"))
  {
    digitalRead(data_value);
    return data_option;
  }
  return (byte)NULL;
}

system_setting::system_setting() {}

system_setting::~system_setting() {}
