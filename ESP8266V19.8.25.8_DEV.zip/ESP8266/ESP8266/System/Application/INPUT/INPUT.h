/**
  define_esp8266_input为真 GPIO15(D8) -> Vcc
  define_esp8266_input为假 GPIO2(D4) -> Vcc
*/

#ifdef define_esp8266_input
#define LED1  0X0
#define LED2  0X2
#define KEY  0XF
#else
#define LED  0X0
#define KEY  0X2
#endif

bool flag = HIGH;//默认当前灭灯

// 定义记录按键当前状态的变量
bool state_btn;
// 定义记录按键最近一次状态变化的变量，并初始化状态为LOW。
bool lastButtonState = LOW;
// 定义记录最近一次抖动的时间变量，并初始化时间为0毫秒。
unsigned long lastDebounceTime = 0;
// 定义延迟抖动的时间变量
unsigned long debouncdDelay = 60;

void Analog_key()
{
  bool buttonState = digitalRead(KEY);//读取当前按键状态

  if (buttonState != lastButtonState)
  {
    //如果按键发生了变化  则重新设置最近一次抖动的时间
    //方法millis()可以获取当前时间，单位统一为毫秒。
    lastDebounceTime = millis();
  }

  // 判断按键按下状态时间间隔是否大于延迟抖动的时间长度。
  if (millis() - lastDebounceTime > debouncdDelay)
  {
    // 判断当前的按键状态是否和之前有所变化
    if (buttonState != state_btn)
    {
      // 如果发生了变化，
      // 则更新按键状态变量。
      state_btn = buttonState;
      if (state_btn == HIGH)
      {
        //再次确认是否真的按下了按键,是的话就置反当前灯的状态
        flag = !flag;
#ifdef define_esp8266_input
        digitalWrite(LED1, flag);
        digitalWrite(LED2, flag);
#else
        digitalWrite(LED, flag);
#endif

        Serial.print("按键状态");
		Serial.print(KEY);
		Serial.print("LED状态");
		Serial.println(flag);
		
      }
    }
  }
  // 更新按键最近一次状态变化的变量
  lastButtonState = buttonState;
}





