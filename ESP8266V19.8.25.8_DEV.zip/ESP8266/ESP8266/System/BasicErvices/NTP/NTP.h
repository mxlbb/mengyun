/*
  data_udp NTP客户端
  从网络时间协议（NTP）时间服务器获取时间
  演示如何使用data_udp发送数据包和接收数据包
  有关NTP时间服务器和与其通信所需的消息的更多信息，
  参见http://en.wikipedia.org/wiki/network_time_协议
  创建于2010年9月4日
  作者：迈克尔·马戈利斯
  修改日期：2012年4月9日
  作者：汤姆·伊戈
  为ESP8266更新，2015年4月12日
  伊凡·格罗霍特科夫
  此代码在公共域中。
*/
#include <ESP8266WiFi.h>
#include <WiFiUDP.h>
#include <Ticker.h>

#define define_time_adjustment +2     //调整秒数 +N / -N  (UL)
//#define define_time_sha1_switch false  //显示SHA1开关
#define define_time_sha1_security 30  //安全时间


#include <Hash.h>
#include <stdlib.h>
#ifdef define_time_sha1_switch
//#include <stdio.h>
#endif

Ticker data_time_sum_ticker;

IPAddress data_time_server_ip;              			//time.nist.gov ntp服务器地址
const char *data_ntp_server_name = "ntp.ntsc.ac.cn";
const int data_ntp_packet_size = 48;          			//NTP时间戳在消息的前48个字节中
byte data_packet_buffer[data_ntp_packet_size];      	//用于保存传入和传出数据包的缓冲区
unsigned int localPort = 2390;              			//本地端口用于侦听data_udp数据包
//--------------------------------Time------------------------------
unsigned long data_epoch;			//显示时间
char data_time_sha1[0X10];			//显示字符串加密
String data_time_string_print;		//显示时间
//--------------------------------Time------------------------------

WiFiUDP data_udp;

bool data_time_main();
void data_time_sum();
void data_time_print();
void data_send_ntp_packet(IPAddress &address);
class ntp_server;

bool data_time_main()
{
  WiFi.hostByName(eeprom.Struct.eeprom_data_ntp_url, data_time_server_ip);
  data_send_ntp_packet(data_time_server_ip);
  delay(1000);
  int data_cb = data_udp.parsePacket();
  if (!data_cb) Serial.println(F("还没有数据包"));
  else
  {
    Serial.print(F("接收的数据包，长度 = ")), Serial.println(data_cb);
    data_udp.read(data_packet_buffer, data_ntp_packet_size);
    unsigned long data_high_word = word(data_packet_buffer[40], data_packet_buffer[41]);
    unsigned long data_low_word = word(data_packet_buffer[42], data_packet_buffer[43]);
    unsigned long data_secs_since_1900 = data_high_word << 16 | data_low_word;
    Serial.print(F("1900年1月1日以来的秒数 = ")), Serial.println(data_secs_since_1900);
    const unsigned long data_seventy_ears = 2208988800UL;//Unix时间从1970年1月1日开始。几秒钟后，即2208988800：
    data_epoch = data_secs_since_1900 - data_seventy_ears define_time_adjustment/*微调*/;//减去70年：
    return true;
  }
  return false;
}

void data_time_sum()
{
  data_epoch++;
}

void data_time_print()
{
  itoa(data_epoch / define_time_sha1_security, data_time_sha1, 16);
  data_time_string_print = (((((data_epoch + 28800UL) % 86400L) / 3600) < 10) ? "0" : "") +
                           (String)(((data_epoch + 28800UL/*CST+8:00*/ define_time_adjustment/*微调*/) % 86400L) / 3600) + ":" +
                           ((((data_epoch % 3600) / 60) < 10) ? "0" : "") + (String)((data_epoch  % 3600) / 60) + ":" +
                           (((data_epoch % 60) < 10) ? "0" : "") + (String)(data_epoch % 60) + "";
#ifdef define_time_sha1_switch
  Serial.print(F("\nUNIX时间是:")), Serial.print(data_epoch);
  Serial.print(F("\tCST时间是"));
  Serial.print(data_time_string_print); //

  Serial.print(F("\t字符串密钥时间:")), Serial.println(data_time_sha1);
  delay(true);//打印数据缓冲时间
  Serial.print(F("基于时间的SHA1密钥:")), Serial.println(sha1(data_time_sha1));
#endif
}

void data_send_ntp_packet(IPAddress &address)//向给定地址的时间服务器发送NTP请求
{
  Serial.println("正在发送NTP数据包…");//将缓冲区中的所有字节设置为0
  memset(data_packet_buffer, 0, data_ntp_packet_size);//初始化形成NTP请求所需的值（有关数据包的详细信息，请参阅上面的URL）
  data_packet_buffer[0] = 0b11100011;   //li，版本，模式
  data_packet_buffer[1] = 0;     //地层或时钟类型
  data_packet_buffer[2] = 6;     //轮询间隔
  data_packet_buffer[3] = 0xEC;  //对等时钟精度//根延迟和根分散为0的8字节
  data_packet_buffer[12]  = 49;
  data_packet_buffer[13]  = 0x4E;
  data_packet_buffer[14]  = 49;
  data_packet_buffer[15]  = 52;//所有ntp字段现在都有值,可以发送请求时间戳的数据包：
  data_udp.beginPacket(address, 123); //NTP请求到端口123
  data_udp.write(data_packet_buffer, data_ntp_packet_size);
  data_udp.endPacket();
}

class ntp_server
{
  public:
    unsigned long data_time_over = millis(), data_time_start = millis();
    void init();
    void main();
    void sum();
    void print();
    ntp_server();
    ~ntp_server();
} NTP;

void ntp_server::init()
{
  data_time_sum_ticker.attach_ms(1000, data_time_sum);
  data_udp.begin(localPort);
  while (!data_time_main())delay(2000);//注意：当millis归零时启动校准
}

void ntp_server::main()
{
  data_time_over = millis();
  if (data_time_over - data_time_start >= 0X3E8 || (millis() >= false && millis() <= 0X3E8))
  {
    data_time_start = millis();
    print();
  }
}

void ntp_server::sum()
{
  data_time_sum();
}

void ntp_server::print()
{
  data_time_print();
}

ntp_server::ntp_server() {}

ntp_server::~ntp_server() {}