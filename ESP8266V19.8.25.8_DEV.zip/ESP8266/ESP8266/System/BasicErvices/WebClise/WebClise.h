#include <ESP8266HTTPClient.h>
#include <ArduinoJson.h>

class web_clise
{
  public:
    struct server
    {
      bool restart = false;
      String ipv4;
      String ipv6;
      String time;//返回时间
      String sha1;//sha1指纹
    } server;
    void main();
    bool http();
    bool https();
    String json();
    web_clise();
    ~web_clise();
} Web;

void web_clise::main()
{
  if (server.ipv4 != Network.ip(F("ipv4_ip")) || server.ipv6 != Network.ip(F("ipv6_ip")) || server.restart == false)
  {
    server.ipv4 = Network.ip(F("ipv4_ip"));
    server.ipv6 = Network.ip(F("ipv6_ip"));
    if (https() == false)
	{
	  server.restart = false;
	  return;
	}
    else
      server.restart = true;
    if (http() == false)
	{
	  server.restart = false;
	  return;
	}
    else
      server.restart = true;
  }
  //if (WiFi.status() == WL_CONNECTED && millis() % 0X400 >= 0X3E7)clise();
}

bool web_clise::http()
{
  WiFiClient client;

  HTTPClient http;

  Serial.print(F("[HTTP] begin...\n"));
  Serial.println(eeprom.Struct.eeprom_data_http_api);
  if (http.begin(client, eeprom.Struct.eeprom_data_http_api))
  { // HTTP

    Serial.print(F("[HTTP] GET...\n"));
    // start connection and send HTTP header
    int httpCode = http.GET();

    // httpCode will be negative on error
    if (httpCode > 0X0)
    {
      // HTTP header has been send and Server response header has been handled
      Serial.printf("[HTTP] GET... code: %d\n", httpCode);
      // file found at server
      if (httpCode == HTTP_CODE_OK || httpCode == HTTP_CODE_MOVED_PERMANENTLY)
      {
        DynamicJsonDocument data_json_sha1(0X300);
        deserializeJson(data_json_sha1, http.getString());
        JsonObject data_json_obj = data_json_sha1.as<JsonObject>();
        if (String(eeprom.Struct.eeprom_data_web_name)    != data_json_obj[F("服务器名称")].as<String>() ||
            String(eeprom.Struct.eeprom_data_http_url)    != data_json_obj[F("服务器地址")].as<String>() ||
            String(eeprom.Struct.eeprom_data_http_api)    != data_json_obj[F("应用接口")].as<String>() ||
            String(eeprom.Struct.eeprom_data_https_dns)   != data_json_obj[F("DNS地址")].as<String>() ||
            String(eeprom.Struct.eeprom_data_https_sha1)  != data_json_obj[F("DNS指纹")].as<String>() ||
            String(eeprom.Struct.eeprom_data_ntp_url)     != data_json_obj[F("NTP地址")].as<String>()
           )
        {
          strcpy(eeprom.Struct.eeprom_data_web_name,    data_json_obj[F("服务器名称")].as<String>().c_str());
          strcpy(eeprom.Struct.eeprom_data_http_url,    data_json_obj[F("服务器地址")].as<String>().c_str());
          strcpy(eeprom.Struct.eeprom_data_http_api,    data_json_obj[F("应用接口")].as<String>().c_str());
          strcpy(eeprom.Struct.eeprom_data_https_dns,   data_json_obj[F("DNS地址")].as<String>().c_str());
          strcpy(eeprom.Struct.eeprom_data_https_sha1,  data_json_obj[F("DNS指纹")].as<String>().c_str());
          strcpy(eeprom.Struct.eeprom_data_ntp_url,     data_json_obj[F("NTP地址")].as<String>().c_str());
          eeprom.write();
          eeprom.read();
          eeprom.message();
		  Serial.println(F("将新的信息写入EEPROM储存"));
        }
        server.time = data_json_obj[F("同步服务")].as<String>();
        Serial.print(F("同步服务=")), Serial.println(server.time);
        return true;
      }
    }
    else
    {
      Serial.print(F("[HTTP] GET... 失败，错误: "));
      Serial.println(http.errorToString(httpCode).c_str());
      return false;
    }
    http.end();
  }
  else
  {
    Serial.println(F("[HTTPS]无法连接"));
    return false;
  }
  return true;
}

bool web_clise::https()
{
  std::unique_ptr<BearSSL::WiFiClientSecure>client(new BearSSL::WiFiClientSecure);
  client->setFingerprint(eeprom.Struct.eeprom_data_https_sha1);
  HTTPClient https;
  Serial.print(F("[HTTPS] begin...\n"));
  if (https.begin(*client, eeprom.Struct.eeprom_data_https_dns))
  { // HTTPS
    Serial.print(F("[HTTPS] POST...\n"));
    // start connection and send HTTP header
    int httpsCode = https.POST(json().c_str());

    // httpCode will be negative on error
    if (httpsCode > false)
    {
      // HTTP header has been send and Server response header has been handled
      Serial.print(F("[HTTPS] POST请求... 代码: "));
      Serial.println(httpsCode);
      // file found at server
      if (httpsCode == HTTP_CODE_OK || httpsCode == HTTP_CODE_MOVED_PERMANENTLY)
      {
        DynamicJsonDocument data_json(0X300);
        deserializeJson(data_json, https.getString());
        JsonObject data_json_obj = data_json.as<JsonObject>();
        server.time = data_json_obj[F("同步服务")].as<String>();
        Serial.print(F("同步服务=")), Serial.println(server.time);
        return true;
      }
    }
    else
    {
      Serial.print(F("[HTTPS] POST... 失败，错误: "));
      Serial.println(https.errorToString(httpsCode).c_str());
      return false;
    }
    https.end();
  }
  else
  {
    Serial.print(F("[HTTPS]无法连接\n"));
    return false;
  }
  Serial.println(F("正在重新连接服务器..."));
  return true;
}

String web_clise::json()
{
  StaticJsonDocument<0X300> data_https_json;
  JsonObject data_json_message = data_https_json.createNestedObject("公共服务");
  data_json_message[F("云端名称")] = (String)eeprom.Struct.eeprom_data_web_name;
  data_json_message[F("云端地址")] = (String)eeprom.Struct.eeprom_data_http_url;
  data_json_message[F("地址接口")] = (String)eeprom.Struct.eeprom_data_http_api;
  data_json_message[F("域名接口")] = (String)eeprom.Struct.eeprom_data_https_dns;
  data_json_message[F("时间地址")] = (String)eeprom.Struct.eeprom_data_ntp_url;
  data_json_message[F("设备名称")] = String(eeprom.Struct.eeprom_data_scene) + String(eeprom.Struct.eeprom_data_category);
  data_json_message[F("设备SN码")] = (String)ESP.getChipId() + (String)ESP.getFlashChipId();
  data_json_message[F("认证密钥")] = (String)data_time_sha1;
  data_json_message[F("本地IPv4")] = (String)Network.ip(F("ipv4_ip"));
  data_json_message[F("本地IPv6")] = (String)Network.ip(F("ipv6_ip"));
  data_json_message[F("保留地址")] = (String)Network.ip(F("ipv6_retain"));
  data_json_message[F("MAC地址")] = (String)Network.equipment(F("equipment_localmac"));
  data_json_message[F("同步状态")] = server.time;
  return data_https_json.as<String>();
}

web_clise::web_clise() {}


web_clise::~web_clise() {}