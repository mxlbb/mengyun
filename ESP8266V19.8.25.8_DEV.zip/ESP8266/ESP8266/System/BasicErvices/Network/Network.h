/*

   请注意测试smartconfig通过60位密码，无法通过60位以上密码：
   测试结果：60位密码平均通过时间13秒

*/

#include <ESP8266WiFi.h>
#include <AddrList.h>

#define define_smartnetwork_print_debug         false
#define define_smartnetwork_function_swit_time  true
#define define_smartnetwork_network_overtime    0X3A98

class smart_network
{
  public:
    void init();
    void main();
    void message(const bool data_message);
#if define_smartnetwork_function_swit
    long time(const String data_function);
#endif
    void hostname(const String data_function);
    long smartconfig();
    long connect();
    String ip(const String data_ip_char);
    String equipment(const String data_equipment_char);
    smart_network();
    ~smart_network();
} Network;

void smart_network::init()
{
  hostname(String(eeprom.Struct.eeprom_data_scene) + String(eeprom.Struct.eeprom_data_category));
  WiFi.mode(WIFI_STA);
  WiFi.stopSmartConfig();
  message(false);
}

void smart_network::main()
{
  if (WiFi.status() != WL_CONNECTED)
  {
    unsigned long data_time;
    Serial.print(F("网络初始化\n"));
    Serial.print(F("联网用时:"));
    data_time = connect();
    Serial.printf("%6ldms 状态:%s\n", data_time, (data_time < define_smartnetwork_network_overtime) ? "成功" : "失败");
    if (data_time >= define_smartnetwork_network_overtime)
    {
      Serial.print(F("配网用时:"));
      data_time = smartconfig();
      Serial.printf("%6ldms 状态:%s\n", data_time, (data_time < define_smartnetwork_network_overtime) ? "成功" : "失败");
    }
    if (WiFi.status() == WL_CONNECTED)Network.message(true);
  }
}

void smart_network::message(const bool data_message)
{
  Serial.print(F("无线名称:")), Serial.println(equipment(F("equipment_ssid")));
  Serial.print(F("无线密码:")), Serial.println(equipment(F("equipment_psk")));

  switch (data_message)
  {
    case false:
      Serial.print(F("本地地址:")), Serial.println(equipment(F("equipment_localmac")));
      Serial.print(F("网关地址:")), Serial.println(equipment(F("equipment_gatewaymac")));
      Serial.print(F("IPV6保留:")), Serial.println(ip(F("ipv6_retain")).c_str());
      break;
    case true:
      Serial.print(F("信号强度:")), Serial.print(WiFi.RSSI()), Serial.println("dBm");
      Serial.print(F("本地地址:")), Serial.println(equipment(F("equipment_localmac")));
      Serial.print(F("网关地址:")), Serial.println(equipment(F("equipment_gatewaymac")));
      Serial.print(F("IPV4地址:")), Serial.println(ip(F("ipv4_ip")));
      Serial.print(F("IPV4子网:")), Serial.println(ip(F("ipv4_subnetmask")));
      Serial.print(F("IPV4网关:")), Serial.println(ip(F("ipv4_gateway")));
      Serial.print(F("IPV6地址:")), Serial.println(ip(F("ipv6_ip")));
      Serial.print(F("IPV6保留:")), Serial.println(ip(F("ipv6_retain")));
      Serial.print(F("DNS1:")),     Serial.println(ip(F("ip_dns1")));
      Serial.print(F("DNS2:")),     Serial.println(ip(F("ip_dns2")));

#if define_smartnetwork_function_swit //你可以启用define_smartnetwork_print获取函数用法
      Serial.print(F("Network.ip("")函数字符串帮助:")),        Serial.print(ip(F("help")));
      Serial.print(F("Network.equipment("")函数字符串帮助:")), Serial.print(equipment(F("help")));
#endif

      break;
    default:
      break;
  }
}

#if define_smartnetwork_function_swit
long smart_network::time(const String data_function)
{
  unsigned long data_time_over, data_time_start;
  data_time_start = millis();

  if (data_function == F("message(true)"))                        message(true);
  if (data_function == F("message(false)"))                       message(false);
  if (data_function == F("init()"))                               init();
  if (data_function == F("connect()"))                            connect();
  if (data_function == F("smartconfig()"))                        smartconfig();
  if (data_function == F("ip(\"ipv4_ip\")"))                      ip(F("ipv4_ip"));
  if (data_function == F("ip(\"ipv4_subnetmask\")"))              ip(F("ipv4_subnetmask"));
  if (data_function == F("ip(\"ipv4_gateway\")"))                 ip(F("ipv4_gateway"));
  if (data_function == F("ip(\"ipv6_ip\")"))                      ip(F("ipv6_ip"));
  if (data_function == F("ip(\"ipv6_retain\")"))                  ip(F("ipv6_retain"));
  if (data_function == F("ip(\"ip_dns1\")"))                      ip(F("ip_dns1"));
  if (data_function == F("ip(\"ip_dns2\")"))                      ip(F("ip_dns2"));
  if (data_function == F("equipment(\"equipment_ssid\")"))        equipment(F("equipment_ssid"));
  if (data_function == F("equipment(\"equipment_psk\")"))         equipment(F("equipment_psk"));
  if (data_function == F("equipment(\"equipment_localmac\")"))    equipment(F("equipment_localmac"));
  if (data_function == F("equipment(\"equipment_gatewaymac\")"))  equipment(F("equipment_gatewaymac"));
  data_time_over = millis();
  return data_time_over - data_time_start;
}
#endif

void smart_network::hostname(const String data_function)
{
  WiFi.hostname(data_function);
}

long smart_network::smartconfig()
{
  WiFi.beginSmartConfig();
  unsigned long data_time_over = millis(), data_time_start = millis();
  for (; data_time_over - data_time_start < define_smartnetwork_network_overtime; data_time_over = millis(), delay(true))
    if (WiFi.smartConfigDone())
    {
      WiFi.setAutoConnect(true);  // 设置自动连接
      return data_time_over - data_time_start;
    }
  return data_time_over - data_time_start;
}

long smart_network::connect()
{
  WiFi.begin(WiFi.SSID().c_str(), WiFi.psk().c_str());
  unsigned long data_time_over = millis(), data_time_start = millis();
  for (; data_time_over - data_time_start < define_smartnetwork_network_overtime; data_time_over = millis() , delay(true))
    if (WiFi.status() == WL_CONNECTED)return data_time_over - data_time_start;
  return data_time_over - data_time_start;
}

String smart_network::ip(const String data_ip_char)
{
  String ipv4_ip, ipv4_subnet_mask, ipv4_gateway,
         ipv6_ip, ipv6_retain, ip_dns1, ip_dns2;
  for (int data_ip_dns = 0; data_ip_dns < DNS_MAX_SERVERS; data_ip_dns++)
  {
    IPAddress data_dns = WiFi.dnsIP(data_ip_dns);
    if (data_dns.isSet())
    {
      switch (data_ip_dns)
      {
        case false: ip_dns1 = data_dns.toString().c_str(); break;
        case true: ip_dns2 = data_dns.toString().c_str(); break;
      }
    }
  }
  for (auto data_ip : addrList)
  {
    if (data_ip.isV6() && data_ip.isLocal() == false)           ipv6_ip     = data_ip.toString().c_str();
    if (data_ip.isV6() && data_ip.isLocal())                    ipv6_retain = data_ip.toString().c_str();
    if (data_ip.isV6() == false && data_ip.isLocal() == false)  ipv4_ip     = data_ip.toString().c_str();
    if (data_ip.isLegacy())
    {
      ipv4_subnet_mask = data_ip.netmask().toString().c_str();
      ipv4_gateway = data_ip.gw().toString().c_str();
    }
  }

#if define_smartnetwork_print
  Serial.println(F("------------------------------"));
  Serial.print("网络详情\n");
  Serial.print("IPV4\t地址:%s\n", ipv4_ip.c_str());
  Serial.print("IPV4\t子网掩码:%s\n", ipv4_subnet_mask.c_str());
  Serial.print("IPV4\t网关:%s\n", ipv4_gateway.c_str());
  Serial.print("IPV6\t地址:%s\n", ipv6_ip.c_str());
  Serial.print("IPV6\t保留:%s\n", ipv6_retain.c_str());
  Serial.print("DNS1: \t%s\n", ip_dns1.c_str());
  Serial.print("DNS2: \t%s\n", ip_dns2.c_str());
  Serial.println(F("------------------------------"));
#endif

  if (data_ip_char == F("ipv4_ip"))         return ipv4_ip;
  if (data_ip_char == F("ipv4_subnetmask")) return ipv4_subnet_mask;
  if (data_ip_char == F("ipv4_gateway"))    return ipv4_gateway;
  if (data_ip_char == F("ipv6_ip"))         return ipv6_ip;
  if (data_ip_char == F("ipv6_retain"))     return ipv6_retain;
  if (data_ip_char == F("ip_dns1"))         return ip_dns1;
  if (data_ip_char == F("ip_dns2"))         return ip_dns2;
  if (data_ip_char == F("help"))
    return F("\
              Parametric string: \n\
              ipv4_ip\n\
              ipv4_subnetmask\n\
              ipv4_gateway\n\
              ipv6_ip\n\
              ipv6_retain\n\
              ip_dns1\n\
              ip_dns2\n");
  return F("0");
}

String smart_network::equipment(const String data_equipment_char)
{
#if define_smartnetwork_print
  Serial.print("\t%s%s\n", "无线网络：", WiFi.SSID().c_str());
  Serial.print("\t%s%s\n", "无线密码：", WiFi.psk().c_str());
  Serial.print("\t%s%s\n", "设备地址：", WiFi.macAddress().c_str());
  Serial.print("\t%s%s\n", "网关地址：", WiFi.BSSIDstr().c_str());
  Serial.print("\t%s", "子网掩码："), Serial.println(WiFi.subnetMask());
  Serial.print("\t%s", "IP地址："), Serial.print(WiFi.localIP());
  Serial.print("\t%s", "网关地址："), Serial.print(WiFi.gatewayIP());
#endif
  if (data_equipment_char == F("equipment_ssid"))       return WiFi.SSID().c_str();
  if (data_equipment_char == F("equipment_psk"))        return WiFi.psk().c_str();
  if (data_equipment_char == F("equipment_localmac"))   return WiFi.macAddress().c_str();
  if (data_equipment_char == F("equipment_gatewaymac")) return WiFi.BSSIDstr().c_str();
  if (data_equipment_char == F("help"))
    return F("Parametric string: \n\
              equipment_ssid\n\
              equipment_psk\n\
              equipment_localmac\n\
              equipment_gatewaymac\n");
  return F("0");
}

smart_network::smart_network() {}

smart_network::~smart_network() {}
