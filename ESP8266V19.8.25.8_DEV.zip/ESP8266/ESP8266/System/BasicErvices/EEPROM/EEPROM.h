#include <EEPROM.h>

#define define_eeprom_template_debug true
#define define_Struct_eeprom_data_http_api "http://dns.mengyun.org:880/iot/config.php"

static const char define_eeprom_data_http_api[0X50] PROGMEM = define_Struct_eeprom_data_http_api;
static const char define_eeprom_data_scene[0X30]    PROGMEM = "客厅";
static const char define_eeprom_data_category[0X20] PROGMEM = "灯泡";
static const char define_eeprom_data_remarks[0XA00 - 0XE0] PROGMEM = "\n你好，欢迎来到ESP8266硬件服务器！\n你看到的是默认模板信息(EEPROM数据储存)。\n在这里可以存储字符长度：2301。\n请注意：\nFlase只有10W次擦写寿命（数据来自Arduino官网）\n请减少访问间隔，不然引起拥塞。";

class eeprom_rom
{
  public:
    struct data_struct
    {
      bool  eeprom_data_switch_init;
      char  eeprom_data_web_name[0X20];
      char  eeprom_data_http_url[0X50];
      char  eeprom_data_http_api[0X50];
      char  eeprom_data_https_dns[0X50];
      char  eeprom_data_https_sha1[0X30];
      char  eeprom_data_ntp_url[0X50];
      char  eeprom_data_scene[0X30];
      char  eeprom_data_category[0X20];
      char  eeprom_data_remarks[0XA00 - 0XE2];//0X1000 - 0X4 - 0X80
    } Struct;
    void init();
    void main();
    void message();
    void read();
    void write();
    eeprom_rom();
    ~eeprom_rom();
} eeprom;

void eeprom_rom::init()
{
  strcpy(Struct.eeprom_data_http_api, define_eeprom_data_http_api);
  strcpy(Struct.eeprom_data_scene,    define_eeprom_data_scene);
  strcpy(Struct.eeprom_data_category, define_eeprom_data_category);
  strcpy(Struct.eeprom_data_remarks,  define_eeprom_data_remarks);
}

void eeprom_rom::main()
{
  Serial.print(F("测试开始\n读取信息...\n"));
  Struct.eeprom_data_switch_init = true;
  read();
  message();
#if define_eeprom_template_debug
  if (Struct.eeprom_data_switch_init || digitalRead(0X0)) //digitalRead开启恢复默认的API网络地址
  {
    Struct.eeprom_data_switch_init = false;
	ESP.eraseConfig();
    Serial.print(F("初始化默认模板...\n"));
    init();
    Serial.print(F("写入EEPROM储存...\n"));
    write();
    Serial.print(F("读取信息...\n"));
    read();
    message();
  }
#endif
  Serial.print(F("测试完毕...\n"));
}

void eeprom_rom::message()
{
  Serial.print(F("EEPROM服务器名称:")),  Serial.println(Struct.eeprom_data_web_name);
  Serial.print(F("EEPROM服务器地址:")),  Serial.println(Struct.eeprom_data_http_url);
  Serial.print(F("EEPROM API 地址:")),  Serial.println(Struct.eeprom_data_http_api);
  Serial.print(F("EEPROM DNS 地址:")),  Serial.println(Struct.eeprom_data_https_dns);
  Serial.print(F("EEPROM DNS 指纹:")),  Serial.println(Struct.eeprom_data_https_sha1);
  Serial.print(F("EEPROM NTP 地址:")),  Serial.println(Struct.eeprom_data_ntp_url);
  Serial.print(F("EEPROM 数据场景:")),  Serial.println(Struct.eeprom_data_scene);
  Serial.print(F("EEPROM 数据类别:")),  Serial.println(Struct.eeprom_data_category);
  Serial.print(F("EEPROM 数据存储:")),  Serial.println(Struct.eeprom_data_remarks);
}

void eeprom_rom::read()
{
  EEPROM.begin(0X1000);
  uint8_t *pointer = (uint8_t*)(&Struct);
  for (uint16_t data_sum = 0X0; data_sum < sizeof(Struct); data_sum++)
    *(pointer + data_sum) = EEPROM.read(data_sum);
  EEPROM.end();
}

void eeprom_rom::write()
{
  EEPROM.begin(0X1000);
  uint8_t *pointer = (uint8_t*)(&Struct);
  for (uint16_t data_sum = 0X0; data_sum < sizeof(Struct); data_sum++)
    EEPROM.write(data_sum, *(pointer + data_sum));
  delay(0XA);
  EEPROM.end();//EEPROM.commit();
}

eeprom_rom::eeprom_rom() {}

eeprom_rom::~eeprom_rom() {}
