/****************************************************************

  ESP8266基础框架：EEPROM、Network、NTP、System、WebClise

*****************************************************************/

#include "./BasicErvices/BasicErvices.h"
#include "./Application/Application.h"

void BasicErvices_setup();
void BasicErvices_loop();

//#define define_esp8266_input 		//请确认硬件类型引脚是否只有GPIO-0和GPIO-2是请定义

#define define_esp8266_BasicErvices true 

void BasicErvices_setup()
{
  System.main();
  eeprom.main();
  Network.init();
  while (WiFi.status() != WL_CONNECTED)Network.main();
  Web.http();
#if define_esp8266_BasicErvices
  NTP.init();
#endif
}

void BasicErvices_loop()
{
#if define_esp8266_BasicErvices
  NTP.main();
#endif
  Network.main();
  Web.main();
  Analog_key();
}