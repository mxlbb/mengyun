function function_main()
{
    var data_user = document.getElementById("DataUser").value;
    var data_passwork = document.getElementById("DataPasswork").value;
    if (data_user == "")
    {
        alert("用户名不能为空！");
        return;
    }
    if (data_passwork == "")
    {
        alert("密码不能为空！");
        return;
    }
    var data_url = "http://" + data_user + ":" + data_passwork + "@" + location.host + "/admin.html";
    self.location = data_url;
}

function function_json(data_post, content_type, data_uri, data_params, callback) {
    var xmlhttp;
    var ReturnChar;
    if (window.XMLHttpRequest) xmlhttp = new XMLHttpRequest(); // IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
    else xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); // IE6, IE5 浏览器执行代码
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            callback(xmlhttp.responseText);
            //document.getElementById("myDiv").innerHTML=xmlhttp.responseText;
        }
    }
    xmlhttp.open(data_post, data_uri, true);
    xmlhttp.setRequestHeader("Content-type", content_type);
    xmlhttp.send(data_params);
}

function function_title() {
    function_json("POST", "application/x-www-form-urlencoded", "/server/public.php", "",
    function(returnData) {
        var Return_char = "";
        returnData = eval('(' + returnData + ')');
        Return_char += "<a href=\"/\">" + returnData.公共服务.设备名称 + "</a>";
        Return_char += "&nbsp;-&nbsp;";
        Return_char += "<a target=\"view_window\" href=\"" + returnData.公共服务.服务器地址 + "\">" + returnData.公共服务.服务器名称 + "</a>";
        document.getElementById("function_title").innerHTML = Return_char;
    });
}

function function_site() {
    function_json("POST", "application/x-www-form-urlencoded", "/server/public.php", "",
    function(returnData) {
        var Return_char = "";
        returnData = eval('(' + returnData + ')');
        Return_char += "<title>" + returnData.公共服务.设备名称 + "&nbsp;-&nbsp;" + returnData.公共服务.服务器名称 + "</title>";
        document.getElementById("function_site").innerHTML = Return_char;
    });
}

function function_public() {
    function_json("POST", "application/x-www-form-urlencoded", "/server/public.php", "",
    function(returnData) {
        var Return_char;
        returnData = eval('(' + returnData + ')');
        for (var childElement in returnData) {
            Return_char = "<table><dt>" + childElement + "</dt><tbody>";
            var subchildElement = returnData[childElement];
            for (var subchild in subchildElement) {
                Return_char += "<tr><td style=\"text-align:right;vertical-align:middle;\">" + subchild + ":</td>";
                Return_char += "<td style=\"vertical-align:middle;\"><input value=\"" + subchildElement[subchild] + "\" /></td></tr>";
            }
        }
        Return_char += "</tbody></table>";
        document.getElementById("function_public").innerHTML = Return_char;
    });
}

function function_help() {
    function_json("POST", "application/x-www-form-urlencoded", "/server/help.php", "1=全部文档",
    function(returnData) {
        var Return_char;
        returnData = eval('(' + returnData + ')');
        for (var childElement in returnData) {
            Return_char = "<table><dt>" + childElement + "</dt><tbody>";
            var subchildElement = returnData[childElement];
            for (var subchild in subchildElement) {
                Return_char += "<tr><td style=\"text-align:right;vertical-align:middle;\">" + subchild + ":</td>";
                Return_char += "<td style=\"vertical-align:middle;\"><input value=\"" + subchildElement[subchild] + "\" /></td></tr>";
            }
        }
        Return_char += "</tbody></table>";
        document.getElementById("function_help").innerHTML = Return_char;
    });
}




