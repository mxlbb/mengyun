function function_switch_query() {
    function_json("POST", "application/x-www-form-urlencoded", "/server/switch.php", "查询=GPIO-0",
    function(returnData) {
        returnData = eval('(' + returnData + ')');
		var GPIO_STATUS = returnData['GPIO-0'];
        if (GPIO_STATUS)
        document.getElementById("function_switch").innerHTML = "运行状态:&nbsp;已开启&nbsp;";
        else
        document.getElementById("function_switch").innerHTML = "运行状态:&nbsp;已关闭&nbsp;";
    });
}

function function_switch_open() {
    function_json("POST", "application/x-www-form-urlencoded", "/server/switch.php", "开关=开启",
    function(returnData) {
        returnData = eval('(' + returnData + ')');
        if (returnData.开关 == "开启") document.getElementById("function_switch").innerHTML = "运行状态:&nbsp;已开启&nbsp;";
    });
}

function function_switch_close() {
    function_json("POST", "application/x-www-form-urlencoded", "/server/switch.php", "开关=关闭",
    function(returnData) {
        returnData = eval('(' + returnData + ')');
        if (returnData.开关 == "关闭") document.getElementById("function_switch").innerHTML = "运行状态:&nbsp;已关闭&nbsp;";
    });
}

function function_reboot() {
    function_json("POST", "application/x-www-form-urlencoded", "/server/switch.php", "重启=确认",
    function(returnData) {
        returnData = eval('(' + returnData + ')');
        if (returnData.重启 == "确认") alert("重启成功\n请耐心等待硬件接入网络！");
    });
}

function function_reset() {
    function_json("POST", "application/x-www-form-urlencoded", "/server/switch.php", "重置=确认",
    function(returnData) {
        returnData = eval('(' + returnData + ')');
        if (returnData.重置 == "确认");
        alert("重置成功\n请重启硬件并重新设置网无线网络！");
    });
}

function function_message() {
    function_json("POST", "application/x-www-form-urlencoded", "/server/api.php", "2=实时信息",
    function(returnData) {
        var Return_char;
        returnData = eval('(' + returnData + ')');
        for (var childElement in returnData) {
            Return_char = "<table><dt>" + childElement + "</dt><tbody>";
            var subchildElement = returnData[childElement];
            for (var subchild in subchildElement) {
                Return_char += "<tr><td style=\"text-align:right;vertical-align:middle;\">" + subchild + ":</td>";
                Return_char += "<td style=\"vertical-align:middle;\"><input value=\"" + subchildElement[subchild] + "\" /></td></tr>";
            }
        }
        Return_char += "</tbody></table>";
        document.getElementById("function_message").innerHTML = Return_char;
    });
}

function function_network() {
    function_json("POST", "application/x-www-form-urlencoded", "/server/api.php", "3=网络状态",
    function(returnData) {
        var Return_char;
        returnData = eval('(' + returnData + ')');
        for (var childElement in returnData) {
            Return_char = "<table><dt>" + childElement + "</dt><tbody>";
            var subchildElement = returnData[childElement];
            for (var subchild in subchildElement) {
                Return_char += "<tr><td style=\"text-align:right;vertical-align:middle;\">" + subchild + ":</td>";
                Return_char += "<td style=\"vertical-align:middle;\"><input value=\"" + subchildElement[subchild] + "\" /></td></tr>";
            }
        }
        Return_char += "</tbody></table>";
        document.getElementById("function_network").innerHTML = Return_char;
    });
}

function function_security() {
    function_json("POST", "application/x-www-form-urlencoded", "/server/api.php", "4=安全认证",
    function(returnData) {
        var Return_char;
        returnData = eval('(' + returnData + ')');
        for (var childElement in returnData) {
            Return_char = "<table><dt>" + childElement + "</dt><tbody>";
            var subchildElement = returnData[childElement];
            for (var subchild in subchildElement) {
                Return_char += "<tr><td style=\"text-align:right;vertical-align:middle;\">" + subchild + ":</td>";
                Return_char += "<td style=\"vertical-align:middle;\"><input value=\"" + subchildElement[subchild] + "\" /></td></tr>";
            }
        }
        Return_char += "</tbody></table>";
        document.getElementById("function_security").innerHTML = Return_char;
    });
}

function function_eeprom() {
    function_json("POST", "application/x-www-form-urlencoded", "/server/eeprom.php", "1=全部数据",
    function(returnData) {
        var Return_char;
        returnData = eval('(' + returnData + ')');
        for (var childElement in returnData) {
            Return_char = "<table><dt>" + childElement + "</dt><tbody>";
            var subchildElement = returnData[childElement];
            for (var subchild in subchildElement) {
                Return_char += "<tr><td style=\"text-align:right;vertical-align:middle;\">" + subchild + ":</td>";
                Return_char += "<td style=\"vertical-align:middle;\"><input value=\"" + subchildElement[subchild] + "\" /></td></tr>";
            }
        }
        Return_char += "</tbody></table>";
        document.getElementById("function_eeprom").innerHTML = Return_char;
    });
}
