<?php
/* vim: set expandtab tabstop=4 shiftwidth=4: */
// +----------------------------------------------------------------------+
// | PHP version 5                                                        |
// +----------------------------------------------------------------------+
// | Copyright (c) 1997-2004 The PHP Group                                |
// +----------------------------------------------------------------------+
// | This source file is subject to version 3.0 of the PHP license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available through the world-wide-web at the following url:           |
// | http://www.php.net/license/3_0.txt.                                  |
// | If you did not receive a copy of the PHP license and are unable to   |
// | obtain it through the world-wide-web, please send a note to          |
// | license@php.net so we can mail you a copy immediately.               |
// +----------------------------------------------------------------------+
// | Authors: Original Author <author@example.com>                        |
// |          Your Name <you@example.com>                                 |
// +----------------------------------------------------------------------+
//
// $Id:$

$_data_var = false;
if ($_GET['1'] == "全部功能" || $_POST['1'] == "全部功能") $_data_var = true;
if ($_data_var) echo "{";
if ($_data_var || ($_GET['2'] == "实时信息" || $_POST['2'] == "实时信息")) {
    if (!$_data_var) echo "{";
    echo "\"实时信息\": {\"型号\":\"ESP8266EX\",\"CPU\":\"160MHz\",\"RAM\":\"39.10KiB\",\"ROM\":\"525.39KiB\",\"本地时间\":\"15:18:24\",\"信号强度\":\"-59dBm\"}";
    if (!$_data_var) echo "}";
}
if ($_data_var) echo ",";
if ($_data_var || ($_GET['3'] == "网络状态" || $_POST['3'] == "网络状态")) {
    if (!$_data_var) echo "{";
    echo "\"网络状态\":{\"无线名称\":\"mxlbb_2.4G\",\"无线密码\":\"13226253380\",\"本机MAC\":\"60:01:94:1C:2A:13\",\"网关MAC\":\"9C:71:3A:27:94:0A\",\"IPV4地址\":\"10.1.1.209\",\"IPV4子网\":\"255.255.255.0\",\"IPV4网关\":\"10.1.1.1\",\"IPV6地址\":\"\",\"IPV6保留\":\"fe80::6201:94ff:fe1c:2a13\",\"DNS1\":\"10.1.1.1\",\"DNS2\":\"\"}";
    if (!$_data_var) echo "}";
}
if ($_data_var) echo ",";
if ($_data_var || ($_GET['4'] == "安全认证" || $_POST['4'] == "安全认证")) {
    if (!$_data_var) echo "{";
    echo "\"安全认证\":{\"用户\":\"1845779\",\"密码\":\"1589487\",\"密钥生命周期\":6,\"安全认证密钥\":\"e0cf4f84810c0938b06db7d5134df4af54180664\"}";
if (!$_data_var) echo "}";
}
if ($_data_var) echo "}";
?>

