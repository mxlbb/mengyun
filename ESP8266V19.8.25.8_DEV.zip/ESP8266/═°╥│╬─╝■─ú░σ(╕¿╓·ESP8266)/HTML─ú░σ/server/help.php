<?php

/*

Help是最后编写，预期的连接地址是

帮助文档：/help/index.html
用户手册：/help/user.html
开发手册：/help/dev.html
源码手册：/help/code.html
常见问题：/help/problem.html

*/

$_data_var = false;
if ($_GET['1'] == "全部文档" || $_POST['1'] == "全部文档")
echo "{\"使用帮助(void)\":{\"0\":\"{\",\"1\":\"全部文档(function)\",\"2\":\"帮助文档(url)\",\"3\":\"用户手册(url)\",\"4\":\"开发手册(url)\",\"5\":\"源码手册(url)\",\"6\":\"常见问题(url)\",\"7\":\"}\"}}";
?>
