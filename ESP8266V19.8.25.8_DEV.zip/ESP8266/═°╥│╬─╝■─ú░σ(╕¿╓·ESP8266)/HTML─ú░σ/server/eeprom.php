<?php
if ($_GET['1'] == "全部数据" || $_POST['1'] == "全部数据")//只要提交任意参数即可下发数据，不提交参数无法下发数据
echo "{\"存储数据\":{\"EEPROM服务器名称\":\"梦云物联\",\"EEPROM服务器地址\":\"https://dns.mengyun.org:8443/\",\"EEPROM API 地址\":\"http://dns.mengyun.org:880/iot/config.php\",\"EEPROM DNS 地址\":\"https://dns.mengyun.org:8443/iot/dns.php\",\"EEPROM DNS 指纹\":\"728e326c8c76b740f19367b6ef9ab7c1d5b2854f\",\"EEPROM NTP 地址\":\"ntp.ntsc.ac.cn\",\"EEPROM 数据场景\":\"客厅\",\"EEPROM 数据类别\":\"灯泡\",\"EEPROM 数据存储\":\"\\n你好，欢迎来到ESP8266硬件服务器！\\n你看到的是默认模板信息(EEPROM数据储存)。\\n在这里可以存储字符长度：2301。\\n请注意：\\nFlase只有10W次擦写寿命（数据来自Arduino官网）\\n请减少访问间隔，不然引起拥塞。\"}}";
?>
