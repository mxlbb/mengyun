<?php
   class data_json
   {
       public $通信类型 = "POST/JSON";
       public $上传数据 = "dns.php?iot=data";
       public $查询状态 = "dns.php?iot=query";
   };
   $data_send = new data_json();
   echo json_encode($data_send, JSON_UNESCAPED_UNICODE);
?>