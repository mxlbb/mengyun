<?php
if ($_GET['iot'] == "data")
{
    function_data_write();
}
if ($_GET['iot'] == "query")
{
    $data_send = file_get_contents('php://input');
    $data_send = json_decode($data_send);
    $data_sn = $data_send->{'设备信息'}->{'设备SN码'};
    $data_mac = $data_send->{'设备信息'}->{'MAC地址'};
    function_data_read($data_sn, $data_mac);
}
?>

<?php
function function_data_read($data_sn, $data_mac)
{
  
    $data_db = sha1($data_sn . $data_mac);
    if (is_file('./DATA/' . $data_db . '.data'))
    {
        $data_db = file_get_contents("./DATA/{$data_db}.data");
        $data_db = json_decode($data_db);
        $data_sn = $data_db->{'公共服务'}->{'设备SN码'};
        $data_mac = $data_db->{'公共服务'}->{'MAC地址'};
        $data_ipv4 = $data_db->{'公共服务'}->{'本地IPv4'};
        $data_ipv6 = $data_db->{'公共服务'}->{'本地IPv6'};
        $data_synchronization = $data_db->{'公共服务'}->{'同步状态'};
        define("SN", $data_sn);
        define("MAC", $data_mac);
        define("IPv4", $data_ipv4);
        define("IPv6", $data_ipv6);
        define("Synchronize", $data_synchronization);
        class data_json
        {
            public $设备SN码 = SN;
            public $MAC地址 = MAC;
            public $IPv4 = IPv4;
            public $IPv6 = IPv6;
            public $同步状态 = Synchronize;
        }
        $data_send = new data_json();
        echo json_encode($data_send, JSON_UNESCAPED_UNICODE);
    }
}
?>

<?php
function function_data_write()
{
    $data_send = file_get_contents('php://input');
    $data_send = mb_convert_encoding($data_send, 'UTF-8');
    //$data_send = '{"公共服务":{"服务器名称":"梦云物联","服务器地址":"https://dns.mengyun.org:8443/","接口地址":"http://dns.mengyun.org:880/iot/config.php?1=223","域名地址":"https://dns.mengyun.org:8443/iot/dns.php","时间地址":"ntp.ntsc.ac.cn","设备名称":"客厅灯泡","设备SN码":"18457791589487","认证密钥":"31baba0","本地IPv4":"10.1.1.209","本地IPv6":"","保留地址":"fe80::6201:94ff:fe1c:2a13","MAC":"60:01:94:1C:2A:13","同步状态":"2019年07月29日06:08:20"}}';
    $data_json = json_decode($data_send);
    header("Content-Type: text/html; charset=UTF-8");
    $data_sn = $data_json->{'公共服务'}->{'设备SN码'};
    $data_mac = $data_json->{'公共服务'}->{'MAC地址'};
    $data_db = sha1($data_sn . $data_mac);
    $data_read_sn;
    $data_read_mac;
    $data_read_db;
    $data_write_sn;
    $data_write_mac;
    $data_write_db;
    $file_db = fopen("./DATA/{$data_db}.data", "w");
    fwrite($file_db, $data_send);
    fclose($file_db);
    define("Synchronize", date("Y年m月d日H:i:s"));
    class data_json
    {
        public $同步服务 = Synchronize;
    }
    $data_send = new data_json();
    echo json_encode($data_send, JSON_UNESCAPED_UNICODE);
}
?>

