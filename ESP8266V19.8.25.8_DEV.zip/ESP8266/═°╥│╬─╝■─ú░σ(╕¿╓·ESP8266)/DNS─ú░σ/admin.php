<?php

//function_data_read("184577915894870");
//function_data_read("60:01:94:1C:2A:13");

$data_char = $_GET['id'];
$stime=microtime(true); 
$a = function_data_cache($data_char);
if ($a == NULL) {
  //-------------------------------------------------
    function_data_DATA($data_char);
    $a = function_data_cache($data_char);
    echo $a;
  //-------------------------------------------------
} else echo $a;
$etime=microtime(true);//获取程序执行结束的时间
$total=$etime-$stime;   //计算差值
echo "<br />执行时间为：{$total} 秒";

function function_data_DATA($data_query) {
    chdir('DATA');
    $data_DATA_files;
    $data_cache_files;
    $data_files;
    //echo getcwd();
    $dh = opendir(getcwd());
    while (false !== ($filename = readdir($dh))) {
        $files[] = $filename;
    }
    rsort($files);
    for ($data_temp = 0X0; is_file($files[$data_temp]); $data_temp++) {
        if (is_file($files[$data_temp])) {
            $data_DATA_files = "./DATA/" . $files[$data_temp];
            $data_cache = file_get_contents($files[$data_temp]);
            $data_cache = json_decode($data_cache);
            $data_sn = $data_cache->{'公共服务'}->{'设备SN码'};
            $data_mac = $data_cache->{'公共服务'}->{'MAC地址'};
            if (!strnatcmp($data_query, $data_sn)) {
                $data_cache_files = $data_sn;
                break;
            }
            if (!strnatcmp($data_query, $data_mac)) {
                $data_cache_files = $data_mac;
                break;
            }
        }
    }
    chdir('../');
    chdir('cache');
    $data_files = fopen($data_cache_files . ".data", "w");
    fwrite($data_files, $data_DATA_files);
    fclose($data_files);
    chdir('../');
  return false;
}
function function_data_cache($data_query) {
    if (is_file('./cache/' . $data_query . '.data')) {
        $data_query = file_get_contents("./cache/{$data_query}.data");
        if (is_file($data_query)) {
            $data_query = file_get_contents("{$data_query}");
            return $data_query;
        } else {
            return NULL;
        }
        echo $data_query;
        return $data_query;
    } else {
        return NULL;
    }
}
?>




