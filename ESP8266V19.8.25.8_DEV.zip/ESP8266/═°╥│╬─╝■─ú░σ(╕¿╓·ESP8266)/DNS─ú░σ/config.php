<?php
    define("Synchronize", date("Y年m月d日H:i:s"));
    class data_json
    {
        public $服务器名称 = "梦云物联";
        public $服务器地址 = "https://dns.mengyun.org:8443/";
        public $应用接口 = "http://dns.mengyun.org:880/iot/config.php";
        public $DNS地址 = "https://dns.mengyun.org:8443/iot/dns.php?iot=data";
        public $DNS指纹 = "728e326c8c76b740f19367b6ef9ab7c1d5b2854f";
        public $NTP地址 = "ntp1.aliyun.com";
        public $同步服务 = Synchronize;
    };
    $data_send = new data_json();
    echo json_encode($data_send, JSON_UNESCAPED_UNICODE);
?>
