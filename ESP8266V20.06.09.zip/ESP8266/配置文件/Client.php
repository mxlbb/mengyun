<?php
//echo 'OK';
//$dataIf=false;

if($_GET['client']=='http')
{
    //echo '{"Address":"https://mxlbb.bj01.bdysite.com/ipv6/server.php?client=https","Singerprint":[18,93,239,118,143,109,22,38,57,205,53,81,64,193,90,188,226,42,20,103],"Message":"{\\"ipv4IP\\":\\"10.168.1.205\\",\\"ipv4Mask\\":\\"255.255.255.0\\",\\"ipv4Gateway\\":\\"10.168.1.1\\",\\"ipv4Mac\\":\\"F4:CF:A2:6B:F6:61\\",\\"ipv6Mac\\":\\"fe80::f6cf:a2ff:fe6b:f661\\",\\"ipv6IP\\":\\"2408:84f3::f6cf:a2ff:fe6b:f661\\",\\"ipDns1\\":\\"10.168.1.1\\"}"}';
    echo '{"Code":200,"Address":"https://mxlbb.bj01.bdysite.com/ipv6/server.php?client=https","Singerprint":[18,93,239,118,143,109,22,38,57,205,53,81,64,193,90,188,226,42,20,103]}';
    $dataIf=true;
    $DATA_GET=$_GET['client'];
    $myfile = fopen($DATA_GET.'.txt', "w");
    fwrite($myfile, '{"'.$_GET['client'].'":"'.file_get_contents("php://input").'"}');
    fclose($myfile);
    $dataIf=true;
}

if($_GET['client']=='https')
{
    if(1)
    echo file_get_contents("php://input");
    else
    echo '{"ipv6Mac":"fe80::f6cf:a2ff:fe6b:f661","ipv4Mac":"F4:CF:A2:6B:F6:61","ipv6":"2408:84f3::f6cf:a2ff:fe6b:f661","ipv4":"10.168.1.205","Message","这是测试消息"}';
    $dataIf=true;
    $DATA_GET=$_GET['client'];
    $myfile = fopen($DATA_GET.'.txt', "w");
    fwrite($myfile, '{"'.$_GET['client'].'":"'.file_get_contents("php://input").'"}');
    fclose($myfile);
    $dataIf=true;
}

if($_GET['client']=='data')
{
    $DATA_GET=$_GET['client'];
    $myfile = fopen($DATA_GET.'.txt', "w");
    fwrite($myfile, '{"'.$_GET['client'].'":"'.file_get_contents("php://input").'"}');
    fclose($myfile);
    $dataIf=true;
}

if($dataIf)
{
    //echo "这是一台数据服务器！";
}

//echo "这是一台数据服务器！";
?>