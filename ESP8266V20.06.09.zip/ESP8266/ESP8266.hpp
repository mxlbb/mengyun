/*
  撰写功能文件
  https服务端
  SQL数据库
  按键有bug
*/

//#include "./Test/https.hpp"
//#include "./src/ALiYun/Variable.hpp"
#include "./src/Basic/Api.hpp"
#include "./src/WS/WebSocket.hpp"

void ESP8266Setup();
void ESP8266loop();

void ESP8266Setup()
{
  // Serial.begin(921600);
  //Serial.begin(74880);
  //Serial.setDebugOutput(true);
  Sensor.begin();
  Files.begin();
  Files.Write("/Client.db", "http://mxlbb.bj01.bdysite.com/ipv6/server.php?client=http");
  Files.Write("/Parameter.db", "{\"OS\":\"RTOS\",\"Device\":\"MengYun-Test\",\"CPU\":\"ESP8266EX\",\"MHZ\":160,\"RAM\":409600,\"ROM\":409600}");
  Files.end();
  NetWork.begin(17);
  WSbegin();
  //ALiYun_Setup();
}

void ESP8266loop()
{
  Sensor.Switch("void");
  if (WiFi.status() != WL_CONNECTED)
  {
    if (NetWork.Admin())
    {
      String serverData;
      serverData = Client.Client(Api.Http(), Api.Parameter(), NetWork.IP());
      Serial.print("本地数据：\n");
      Serial.println(NetWork.IP());
      Serial.print("服务器返回数据：\n");
      Serial.println(serverData);
    }
  }
  else
  {
    //if (digitalRead(0))Sensor.Switch("void");
    WSServer();
    //ALiYun_Loop();
  }
}
