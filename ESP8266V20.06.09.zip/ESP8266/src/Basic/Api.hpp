/*
   项目使用了 499916 字节，占用了 (47%) 程序存储空间。最大为 1044464 字节。
   全局变量使用了31728字节，(38%)的动态内存，余留50192字节局部变量。最大为81920字节。
*/


#include "Client.hpp"
#include "Base64.hpp"
#include "Files.hpp"
#include "Network.hpp"
#include "Sensor.hpp"
#include "Status.hpp"

#define defineRun

#ifndef defineRun
#define defineOperateIndependently
#endif
#undef defineRun

#include <CmdParser.hpp>
#include <ArduinoJson.h>

class ClassApi
{
  public:
    ClassApi();
    ~ClassApi();
  public:
    CmdParser cmdParser;
  public:
    String begin(const String beginData);
    String Shell(const String shellData);
    String Api(const String apiData);
    String Http();
    String Parameter();
    String Help();
} Api;

#ifdef defineOperateIndependently

void setup()
{
  Serial.begin(74880);
  //delay(100);
  Serial.println(Api.begin("17"));
  const String var = F("[\"{\",\"Sensor.Buzzer Content=1023\",\"Sensor.LightWarm Content=512\",\"Sensor.LightCold Content=512\",\"Client.Client Address=\\\"http://mxlbb.bj01.bdysite.com/ipv6/server.php?client=http\\\" Parameter=\\\"ESP8266\\\" Content=\\\"测试文字：萌小狸宝宝\\\"\",\"}\"]");
  Serial.println(Api.Shell(var));
  Serial.println(F("测试完成"));
}

int sum = 0;
void loop()
{
  if (Serial.available())
  {
    const String comData = Serial.readStringUntil('\n');
    Serial.print(F("API测试: "));
    Serial.println(comData);
    Serial.println(Api.Api(comData));
  }
  //delay(30000);
}

#endif
#undef defineOperateIndependently

ClassApi::ClassApi() {}
ClassApi::~ClassApi() {}

String ClassApi::begin(String beginData)
{
  Api("Sensor.begin");
  Api("Sensor.Init");
  beginData = "NetWork.begin Content=" + beginData.toInt();
  Api(beginData);
  return F("[true]");
}

String ClassApi::Shell(const String shellData)
{
  String returnData;
  const size_t apiSize = JSON_ARRAY_SIZE(0X100) + shellData.length();
  DynamicJsonDocument shellJson(apiSize);
  DynamicJsonDocument wsSned(apiSize);
  deserializeJson(shellJson, shellData);

  for (uint32_t shellTest = 0; shellTest < shellJson.size(); shellTest++)
  {
    wsSned.add(Api(shellJson[shellTest].as<String>()));
  }
  serializeJsonPretty(wsSned, returnData);
  shellJson.clear();
  wsSned.clear();
  return returnData;
}

String ClassApi::Api(const String apiData)
{
  const uint32_t cmdInt = apiData.length();
  char apiDatachar[cmdInt];
  strcpy(apiDatachar, apiData.c_str());
  cmdParser.setOptKeyValue(true);
  if (cmdParser.parseCmd(apiDatachar) != CMDPARSER_ERROR)
  {
#if 0
    Serial.print(F("Command: "));
    Serial.println(cmdParser.getCommand());
    Serial.print(F("Size of parameter: "));
    Serial.println(cmdParser.getParamCount());
#endif
    if (cmdParser.equalCommand_P(PSTR("Client.Client")))return Client.Client(cmdParser.getValueFromKey_P(PSTR("Address")), cmdParser.getValueFromKey_P(PSTR("Parameter")), cmdParser.getValueFromKey_P(PSTR("Content")));
    if (cmdParser.equalCommand_P(PSTR("Client.http")))return Client.http(cmdParser.getValueFromKey_P(PSTR("Address")));
    if (cmdParser.equalCommand_P(PSTR("Client.https")))return Client.https(cmdParser.getValueFromKey_P(PSTR("Address")), cmdParser.getValueFromKey_P(PSTR("Content")));
    if (cmdParser.equalCommand_P(PSTR("Base64.Encode")))return Base64.Encode(cmdParser.getValueFromKey_P(PSTR("Content")));
    if (cmdParser.equalCommand_P(PSTR("Base64.Decode")))return Base64.Decode(cmdParser.getValueFromKey_P(PSTR("Content")));
    if (cmdParser.equalCommand_P(PSTR("Files.format")))return Files.format() ? F("[true]") : F("[false]");
    if (cmdParser.equalCommand_P(PSTR("Files.begin")))return Files.begin() ? F("[true]") : F("[false]");
    if (cmdParser.equalCommand_P(PSTR("Files.end")))return Files.end() ? F("[true]") : F("[false]");
    if (cmdParser.equalCommand_P(PSTR("Files.ListDir")))return Files.ListDir(cmdParser.getValueFromKey_P(PSTR("Address")));
    if (cmdParser.equalCommand_P(PSTR("Files.Read")))return Files.Read(cmdParser.getValueFromKey_P(PSTR("Address")));
    if (cmdParser.equalCommand_P(PSTR("Files.Write")))return Files.Write(cmdParser.getValueFromKey_P(PSTR("Address")), cmdParser.getValueFromKey_P(PSTR("Content"))) ? F("[true]") : F("[false]");
    if (cmdParser.equalCommand_P(PSTR("Files.Append")))return Files.Append(cmdParser.getValueFromKey_P(PSTR("Address")), cmdParser.getValueFromKey_P(PSTR("Content"))) ? F("[true]") : F("[false]");
    if (cmdParser.equalCommand_P(PSTR("Files.Rename")))return Files.Rename(cmdParser.getValueFromKey_P(PSTR("Address")), cmdParser.getValueFromKey_P(PSTR("ReAddress"))) ? F("[true]") : F("[false]");
    if (cmdParser.equalCommand_P(PSTR("Files.Delete")))return Files.Delete(cmdParser.getValueFromKey_P(PSTR("Address"))) ? F("[true]") : F("[false]");
    if (cmdParser.equalCommand_P(PSTR("NetWork.Test")))return NetWork.Test();
    if (cmdParser.equalCommand_P(PSTR("NetWork.begin")))
    {
      String testData = cmdParser.getValueFromKey_P(PSTR("Content"));
      NetWork.begin(testData.toInt());
      return F("[true]");
    }
    if (cmdParser.equalCommand_P(PSTR("NetWork.Admin")))return NetWork.Admin() ? F("[true]") : F("[false]");
    if (cmdParser.equalCommand_P(PSTR("NetWork.Scan")))return NetWork.Scan();
    if (cmdParser.equalCommand_P(PSTR("NetWork.Connect")))
    {
      const size_t jsonSize = JSON_ARRAY_SIZE(1);
      DynamicJsonDocument connect(jsonSize);
      connect.add(NetWork.Connect());
      String connectReturn;
      serializeJson(connect, connectReturn);
      connect.clear();
      return connectReturn;
    }
    if (cmdParser.equalCommand_P(PSTR("NetWork.SmartConfig")))
    {
      const size_t jsonSize = JSON_ARRAY_SIZE(1);
      DynamicJsonDocument smartConfig(jsonSize);
      smartConfig.add(NetWork.SmartConfig());
      String smartConfigReturn;
      serializeJson(smartConfig, smartConfigReturn);
      smartConfig.clear();
      return smartConfigReturn;
    }
    if (cmdParser.equalCommand_P(PSTR("NetWork.Reset")))return NetWork.Reset() ? F("[true]") : F("[false]");
    if (cmdParser.equalCommand_P(PSTR("NetWork.IP")))return NetWork.IP();
    if (cmdParser.equalCommand_P(PSTR("Sensor.Test")))return Sensor.Test();
    if (cmdParser.equalCommand_P(PSTR("Sensor.begin")))
    {
      Sensor.begin();
      return F("[true]");
    }
    if (cmdParser.equalCommand_P(PSTR("Sensor.Init")))
    {
      Sensor.Init();
      return F("[true]");
    }
    if (cmdParser.equalCommand_P(PSTR("Sensor.PIR")))return Sensor.PIR() ? F("[true]") : F("[false]");
    if (cmdParser.equalCommand_P(PSTR("Sensor.MQ2")))
    {
      const size_t jsonSize = JSON_ARRAY_SIZE(1);
      DynamicJsonDocument mq2(jsonSize);
      mq2.add(Sensor.MQ2());
      String mq2Return;
      serializeJson(mq2, mq2Return);
      mq2.clear();
      return mq2Return;
    }
    if (cmdParser.equalCommand_P(PSTR("Sensor.Thermometer")))return Sensor.Thermometer();
    if (cmdParser.equalCommand_P(PSTR("Sensor.Buzzer")))
    {
      String testData = cmdParser.getValueFromKey_P(PSTR("Content"));
      Sensor.Buzzer(testData.toInt());
      const size_t jsonSize = JSON_ARRAY_SIZE(1);
      DynamicJsonDocument buzzer(jsonSize);
      buzzer.add(testData.toInt());
      String buzzerReturn;
      serializeJson(buzzer, buzzerReturn);
      buzzer.clear();
      return buzzerReturn;
    }
    if (cmdParser.equalCommand_P(PSTR("Sensor.LightWarm")))
    {
      String testData = cmdParser.getValueFromKey_P(PSTR("Content"));
      Sensor.LightWarm(testData.toInt());
      const size_t jsonSize = JSON_ARRAY_SIZE(1);
      DynamicJsonDocument lightWarm(jsonSize);
      lightWarm.add(testData.toInt());
      String lightWarmReturn;
      serializeJson(lightWarm, lightWarmReturn);
      lightWarm.clear();
      return lightWarmReturn;
    }
    if (cmdParser.equalCommand_P(PSTR("Sensor.LightCold")))
    {
      String testData = cmdParser.getValueFromKey_P(PSTR("Content"));
      Sensor.LightCold(testData.toInt());
      const size_t jsonSize = JSON_ARRAY_SIZE(1);
      DynamicJsonDocument lightCold(jsonSize);
      lightCold.add(testData.toInt());
      String lightColdReturn;
      serializeJson(lightCold, lightColdReturn);
      lightCold.clear();
      return lightColdReturn;
    }
    if (cmdParser.equalCommand_P(PSTR("Sensor.Switch")))
    {
      return Sensor.Switch(cmdParser.getValueFromKey_P(PSTR("Content"))) ? F("[true]") : F("[false]");
    }
    if (cmdParser.equalCommand_P(PSTR("Status.Core")))return Status.Core();
    if (cmdParser.equalCommand_P(PSTR("Status.All")))return Status.All();
    if (cmdParser.equalCommand_P(PSTR("ESP.restart")))ESP.restart();
    if (cmdParser.equalCommand_P(PSTR("ESP.reset")))ESP.reset();
    if (cmdParser.equalCommand_P(PSTR("Api.Client")))return Http();
    if (cmdParser.equalCommand_P(PSTR("Api.Parameter")))return Parameter();
    if (cmdParser.equalCommand_P(PSTR("Api.Help")))return Help();
  }
  return F("[NULL]");
}

String ClassApi::Http()
{
  String clientData;
  if (Files.begin())
  {
    clientData = Files.Read(F("/Client.db"));
  }
  Files.end();
  return clientData;
}

String ClassApi::Parameter()
{
  String parameterData;
  if (Files.begin())
  {
    parameterData = Files.Read(F("/Parameter.db"));
  }
  Files.end();
  return parameterData;
}

String ClassApi::Help()
{
  String helpData;
  if (Files.begin())
  {
    helpData = Files.Read(F("/Api.json"));
  }
  Files.end();
  return helpData;
}
