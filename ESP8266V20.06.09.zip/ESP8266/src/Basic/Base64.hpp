#include <rBase64.h>

//#define defineRun

#ifndef defineRun
#define defineOperateIndependently
#endif

class ClassBase64
{
  public:
    ClassBase64();
    ~ClassBase64();
  public:
    String Encode(const String encodeData);
    String Decode(const String decodeData);
} Base64;

#ifdef defineOperateIndependently

void setup()
{
  Serial.begin(74880);
  Serial.println();
  Serial.println(Base64.Encode(F("Hello There, I am doing Good.")));
  Serial.println(Base64.Decode(F("SGVsbG8gVGhlcmUsIEkgYW0gZG9pbmcgR29vZC4=")));
}

void loop() {}

#endif
#undef defineOperateIndependently

ClassBase64::ClassBase64() {}

ClassBase64::~ClassBase64() {}

String ClassBase64::Encode(const String encodeData)
{
  if (rbase64.encode(encodeData) == RBASE64_STATUS_OK)
    return rbase64.result();
  return F("error");
}

String ClassBase64::Decode(const String decodeData)
{
  if (rbase64.decode(decodeData) == RBASE64_STATUS_OK)
    return rbase64.result();
  return F("error");
}
