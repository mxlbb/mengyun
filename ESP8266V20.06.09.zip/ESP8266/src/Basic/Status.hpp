#include <ArduinoJson.h>
#include <ESP8266WiFi.h>

#define defineRun

#ifndef defineRun
#define defineOperateIndependently
#endif

class __Object__Status__;

class __Object__Status__
{
  public:
    __Object__Status__();
    ~__Object__Status__();
  public:
    String Core();
    String All();
} Status;

#ifdef defineOperateIndependently

void setup()
{
  Serial.begin(74880);
  Serial.println(Status.Core());
  Serial.println(Status.All());
}

void loop() {}

#endif
#undef defineRun
#undef defineOperateIndependently

__Object__Status__::__Object__Status__() {}
__Object__Status__::~__Object__Status__() {}

String __Object__Status__::Core()
{
  const size_t __JSON__SIZE__ = JSON_OBJECT_SIZE(0X7) + 0X64;
  DynamicJsonDocument __ESP__DATA__JSON__(__JSON__SIZE__);
  __ESP__DATA__JSON__[F("getMaxFreeBlockSize")] = ESP.getMaxFreeBlockSize();
  __ESP__DATA__JSON__[F("getCpuFreqMHz")] = ESP.getCpuFreqMHz();
  __ESP__DATA__JSON__[F("getFlashChipId")] = ESP.getFlashChipId();
  __ESP__DATA__JSON__[F("getFlashChipRealSize")] = ESP.getFlashChipRealSize();
  __ESP__DATA__JSON__[F("getSketchSize")] = ESP.getSketchSize();
  String __ESP__RETURN__;
  serializeJsonPretty(__ESP__DATA__JSON__, __ESP__RETURN__);
  __ESP__DATA__JSON__.clear();
  return __ESP__RETURN__;
}

String __Object__Status__::All()
{
  const size_t __JSON__SIZE__ = JSON_OBJECT_SIZE(0X13) + 0X2A0;
  DynamicJsonDocument __ESP__DATA__JSON__(__JSON__SIZE__);
  __ESP__DATA__JSON__[F("getFreeHeap")] = ESP.getFreeHeap();
  __ESP__DATA__JSON__[F("getHeapFragmentation")] = ESP.getHeapFragmentation();
  __ESP__DATA__JSON__[F("getMaxFreeBlockSize")] = ESP.getMaxFreeBlockSize();
  __ESP__DATA__JSON__[F("getSdkVersion")] = ESP.getSdkVersion();
  __ESP__DATA__JSON__[F("getCoreVersion")] = ESP.getCoreVersion();
  __ESP__DATA__JSON__[F("getFullVersion")] = ESP.getFullVersion();
  __ESP__DATA__JSON__[F("getBootVersion")] = ESP.getBootVersion();
  __ESP__DATA__JSON__[F("getBootMode")] = ESP.getBootMode();
  __ESP__DATA__JSON__[F("getCpuFreqMHz")] = ESP.getCpuFreqMHz();
  __ESP__DATA__JSON__[F("getFlashChipId")] = ESP.getFlashChipId();
  __ESP__DATA__JSON__[F("getFlashChipRealSize")] = ESP.getFlashChipRealSize();
  __ESP__DATA__JSON__[F("getFlashChipSize")] = ESP.getFlashChipSize();
  __ESP__DATA__JSON__[F("getFlashChipSpeed")] = ESP.getFlashChipSpeed();
  __ESP__DATA__JSON__[F("getFlashChipMode")] = ESP.getFlashChipMode();
  __ESP__DATA__JSON__[F("getFlashChipSizeByChipId")] = ESP.getFlashChipSizeByChipId();
  __ESP__DATA__JSON__[F("getSketchSize")] = ESP.getSketchSize();
  __ESP__DATA__JSON__[F("getResetReason")] = ESP.getResetReason();
  __ESP__DATA__JSON__[F("getResetInfo")] = ESP.getResetInfo();
  __ESP__DATA__JSON__[F("getCycleCount")] = ESP.getCycleCount();
  String __ESP__RETURN__;
  serializeJsonPretty(__ESP__DATA__JSON__, __ESP__RETURN__);
  __ESP__DATA__JSON__.clear();
  return __ESP__RETURN__;
}
