#include <ArduinoJson.h>
#include <WiFiClient.h>
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>

#define defineRun

#ifndef defineRun
#define defineOperateIndependently
#endif


#ifdef defineOperateIndependently

#define defineSSID F("萌小狸宝宝")
#define definePSk F("13226253380")

#endif
class ClassClient
{
  public:
    ClassClient();
    ~ClassClient();
  public:
    String Client(const String clientAddress, const String clientParameter, const String clientMessage);
    String http(const String httpJsonString);
    String https(const String httpsJsonString, const String httpsMsg);
} Client;

#ifdef defineOperateIndependently

uint32_t sum = 0;

void setup()
{

  Serial.begin(74880);
  Serial.println();
  WiFi.mode(WIFI_STA);
}

void loop()
{
  if (WiFi.status() != WL_CONNECTED)
  {
    WiFi.begin(defineSSID, definePSk);
    while (WiFi.status() != WL_CONNECTED)
    {
      Serial.printf(".");
      delay(1000);
    }
    Serial.println(WiFi.localIP());
  }
  if (WiFi.status() == WL_CONNECTED)
  {
    String Address = F("http://mxlbb.bj01.bdysite.com/ipv6/server.php?client=http");
    String Parameter = F("ESP8266");
    String Message = F("这是测试文本消息！");
    String DATA = Client.Client(Address, Parameter, Message);
    Client.~ClassClient();
    Serial.printf("{\"序号\":%d,\"DATA\":\"%s\"}\n", sum++, DATA.c_str());
    //delay(1000);
  }
}

#endif
#undef defineSSID
#undef definePSk
#undef defineOperateIndependently

ClassClient::ClassClient() {}

ClassClient::~ClassClient() {}

String ClassClient::Client(const String clientAddress, const String clientParameter, const String clientMessage)
{
  String clientData;
  size_t jsonSize = JSON_OBJECT_SIZE(2) + (clientAddress.length() + clientParameter.length()) * 2;
  DynamicJsonDocument clientDataJson(jsonSize);
  clientDataJson["Address"] = clientAddress;
  clientDataJson["Parameter"] = clientParameter;
  serializeJsonPretty(clientDataJson, clientData);
  clientDataJson.clear();
  String clientReturn = https(http(clientData), clientMessage);
  jsonSize = JSON_OBJECT_SIZE(2) + clientReturn.length();
  DynamicJsonDocument clientJsonReturn(jsonSize);
  deserializeJson(clientJsonReturn, clientReturn);
  clientReturn = clientJsonReturn[F("Message")].as<String>();
  clientJsonReturn.clear();
  return clientReturn;
}

String ClassClient::http(const String httpJsonString)
{
  WiFiClient client;
  HTTPClient http;
  String httpReturn;
  const size_t jsonSize = JSON_OBJECT_SIZE(2) + httpJsonString.length();
  DynamicJsonDocument httpJsonData(jsonSize);
  DynamicJsonDocument httpData(jsonSize);
  deserializeJson(httpJsonData, httpJsonString);
  if (http.begin(client, httpJsonData[F("Address")].as<const char*>())) // HTTP
  {
    int httpCode = http.POST(httpJsonData[F("Parameter")].as<const char*>());
    httpJsonData.clear();
    if (httpCode > 0)
    {
      if (httpCode == HTTP_CODE_OK || httpCode == HTTP_CODE_MOVED_PERMANENTLY)
      {
        httpReturn = http.getString();
        http.end();
        return httpReturn;
      }
    }
    else
    {
      httpData[F("Code")] = http.errorToString(httpCode);
    }
    http.end();
  }
  else
  {
    httpData[F("Code")] = NULL;
  }
  serializeJsonPretty(httpData, httpReturn);
  httpData.clear();
  httpJsonData.clear();
  //http.end();
  return httpReturn;
}

String ClassClient::https(const String httpsJsonString, const String httpsMsg)
{
  uint8_t httpsFingerprint[20];
  size_t jsonSize = JSON_ARRAY_SIZE(20) + JSON_OBJECT_SIZE(3) + httpsJsonString.length() + httpsMsg.length();
  DynamicJsonDocument httpsJsonData(jsonSize);
  jsonSize = JSON_OBJECT_SIZE(2) + httpsJsonString.length() + httpsMsg.length();
  DynamicJsonDocument httpsData(jsonSize);
  deserializeJson(httpsJsonData, httpsJsonString);
  for (int httpsTest = 0; httpsTest < 20; httpsTest++)httpsFingerprint[httpsTest] = httpsJsonData[F("Singerprint")][httpsTest].as<unsigned int>();
  std::unique_ptr<BearSSL::WiFiClientSecure>client(new BearSSL::WiFiClientSecure);
  client->setFingerprint(httpsFingerprint);
  HTTPClient https;
  if (https.begin(*client, httpsJsonData[F("Address")].as<const char*>()))// HTTPS
  {
    int httpCode = https.POST(httpsMsg.c_str());
    if (httpCode > 0)
    {
      if (httpCode == HTTP_CODE_OK || httpCode == HTTP_CODE_MOVED_PERMANENTLY)
      {
        httpsData[F("Code")] = httpCode;
        httpsData[F("Message")] = https.getString();
      }
    }
    else
    {
      httpsData[F("Code")] = httpCode;
    }
  }
  else
  {
    httpsData[F("Code")] = NULL;
  }
  String httpsReturn;
  serializeJsonPretty(httpsData, httpsReturn);
  httpsData.clear();
  httpsJsonData.clear();
  //https.end();
  return httpsReturn;
}
