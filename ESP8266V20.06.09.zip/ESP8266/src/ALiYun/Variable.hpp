#include "Sensor.hpp"
#include "Network.hpp"
#include <ArduinoJson.h>
#include <ESP8266WiFi.h>
#include <AliyunIoTSDK.h>

#define defneGetTime 1
#define defineBuzzer 15
#define defineLightWarmIO 12
#define defineLightColdIO 14
#define PRODUCT_KEY "a1Auvt2LBxc"
#define DEVICE_NAME "Test"
#define DEVICE_SECRET "lmDL2xAEHvPQ7zDP3yvwrR9XW82M7kYw"
#define REGION_ID "cn-shanghai"

bool    pir;
bool    lightSwitch = true; //主灯开关
int     colorTemperature = 4500; //冷暖色温
int     colorTemperatureWarm = 50;
int     colorTemperatureCold = 50;
int     brightness = 100; //明暗度
float   co = 0; //一氧化碳浓度
bool    buzzer = false; //蜂鸣器
float   indoorTemperature = 37; //温度
float   currentHumidity = 75; //湿度
bool    detectEanbled = false; //启用人体感应
//String    error; //故障上报
String  allData; //数据
String  aLiYunApi; //设备接口
unsigned int allDataSum = '1'; //数据
static  WiFiClient espClient;

void ALiYun_Setup();
void ALiYun_Loop();
void LightSwitch();       //主灯开关
void ColorTemperature();  //冷暖色温
void Brightness();        //明暗度
void CO();                //一氧化碳浓度
void Buzzer();            //蜂鸣器
void IndoorTemperature();//温度
void CurrentHumidity();   //湿度
void DetectEanbled();     //启用人体感应
void Error();             //故障上报
void AllData();           //数据
void ALiYunApi();         //设备接口

void BDLightSwitch(JsonVariant dataJson);       //主灯开关
void BDColorTemperature(JsonVariant dataJson);  //冷暖色温
void BDBrightness(JsonVariant dataJson);        //明暗度
void BDCO(JsonVariant dataJson);                //一氧化碳浓度
void BDBuzzer(JsonVariant dataJson);            //蜂鸣器
void BDIndoorTemperature(JsonVariant dataJson);//温度
void BDCurrentHumidity(JsonVariant dataJson);   //湿度
void BDDetectEanbled(JsonVariant dataJson);     //启用人体感应
void BDError(JsonVariant dataJson);             //故障上报
void BDAllData(JsonVariant dataJson);           //数据
void BDALiYunApi(JsonVariant dataJson);         //设备接口

void LightSwitch()
{
  if (lightSwitch)
  {
    ColorTemperature();
    Brightness();
    //lightSwitch = true;
  }
  else
  {
    Sensor.LightWarm(0);
    Sensor.LightCold(0);
    //lightSwitch = false;
  }
  AliyunIoTSDK::send("LightSwitch", lightSwitch);
}

void ColorTemperature()
{
  colorTemperatureCold = (colorTemperature - 3000) / 30;
  colorTemperatureWarm = 100 - colorTemperatureCold;
  Sensor.LightWarm(colorTemperatureWarm);
  Sensor.LightCold(colorTemperatureCold);
}

void Brightness()
{
  Sensor.LightWarm(colorTemperatureWarm * brightness * 0.1024);
  Sensor.LightCold(colorTemperatureCold * brightness * 0.1024);
}

void CO()
{
  if (co != Sensor.MQ2())
  {
    co = Sensor.MQ2();
    AliyunIoTSDK::send("CO", co);
  }
}

void Buzzer()
{
  if (buzzer && pir)
    Sensor.Buzzer(3885);
  else
    noTone(defineBuzzer);
}

void IndoorTemperature()
{
  const size_t capacity = JSON_OBJECT_SIZE(6) + 0X20;
  DynamicJsonDocument doc(capacity);
  deserializeJson(doc, Sensor.Thermometer());
  if (indoorTemperature != doc["温度"])
    indoorTemperature = doc["温度"];
  doc.clear();
}

void CurrentHumidity()
{
  const size_t capacity = JSON_OBJECT_SIZE(6) + 0X20;
  DynamicJsonDocument doc(capacity);
  deserializeJson(doc, Sensor.Thermometer());
  if (currentHumidity != doc["湿度"])
    currentHumidity = doc["湿度"];
  doc.clear();
}

void DetectEanbled()
{
  LightSwitch();
  AliyunIoTSDK::send("LightSwitch", detectEanbled);
}

void Error()
{
  //AliyunIoTSDK::send("DetectEanbled", error);
}

void AllData()
{
  LightSwitch(); delay(1000);      //主灯开关
  ColorTemperature(); delay(1000); //冷暖色温
  Brightness(); delay(1000);       //明暗度
  CO(); delay(1000);               //一氧化碳浓度
  Buzzer(); delay(1000);           //蜂鸣器
  IndoorTemperature(); delay(1000); //温度
  CurrentHumidity(); delay(1000);  //湿度
  DetectEanbled(); delay(1000);    //启用人体感应
  Error(); delay(1000);            //故障上报
  AllData(); delay(1000);          //数据
  //ALiYunApi(); delay(1000);        //设备接口
}


void ALiYunApi()
{
  //Api.Api(aLiYunApi);
  AliyunIoTSDK::send("ALiYunApi", (char*)aLiYunApi.c_str());
}


void BDLightSwitch(JsonVariant dataJson)
{
  lightSwitch = dataJson["LightSwitch"].as<bool>();
  LightSwitch();
}

void BDColorTemperature(JsonVariant dataJson)
{
  colorTemperature = dataJson["ColorTemperature"];
  ColorTemperature();
  AliyunIoTSDK::send("ColorTemperature", colorTemperature);
}

void BDBrightness(JsonVariant dataJson)
{
  brightness = dataJson["Brightness"];
  Brightness();
  AliyunIoTSDK::send("Brightness", brightness);
}

void BDCO(JsonVariant dataJson)
{
  co = dataJson["CO"];
  CO();
}

void BDBuzzer(JsonVariant dataJson)
{
  buzzer = dataJson["Buzzer"];
  Buzzer();
  AliyunIoTSDK::send("Buzzer", buzzer);
}

void BDIndoorTemperature(JsonVariant dataJson)
{
  dataJson["IndoorTemperature"];
  IndoorTemperature();
}

void BDCurrentHumidity(JsonVariant dataJson)
{
  dataJson["CurrentHumidity"];
  CurrentHumidity();
}

void BDDetectEanbled(JsonVariant dataJson)
{
  //if (dataJson["DetectEanbled"])
  detectEanbled = dataJson["DetectEanbled"];
  if (detectEanbled)
  {
    DetectEanbled();
    Buzzer();
  }
}

void BDError(JsonVariant dataJson)
{
  dataJson["Error"];
  Error();
}

void BDAllData(JsonVariant dataJson)
{
  dataJson["AllData"];
  AllData();
  if (allDataSum == 0XFFFF)
    allDataSum = 1;
  else
    allDataSum++;
  allData = "所有数据更新完成：";
  allData += (String)allDataSum;
  AliyunIoTSDK::send("AllData", (char*)allData.c_str());
}


void BDALiYunApi(JsonVariant dataJson)
{
  aLiYunApi = dataJson["ALiYunApi"].as<String>();
  ALiYunApi();
}


void ALiYun_Setup()
{
  AliyunIoTSDK::begin(espClient, PRODUCT_KEY, DEVICE_NAME, DEVICE_SECRET, REGION_ID);
  AliyunIoTSDK::bindData("LightSwitch", BDLightSwitch);
  AliyunIoTSDK::bindData("ColorTemperature", BDColorTemperature);
  AliyunIoTSDK::bindData("Brightness", BDBrightness);
  AliyunIoTSDK::bindData("CO", BDCO);
  AliyunIoTSDK::bindData("Buzzer", BDBuzzer);
  AliyunIoTSDK::bindData("IndoorTemperature", BDIndoorTemperature);
  AliyunIoTSDK::bindData("CurrentHumidity", BDCurrentHumidity);
  AliyunIoTSDK::bindData("DetectEanbled", BDDetectEanbled);
  AliyunIoTSDK::bindData("Error", BDError);
  AliyunIoTSDK::bindData("AllData", BDAllData);
  AliyunIoTSDK::bindData("ALiYunApi", BDALiYunApi);
}

void ALiYun_Loop()
{
  AliyunIoTSDK::loop();
  if (millis() % (60 * 1000) <= defneGetTime) //每分钟
  {
    IndoorTemperature();//温度
    CurrentHumidity();   //湿度
    AliyunIoTSDK::send("IndoorTemperature", indoorTemperature);
    AliyunIoTSDK::send("CurrentHumidity", currentHumidity);
  }
  if (!pir || millis() % (2 * 1000) <= defneGetTime)
  {
    if (detectEanbled)
    {
      pir = Sensor.PIR();
      lightSwitch = pir;
      Buzzer();
    }
    if (pir || millis() % (10 * 1000) <= defneGetTime)DetectEanbled();
    if (pir || millis() % (2 * 1000) <= defneGetTime)AliyunIoTSDK::send("AlarmState", pir);
    if (co >= 1)CO(); //一氧化碳浓度
  }
  //ALiYunApi();
}


#undef defneGetTime
#undef defineBuzzer
#undef defineLightWarmIO
#undef defineLightColdIO
#undef PRODUCT_KEY
#undef DEVICE_NAME
#undef DEVICE_SECRET
#undef REGION_ID
