#include <ArduinoJson.h>
#include <ESP8266WiFi.h>
#include <AddrList.h>

#define defineRun

#ifndef defineRun
#define defineOperateIndependently
#endif
#define dataTime 0X3A98

class ClassNetWork
{
  public:
    ClassNetWork();
    ~ClassNetWork();
  public:
    String Test();
    String begin(const uint8_t hostName);
    bool Admin();
    String Scan();
    uint32_t Connect();
    uint32_t SmartConfig();
    bool Reset();
    String IP();
} NetWork;

#ifdef defineOperateIndependently

void setup()
{
  Serial.begin(74880);
  Serial.println(NetWork.begin(17));
  for (int test = 0XFF; test > 0 ; test--)
  {
    Serial.printf("循环次数剩余：%d\n", test);
    Serial.println(NetWork.Test());
    delay(2000);
  }
}

void loop() {}

#endif
#undef defineOperateIndependently

ClassNetWork::ClassNetWork() {}

ClassNetWork::~ClassNetWork() {}

String ClassNetWork::Test()
{
  String testData;
  if (WiFi.status() == WL_CONNECTED)
    testData = IP();
  if (Admin())
  {
    testData = F("{\"");
    testData += WiFi.SSID().c_str();
    testData += F("\":");
    testData += F("\"联网失败\"}");
  }
  return testData;
}

String ClassNetWork::begin(const uint8_t hostName)
{
  String beginData = F("MengYun");
  switch (hostName)
  {
    case 1: beginData += F("-Water_Purifier"); break;
    case 2: beginData += F("-Electric_blanket"); break;
    case 3: beginData += F("-Gateway"); break;
    case 4: beginData += F("-Electric_pressure_cooker"); break;
    case 5: beginData += F("-Boiler"); break;
    case 6: beginData += F("-Automatic_door"); break;
    case 7: beginData += F("-Electric_kettle"); break;
    case 8: beginData += F("-Clothes_dryer"); break;
    case 9: beginData += F("-Dehumidifier"); break;
    case 10: beginData += F("-Cat's_eye"); break;
    case 11: beginData += F("-Refrigerator"); break;
    case 12: beginData += F("-Window_pusher"); break;
    case 13: beginData += F("-Air_conditioner"); break;
    case 14: beginData += F("-Clothes_rod"); break;
    case 15: beginData += F("-Breaking_machine"); break;
    case 16: beginData += F("-Oven"); break;
    case 17: beginData += F("-Light"); break;
    case 18: beginData += F("-Curtain"); break;
    case 19: beginData += F("-Yuba"); break;
    case 20: beginData += F("-Socket"); break;
    case 21: beginData += F("-Wall_switch"); break;
    case 22: beginData += F("-Camera"); break;
    case 23: beginData += F("-Water_heater"); break;
    case 24: beginData += F("-HVAC_external_controller"); break;
    case 25: beginData += F("-Dishwasher"); break;
    case 26: beginData += F("-Floor_heating"); break;
    case 27: beginData += F("-Humidifier"); break;
    case 28: beginData += F("-Heater"); break;
    case 29: beginData += F("-Rice_cooker"); break;
    case 30: beginData += F("-Washing_machine"); break;
    case 31: beginData += F("-Smart_door_lock"); break;
    case 32: beginData += F("-Mosquito_killer"); break;
    case 33: beginData += F("-Fan"); break;
    case 34: beginData += F("-Air_purifier"); break;
    case 35: beginData += F("-Range_hood"); break;
    case 36: beginData += F("-Home_dimming_panel"); break;
    default: beginData = F("MengYun"); break;
  }
  const String beginDataTest = beginData;
  WiFi.mode(WIFI_STA);
  WiFi.hostname(beginDataTest);
  return beginDataTest;
}

bool ClassNetWork::Admin()
{
  if (WiFi.status() != WL_CONNECTED)
  {
    String adminDataMAC = Scan();
    const size_t jsonSize = adminDataMAC.length();
    DynamicJsonDocument admin(jsonSize);
    deserializeJson(admin, adminDataMAC);
    adminDataMAC = admin[WiFi.SSID()][F("BSSIDstr")].as<String>();
    admin.clear();
    if (adminDataMAC == WiFi.BSSIDstr())
    {
      if (Connect() < dataTime) return true;
    }
    else
    {
      if (SmartConfig() < dataTime)
        return true;
    }
  }
  return false;
}

String ClassNetWork::Scan()
{
  WiFi.scanNetworks();
  const size_t jsonSize = WiFi.scanComplete() * (JSON_OBJECT_SIZE(true) + JSON_OBJECT_SIZE(0X6) + WiFi.scanComplete() * 0X80);
  DynamicJsonDocument scan(jsonSize);
  if (WiFi.scanComplete() != false)
  {
    for (int test = 0; test < WiFi.scanComplete(); ++test)
    {
      JsonObject scanData = scan.createNestedObject(WiFi.SSID(test));
      scanData[F("SSID")] = WiFi.SSID(test);
      scanData[F("BSSIDstr")] = WiFi.BSSIDstr(test);
      scanData[F("RSSI")] = WiFi.RSSI(test);
      scanData[F("channel")] = WiFi.channel(test);
      switch (WiFi.encryptionType(test))
      {
        case 2: scanData[F("encryptionType")] = F("TKIP(WPA/PSK)"); break; //TKIP WPA PSK
        case 4: scanData[F("encryptionType")] = F("CCMP(WPA2/PSK)"); break;//CCMP WPA2 PSK
        case 5: scanData[F("encryptionType")] = F("WEP"); break;
        case 7: scanData[F("encryptionType")] = F("NONE"); break;
        case 8: scanData[F("encryptionType")] = F("AUTO"); break;
      }
      scanData[F("isHidden")] = WiFi.isHidden(test);
    }
  }
  String scanReturn;
  serializeJsonPretty(scan, scanReturn);
  scan.clear();
  WiFi.scanDelete();
  return scanReturn;
}

uint32_t ClassNetWork::Connect()
{
  WiFi.begin(WiFi.SSID().c_str(), WiFi.psk().c_str());
  unsigned long dataTimeEnd = millis(), dataTimeStart = millis();
  for (; dataTimeEnd - dataTimeStart < dataTime; dataTimeEnd = millis() , delay(true))
    if (WiFi.status() == WL_CONNECTED)return dataTimeEnd - dataTimeStart;
  return dataTimeEnd - dataTimeStart;
}

uint32_t ClassNetWork::SmartConfig()
{
  WiFi.beginSmartConfig();
  unsigned long dataTimeEnd = millis(), dataTimeStart = millis();
  for (; dataTimeEnd - dataTimeStart < dataTime; dataTimeEnd = millis(), delay(true))
  {
    if (WiFi.smartConfigDone())
    {
      WiFi.setAutoConnect(true);  // 设置自动连接
      return dataTimeEnd - dataTimeStart;
    }
  }
  WiFi.stopSmartConfig();
  return dataTimeEnd - dataTimeStart;
}

bool ClassNetWork::Reset()
{
  return WiFi.disconnect(true);
}

String ClassNetWork::IP()
{
  const size_t jsonSize = JSON_OBJECT_SIZE(10) + 0X120;
  DynamicJsonDocument ip(jsonSize);
  ip[F("Device")] = WiFi.hostname();
  ip[F("SSID")] = WiFi.SSID();
  ip[F("PSK")] = WiFi.psk();
  for (auto dataIP : addrList)
  {
    if (dataIP.isV6() && dataIP.isLocal() == false)           ip[F("ipv6IP")]  = dataIP.toString();
    if (dataIP.isV6() && dataIP.isLocal())                    ip[F("ipv6Mac")] = dataIP.toString();
    if (dataIP.isV6() == false && dataIP.isLocal() == false)  ip[F("ipv4IP")]  = dataIP.toString();
    if (dataIP.isLegacy())
    {
      ip[F("ipv4Mask")]    = dataIP.netmask().toString();
      ip[F("ipv4Gateway")] = dataIP.gw().toString();
      ip[F("ipv4Mac")]     = WiFi.macAddress();
    }
  }
  for (int dataIPDns = 0; dataIPDns < DNS_MAX_SERVERS; dataIPDns++)
  {
    IPAddress dataDns = WiFi.dnsIP(dataIPDns);
    if (dataDns.isSet())
    {
      switch (dataIPDns)
      {
        case false: ip[F("ipDns1")] = dataDns.toString(); break;
        case true:  ip[F("ipDns2")] = dataDns.toString(); break;
      }
    }
  }

  String ipReturn;
  serializeJsonPretty(ip, ipReturn);
  ip.clear();
  return ipReturn;
}

#undef dataTime
