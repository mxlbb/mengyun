#include <ArduinoJson.h>
#include "DHTesp.h"

#define defineRun

#define defineMQ2 A0
#define definePIR 5
#define defineBuzzer 15
#define defineThermometer 4
#define defineLightWarmIO 12
#define defineLightColdIO 14
#define switchControl  2
#define switchTesting  0

bool switchBoot = 0;

#ifndef defineRun
#define defineOperateIndependently
#endif

class ClassSensor;

class ClassSensor
{
  public:
    ClassSensor();
    ~ClassSensor();
  public:
    String Test();
    void begin();
    void Init();
    bool PIR();
    uint32_t MQ2();
    String Thermometer();
    void Buzzer(const uint32_t buzzerHZ);
    void LightWarm(const uint32_t lightWarm);
    void LightCold(const uint32_t lightCold);
    bool Switch(const String switchData);
  private:
    DHTesp dhtEsp;
} Sensor;

#ifdef defineOperateIndependently

void setup()
{
  Serial.begin(74880);
  Sensor.begin();
  Sensor.Init();
  Serial.println(Sensor.Test());
  delay(1000);
}

void loop() {}

#endif
#undef defineOperateIndependently

ClassSensor::ClassSensor() {}

ClassSensor::~ClassSensor() {}

String ClassSensor::Test()
{
  const size_t testSize = JSON_OBJECT_SIZE(0X3) + 0X64;
  DynamicJsonDocument testData(testSize);
  testData[F("温湿计数据")] = Thermometer().c_str();
  testData[F("人体感应测试")] = PIR() ? F("开启") : F("关闭");
  testData[F("模拟电压")] = MQ2();
  String testReturn;
  serializeJsonPretty(testData, testReturn);
  testData.clear();
  for (int test = 0; test <= 1023; test++)
  {
    Buzzer(test);
  }
  delay(1000);
  for (int test = 1023; test >= 0; test--)
  {
    Buzzer(test);
  }
  delay(1000);
  for (int test = 0; test <= 0XFF; test++)
  {
    LightWarm(test);
    LightCold(test);
    delay(10);
  }
  delay(1000);
  for (int test = 0XFF; test >= 0; test--)
  {
    LightWarm(test);
    LightCold(test);
    delay(10);
  }
  return testReturn;
}

void ClassSensor::begin()
{
  dhtEsp.setup(defineThermometer, DHTesp::DHT22);
  pinMode(definePIR, INPUT);
  pinMode(defineBuzzer, OUTPUT);
  pinMode(defineThermometer, INPUT);
  pinMode(defineLightWarmIO, OUTPUT);
  pinMode(defineLightColdIO, OUTPUT);
  pinMode(switchTesting, INPUT);
  pinMode(switchControl, OUTPUT);
}

void ClassSensor::Init()
{
  Buzzer(0);
  LightWarm(50);
  LightCold(50);
  Switch("true");
}

bool ClassSensor::PIR()
{
  return digitalRead(definePIR);
}

uint32_t ClassSensor::MQ2()
{
  return analogRead(defineMQ2);//log R= mlog C+ n(m均为常数)
}

String ClassSensor::Thermometer()
{
  const size_t dhtSize = JSON_OBJECT_SIZE(0X7) + 0X64;
  DynamicJsonDocument dhtDataJson(dhtSize);
  const uint64_t dataOutTime = millis();
  if (millis() - dataOutTime < unsigned(dhtEsp.getMinimumSamplingPeriod()))
  {

    dhtDataJson[F("状态")] = (String)dhtEsp.getStatusString() == F("OK") ? F("连接正常") : F("连接超时");
    dhtDataJson[F("温度")] = dhtEsp.getTemperature();
    dhtDataJson[F("湿度")] = dhtEsp.getHumidity();
    dhtDataJson[F("华氏温度")] = dhtEsp.toFahrenheit(dhtEsp.getTemperature());
    dhtDataJson[F("摄氏热量指数")] = dhtEsp.computeHeatIndex(dhtEsp.getTemperature(), dhtEsp.getHumidity(), false);
    dhtDataJson[F("华氏热量指数")] = dhtEsp.computeHeatIndex(dhtEsp.toFahrenheit(dhtEsp.getTemperature()), dhtEsp.getHumidity(), true);
    String dhtReturn;
    serializeJsonPretty(dhtDataJson, dhtReturn);
    dhtDataJson.clear();
    return dhtReturn;
  }
  String dhtReturn;
  serializeJsonPretty(dhtDataJson, dhtReturn);
  dhtDataJson.clear();
  return dhtReturn;
}

void ClassSensor::Buzzer(const uint32_t buzzerHZ)//1910,3885
{
  tone(15, buzzerHZ);
  delay(50);
  noTone(15);
}

void ClassSensor::LightWarm(const uint32_t lightWarm)
{
  analogWrite(defineLightWarmIO, lightWarm);
}

void ClassSensor::LightCold(const uint32_t lightCold)
{
  analogWrite(defineLightColdIO, lightCold);
}

bool ClassSensor::Switch(const String switchData)
{
  if (!digitalRead(switchTesting))
  {
    while (!digitalRead(switchTesting))delay(10);
    if (digitalRead(switchTesting))
    {
      Serial.print("if：\n");
      switchBoot = !switchBoot;
      digitalWrite(switchControl, switchBoot);
      return digitalRead(switchTesting);
    }
  }
  if (switchData == F("true") || switchData == F("on"))
  {
    digitalWrite(switchControl, HIGH);
    return true;
  }
  if (switchData == F("false") || switchData == F("off"))
  {
    digitalWrite(switchControl, LOW);
    return false;
  }
  return NULL;
}

#undef defineMQ2
#undef definePIR
#undef defineBuzzer
#undef defineThermometer
#undef defineLightWarmIO
#undef defineLightColdIO
