//IM身份认证框架
//#include "./src/Basic/src/Files.hpp"

#include <ArduinoJson.h>
#include <CmdParser.hpp>

CmdParser cmdParser;
class ClassIMFramework;

#define defineRun

#ifndef defineRun
#define defineOperateIndependently
#endif

class ClassIMFramework
{
  public:
    ClassIMFramework();
    ~ClassIMFramework();
  public:
    bool SearchIP(const String feilsString);
    bool AddIP(const String feilsString);
    bool DelIP(const String feilsString);
    bool FilterLAN(const String filter);
} IMFramework;

#ifdef defineOperateIndependently

void setup()
{
  Serial.begin(74880);
  Serial.println(NetWork.begin(17));
  for (int test = 0XFF; test > 0 ; test--)
  {
    Serial.printf("循环次数剩余：%d\n", test);
    Serial.println(NetWork.Test());
    delay(2000);
  }
}

void loop() {}

#endif
#undef defineOperateIndependently

ClassIMFramework::ClassIMFramework() {}
ClassIMFramework::~ClassIMFramework() {}

bool ClassIMFramework::SearchIP(const String feilsString)
{
  Files.begin();
  String ip = Files.Read("/IP.db");
  const size_t capacity = JSON_ARRAY_SIZE(0X100) + ip.length() + feilsString.length();
  DynamicJsonDocument doc(capacity);
  if (ip.length() >= 9) deserializeJson(doc, ip);
  for (uint8_t sum = 0; sum < doc.size(); sum++)
  {
    if (doc[sum] == feilsString)
    {
      doc.clear();
      Files.end();
      return true;
    }
  }
  return false;
}

bool ClassIMFramework::AddIP(const String feilsString)
{
  Files.begin();
  String ip = Files.Read("/IP.db");
  const size_t capacity = JSON_ARRAY_SIZE(0X100) + ip.length() + feilsString.length();
  DynamicJsonDocument doc(capacity);
  if (ip.length() >= 9) deserializeJson(doc, ip);
  for (uint8_t sum = 0; sum < doc.size(); sum++)
  {
    if (doc.size() == 0X100)return false;
    if (doc[sum] == feilsString)
    {
      doc.clear();
      Files.end();
      return false;
    }
  }
  doc.add(feilsString);
  ip = F("");
  serializeJson(doc, ip);
  Files.Write(F("/IP.db"), ip);
  Files.end();
  return true;
}

bool ClassIMFramework::DelIP(const String feilsString)
{
  Files.begin();
  String ip = Files.Read(F("/IP.db"));
  if (ip.length() >= 9)
  {
    const size_t capacity = JSON_ARRAY_SIZE(0X100) + ip.length() + feilsString.length();
    DynamicJsonDocument doc(capacity);
    deserializeJson(doc, ip);
    for (uint8_t sum = 0; sum <= doc.size(); ++sum)
      if (doc[sum] == feilsString)
      {
        doc.remove(sum);
        ip = F("");
        serializeJson(doc, ip);
        Files.Write(F("/IP.db"), ip);
        doc.clear();
        Files.end();
        return true;
      }
  }
  Files.end();
  return false;
}

bool ClassIMFramework::FilterLAN(const String filter)
{
#if false
  if (!filter.indexOf(F("2408")) == NULL)return true;
  if (!filter.indexOf(F("2409")) == NULL)return true;
  if (!filter.indexOf(F("240e")) == NULL)return true;
#endif
  if (!filter.indexOf(F("fec0")))return true;
  if (!filter.indexOf(F("fe80")))return true;
  if (!filter.indexOf(F("10")))return true;
  if (!filter.indexOf(F("192")))return true;
  if (!filter.indexOf(F("172.16")) ||
      !filter.indexOf(F("172.17")) ||
      !filter.indexOf(F("172.18")) ||
      !filter.indexOf(F("172.19")) ||
      !filter.indexOf(F("172.20")) ||
      !filter.indexOf(F("172.21")) ||
      !filter.indexOf(F("172.22")) ||
      !filter.indexOf(F("172.23")) ||
      !filter.indexOf(F("172.24")) ||
      !filter.indexOf(F("172.25")) ||
      !filter.indexOf(F("172.26")) ||
      !filter.indexOf(F("172.27")) ||
      !filter.indexOf(F("172.28")) ||
      !filter.indexOf(F("172.29")) ||
      !filter.indexOf(F("172.30")) ||
      !filter.indexOf(F("172.31")))
    return true;
  return false;
}
