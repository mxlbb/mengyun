/*
   1.合成JSON数据
   2.读取
   3.写入
   分解JSON数据
*/
/* Example showing timestamp support in LittleFS */
/* Released into the public domain. */
/* Earle F. Philhower, III <earlephilhower@yahoo.com> */
#include <LittleFS.h>
#include <ArduinoJson.h>

#define defineRun

#ifndef defineRun
#define defineOperateIndependently
#endif

class ClassLittleFS
{
  public:
    ClassLittleFS();
    ~ClassLittleFS();
  public:
    bool format();
    bool begin();
    bool end();
    String ListDir(const String dirname);
    String Read(const String path);
    bool Write(const String path, const String message);
    bool Append(const String path, const String message);
    bool Rename(const String pathFrom, const String pathTarget);
    bool Delete(const String path);
} Files;

#ifdef defineOperateIndependently

void setup()
{
  Serial.begin(74880);
  // We start by connecting to a WiFi networ
  String address = F("/hello.txt");
  String test = F("Hello World!\n");
  Serial.println();
  Serial.print(F("格式化LittleFS文件系统："));
  Serial.println(Files.format() ? F("成功") : F("失败"));
  Serial.print(F("装载LittleFS："));
  Serial.println(Files.begin() ? F("成功") : F("失败"));
  Serial.print(F("查看目录："));
  Serial.println(Files.ListDir("/"));
  Serial.print(F("删除文件："));
  Serial.println(Files.Delete(address) ? F("成功") : F("失败"));
  Serial.print(F("写入文件："));
  Serial.println(Files.Write(address, test) ? F("成功") : F("失败"));
  Serial.print(F("追加文件："));
  Serial.println(Files.Append(address, test) ? F("成功") : F("失败"));
  Serial.print(F("修改文件："));
  Serial.println(Files.Rename(address, "c.c"));
  Serial.print(F("查看目录："));
  Serial.println(Files.ListDir("/"));
  Serial.print(F("修改文件："));
  Serial.println(Files.Rename("c.c", address));
  Serial.print(F("查看目录："));
  Serial.println(Files.ListDir("/"));
  Files.end();
  Serial.println(Files.begin());
  Serial.print(F("读取文件："));
  Serial.println(Files.Read(address));
  Serial.print(F("删除文件："));
  Serial.println(Files.Delete(address) ? F("成功") : F("失败"));
  Serial.print(F("查看目录："));
  Serial.println(Files.ListDir("/"));

}

void loop() { }

#endif
#undef defineOperateIndependently

ClassLittleFS::ClassLittleFS() {}

ClassLittleFS::~ClassLittleFS() {}

bool ClassLittleFS::format()
{
  return LittleFS.format();
}

bool ClassLittleFS::begin()
{
  return LittleFS.begin();
}

bool ClassLittleFS::end()
{
  LittleFS.end();
  return true;
}

String ClassLittleFS::ListDir(const String dirname)
{
  /*
    //获取键值
    char json[] = "{\"first\":\"hello\",\"second\":\"world\"}";
    DynamicJsonDocument doc(1024);
    deserializeJson(doc, json);
    JsonObject root = doc.as<JsonObject>();
    for (JsonPair get : root) {
    Serial.println(get.key().c_str());
    Serial.println(get.value().as<char*>());
    }
  */
  Dir root = LittleFS.openDir(dirname.c_str());
  const size_t jsonSize =  JSON_ARRAY_SIZE(2) + JSON_OBJECT_SIZE(1) + 0X20 * 0X10;

  DynamicJsonDocument doc(jsonSize);
  while (root.next())
  {
    File file = root.openFile("r");
    doc[root.fileName()] = file.size();
    file.close();
  }
  String dirReturn;
  serializeJsonPretty(doc, dirReturn);
  return dirReturn;
}

String ClassLittleFS::Read(const String path)
{
  String readReturn;
  File file = LittleFS.open(path, "r");
  if (!file)
  {
    return "0";
  }
  while (file.available())
  {
    readReturn += file.readString();
  }
  file.close();
  return readReturn;
}

bool ClassLittleFS::Write(const String path, const String message)
{
  File file = LittleFS.open(path, "w");
  if (!file)
    return false;
  if (file.print(message))
  {
    file.close();
    return true;
  }
  file.close();
  return false;
}

bool ClassLittleFS::Append(const String path, const String message)
{
  File file = LittleFS.open(path, "a");
  if (!file)return false;
  if (file.print(message))
  {
    file.close();
    return true;
  }
  else
  {
    file.close();
  }
  return false;
}

bool ClassLittleFS::Rename(const String pathFrom, const String pathTarget)
{
  return LittleFS.rename(pathFrom, pathTarget);
}

bool ClassLittleFS::Delete(const String path)
{
  return LittleFS.remove(path);
}
