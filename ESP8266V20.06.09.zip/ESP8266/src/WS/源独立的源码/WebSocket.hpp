#include "imFramework.hpp"
#include "Network.hpp"

#include <Hash.h>
#include <WebSocketsServer.h>


#define defineRun

#ifndef defineRun
#define defineOperateIndependently
#endif

WebSocketsServer webSocket = WebSocketsServer(80);

void WSInit();
void WSServer();
void webSocketEvent(uint8_t num, WStype_t type, uint8_t *payload, size_t length);

#ifdef defineOperateIndependently

vvoid setup()
{
  // Serial.begin(921600);
  Serial.begin(74880);
  //Serial.setDebugOutput(true);
  WSInit();
}

void loop()
{
  //webSocket.loop();
  WSServer();
}

#endif
#undef defineOperateIndependently

void WSInit()
{
  Files.begin();
  Files.Delete("/IP.db");
  Files.end();
  webSocket.begin();
  webSocket.onEvent(webSocketEvent);
}

void WSServer()
{
  webSocket.loop();
}

void webSocketEvent(uint8_t num, WStype_t type, uint8_t *payload, size_t length)
{
  const String ip = webSocket.remoteIP(num).toString();
  //if (type == WStype_DISCONNECTED)DelIP(ip);
  switch (type)
  {
    case WStype_DISCONNECTED:
      {
        webSocket.sendTXT(num, "您已退出！You have been logged out!");
      }
      break;
    case WStype_CONNECTED:
      {
        //const String ip = webSocket.remoteIP(num).toString();
        Serial.println(ip);
        webSocket.sendTXT(num, "Websocket连接成功！");
        webSocket.sendTXT(num, "正在验证身份！");
        if (!IMFramework.FilterLAN(ip))
        {
          if (IMFramework.SearchIP(ip))
          {
            webSocket.sendTXT(num, "身份验证成功！IP：");
            webSocket.sendTXT(num, ip.c_str());
          }
          else
          {
            webSocket.sendTXT(num, "通信终止:身份验证错误！非授权IP");
            webSocket.sendTXT(num, ip.c_str());
            webSocket.disconnect(num);
          }
        }
        else
        {
          webSocket.sendTXT(num, "局域网授权，身份验证成功！IP：");
          webSocket.sendTXT(num, ip.c_str());
        }
      }
      break;
    case WStype_TEXT:
      {

        // Serial.printf("[%u] get Text: %s\n", num, payload);
        // send message to client
        // webSocket.sendTXT(num, payload);
        // send data to all connected clients
        // webSocket.broadcastTXT("message here");

        cmdParser.setOptKeyValue(true);
        if (cmdParser.parseCmd((char*)payload) != CMDPARSER_ERROR)
        {
          if (cmdParser.equalCommand_P(PSTR("Safety")))
          {
            if (!strcmp(cmdParser.getValueFromKey_P(PSTR("Set")), "add") &&
                !strcmp(cmdParser.getValueFromKey_P(PSTR("Uesr")), WiFi.SSID().c_str()) &&
                !strcmp(cmdParser.getValueFromKey_P(PSTR("PassWork")), WiFi.psk().c_str()))
              webSocket.sendTXT(num, IMFramework.AddIP(cmdParser.getValueFromKey_P(PSTR("IPAddress")))
                                ? "[\"添加授权地址成功\"]" : "[\"添加授权地址失败\"]");

            if (!strcmp(cmdParser.getValueFromKey_P(PSTR("Set")), "del") &&
                !strcmp(cmdParser.getValueFromKey_P(PSTR("Uesr")), WiFi.SSID().c_str()) &&
                !strcmp(cmdParser.getValueFromKey_P(PSTR("PassWork")), WiFi.psk().c_str()))
              webSocket.sendTXT(num, IMFramework.DelIP(cmdParser.getValueFromKey_P(PSTR("IPAddress")))
                                ? "[\"删除授权地址成功\"]" : "[\"删除授权地址失败\"]");

            if (!strcmp(cmdParser.getValueFromKey_P(PSTR("Set")), "disconnect") &&
                !strcmp(cmdParser.getValueFromKey_P(PSTR("Uesr")), WiFi.SSID().c_str()) &&
                !strcmp(cmdParser.getValueFromKey_P(PSTR("PassWork")), WiFi.psk().c_str()))
            {
              webSocket.sendTXT(num, "您已退出！You have been logged out!");
              webSocket.broadcastTXT("管理员强制所有用户下线！The administrator forces all users to go offline!");
              webSocket.disconnect();
            }
          }
          else
          {
            //放API代码
            //Api.Api(payload);
            webSocket.sendTXT(num, payload);
          }
        }
      }
      break;
    case WStype_BIN:
      {
        //Serial.printf("[%u] get binary length: %u\n", num, length);
        hexdump(payload, length);
        // send message to client
        // webSocket.sendBIN(num, payload, length);
      }
      break;
#if false
    case WStype_PONG: {} break;
    case WStype_PING: {} break;
    case WStype_FRAGMENT_FIN: {} break;
    case WStype_FRAGMENT: {} break;
    case WStype_FRAGMENT_BIN_START: {} break;
    case WStype_FRAGMENT_TEXT_START: {} break;
    case WStype_ERROR: {} break;
#endif
    default:
      {}
      break;
  }
}
